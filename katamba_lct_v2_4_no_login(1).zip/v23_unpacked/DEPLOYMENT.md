# Katamba LCT 2.0 — Deployment & Google indexing

## Local
python -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8000
Open http://127.0.0.1:8000/

## Default local admin
Username: admin
Password: Katamba@2026!
Change it before any public deployment using KATAMBA_ADMIN_PASSWORD and set KATAMBA_AUTH_SECRET.

## Production
Deploy this Dockerfile to any HTTPS-capable container host. Set:
- KATAMBA_AUTH_SECRET = long random secret
- KATAMBA_ADMIN_PASSWORD = strong unique password
- KATAMBA_SESSION_HOURS = desired session lifetime

Set the canonical domain in frontend/index.html to the real production domain.

## Google Search
A public HTTPS domain is required. After deployment:
1. Verify the domain in Google Search Console.
2. Submit /sitemap.xml.
3. Request indexing for the public homepage.
4. Keep /api/ and /app/private operational pages out of search.

The application cannot be indexed from localhost or a private IP. No hosting/Search Console connector is available in this environment, so deployment and Search Console submission must be completed after a public domain/hosting account is chosen.
