# Katamba Logistics Control Tower — V2.4 Local Single-User Build

This build continues the existing Katamba LCT V2 line. The login screen is disabled for local single-user operation so the system opens directly into Mission Control. The authentication/RBAC backend remains retained for a future production mode.

## Easiest Windows start
Double-click **START_KATAMBA.bat**.

It will:
1. Detect `py` or `python`.
2. Install the required packages if missing.
3. Start the FastAPI backend locally.
4. Open the system automatically in the browser.

Open manually: `http://127.0.0.1:8000/`

## Tests
`python -m pytest -q` → 20 tests passed.

## Security note
Local single-user mode is intended for local development/operations. Before any public deployment, enable authentication/RBAC and configure a strong `KATAMBA_AUTH_SECRET` and `KATAMBA_ADMIN_PASSWORD`.
