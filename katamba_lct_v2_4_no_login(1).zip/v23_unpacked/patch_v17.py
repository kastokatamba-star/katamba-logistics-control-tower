from pathlib import Path
p=Path('/mnt/data/lct/v17/backend/app/main.py')
s=p.read_text()
s=s.replace("from datetime import datetime, date, timezone", "from datetime import datetime, date, timezone")
s=s.replace("datetime.utcnow().strftime('%Y%m%d%H%M%S')", "datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')")
marker="# Serve the frontend from the same FastAPI process so users do not need a second server."
insert=r'''
# ---------------- V17: LCT 2.0 MISSION CONTROL / FINAL NORTH STAR ----------------
V17_VERSION='2.0.0'
V17_NAME='Katamba Logistics Control Tower — Mission Control'

@app.get('/api/v17/health')
def v17_health():
    c=db()
    required=['shipments','containers','trips','declarations','documents','demurrage','events','gps_positions','geofences','eta_forecasts','demurrage_forecasts','operational_alerts','operational_tasks','tariff_catalog','audit']
    checks={t:bool(c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",(t,)).fetchone()) for t in required}
    fk=bool(c.execute('PRAGMA foreign_keys').fetchone()[0]); wal=c.execute('PRAGMA journal_mode').fetchone()[0].lower()=='wal'
    c.close()
    return {'version':V17_VERSION,'name':V17_NAME,'status':'READY' if all(checks.values()) and fk and wal else 'DEGRADED','checks':{**checks,'foreign_keys':fk,'wal':wal},'principles':['official-source rules','evidence-first','decimal finance','immutable audit intent','idempotent events','UTC storage','Africa/Dar_es_Salaam display']}

def _maps_url(destination='Lubumbashi, DRC'):
    return 'https://www.google.com/maps/dir/?api=1&origin='+__import__('urllib.parse').parse.quote('Dar es Salaam, Tanzania')+'&destination='+__import__('urllib.parse').parse.quote(destination)+'&waypoints='+__import__('urllib.parse').parse.quote('Tunduma, Tanzania|Nakonde, Zambia|Kasumbalesa, Zambia')

@app.get('/api/v17/mission-control')
def v17_mission_control():
    c=db()
    shipments=c.execute('SELECT COUNT(*) n FROM shipments').fetchone()['n']
    containers=c.execute('SELECT COUNT(*) n FROM containers').fetchone()['n']
    active_trucks=c.execute("SELECT COUNT(*) n FROM trips WHERE status NOT IN ('OFFLOADED','DELIVERED','CLOSED')").fetchone()['n']
    open_exceptions=c.execute("SELECT COUNT(*) n FROM exceptions WHERE status NOT IN ('CLOSED','RESOLVED')").fetchone()['n']
    open_alerts=c.execute("SELECT COUNT(*) n FROM operational_alerts WHERE status='OPEN'").fetchone()['n']
    critical_alerts=c.execute("SELECT COUNT(*) n FROM operational_alerts WHERE status='OPEN' AND severity='CRITICAL'").fetchone()['n']
    overdue_tasks=c.execute("SELECT COUNT(*) n FROM operational_tasks WHERE status NOT IN ('COMPLETED','CLOSED') AND due_at IS NOT NULL AND due_at < ?",(now_utc(),)).fetchone()['n']
    open_dem=c.execute("SELECT COUNT(*) n FROM demurrage WHERE status='OPEN'").fetchone()['n']
    unverified_tariffs=c.execute("SELECT COUNT(*) n FROM tariff_catalog WHERE status!='VERIFIED'").fetchone()['n']
    gps=c.execute('SELECT COUNT(*) n FROM gps_positions').fetchone()['n']
    latest=c.execute('SELECT id,bl,customer,destination,status,created_at FROM shipments ORDER BY created_at DESC LIMIT 20').fetchall()
    c.close()
    return {'version':V17_VERSION,'mode':'MISSION_CONTROL','posture':{'shipments':shipments,'containers':containers,'active_trucks':active_trucks,'open_exceptions':open_exceptions,'open_alerts':open_alerts,'critical_alerts':critical_alerts,'overdue_tasks':overdue_tasks,'open_demurrage':open_dem,'unverified_tariffs':unverified_tariffs,'gps_events':gps},'corridor':['Dar es Salaam','Tunduma','Nakonde','Zambia','Kasumbalesa','DRC','Destination'],'timezone':'Africa/Dar_es_Salaam','maps_url':_maps_url(),'shipments': [dict(x) for x in latest]}

@app.get('/api/v17/shipment/{shipment_id}/360')
def v17_shipment_360(shipment_id:str):
    c=db()
    try:
        data=_shipment_twin(c,shipment_id)
        trips=data['trips']
        trip_ids=[x['sn'] for x in trips]
        gps=[]
        if trip_ids:
            q=','.join('?' for _ in trip_ids)
            gps=[dict(r) for r in c.execute(f'SELECT * FROM gps_positions WHERE trip_sn IN ({q}) ORDER BY recorded_at DESC LIMIT 50',tuple(trip_ids)).fetchall()]
        return {'version':V17_VERSION,'shipment':data['shipment'],'digital_twin':data['digital_twin'],'containers':data['containers'],'trucking':trips,'customs':data['declarations'],'documents':data['documents'],'demurrage':data['demurrage'],'events':data['events'],'exposures':data['exposures'],'tasks':data['open_tasks'],'eta':data['eta'],'risk':data['latest_risk'],'gps':gps,'maps_url':_maps_url(data['shipment'].get('destination') or 'Lubumbashi, DRC'),'calendar_timezone':'Africa/Dar_es_Salaam'}
    finally: c.close()

@app.get('/api/v17/tariff-governance')
def v17_tariff_governance():
    c=db(); total=c.execute('SELECT COUNT(*) n FROM tariff_catalog').fetchone()['n']; verified=c.execute("SELECT COUNT(*) n FROM tariff_catalog WHERE status='VERIFIED'").fetchone()['n']; batches=c.execute('SELECT COUNT(*) n FROM tariff_import_batches').fetchone()['n']; c.close()
    return {'version':V17_VERSION,'authority':'TRA/TANeSW official source','policy':'No invented production rates. Import exact official snapshots with source, version, effective date and checksum.','records':total,'verified_records':verified,'import_batches':batches,'status':'READY_FOR_OFFICIAL_DATASET' if total==0 or verified==total else 'REVIEW_REQUIRED'}

@app.get('/api/v17/architecture')
def v17_architecture():
    return {'version':V17_VERSION,'north_star':'One operational truth for the full cargo lifecycle','layers':['Experience & Command Centre','Digital Twin','Event & GPS Intelligence','Workflow & Exception Orchestration','Customs & Trade Rules','Shipment/Container/Trucking Core','Finance & Demurrage','Documents & Evidence','Integration/API Gateway','Security/RBAC/Audit','Analytics/AI Decision Support','Observability/DR/Offline Resilience'],'lifecycle':['B/L','Manifest','Documents','Customs','TRA/OGA controls','Release','Delivery Order','Port/ICD','Truck','Transit','Border','DRC destination','Delivery','Bond closure','Finance reconciliation'],'guardrails':['AI is decision support unless explicitly authorised','official regulatory/rate data is source-controlled','financial calculations use decimal arithmetic','every material action is auditable','events are idempotent','timestamps are stored in UTC and displayed in operational timezone']}

'''
s=s.replace(marker,insert+marker)
p.write_text(s)
