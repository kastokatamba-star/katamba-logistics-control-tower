from fastapi.testclient import TestClient
from backend.app.main import app
client=TestClient(app)
def test_manifest():
    r=client.get('/api/v10/enterprise/manifest'); assert r.status_code==200; assert r.json()['version']=='1.0.0'
def test_procedures_preserved():
    assert client.get('/api/v10/enterprise/manifest').json()['customs_procedures']==['EX1','EX2','EX3','IM4','IM5','IM6','IM7','IM8','IM9']
def test_task_evidence_gate():
    r=client.post('/api/v10/tasks',json={'entity_type':'TEST','entity_id':'V10','task_type':'EVIDENCE','title':'Evidence task','priority':'HIGH','evidence_required':True,'blocking':True}); assert r.status_code==200
    tid=r.json()['id']; assert client.patch(f'/api/v10/tasks/{tid}',json={'status':'COMPLETED'}).status_code==409
    assert client.post(f'/api/v10/tasks/{tid}/evidence-complete').status_code==200
    assert client.patch(f'/api/v10/tasks/{tid}',json={'status':'COMPLETED'}).status_code==200
def test_queue_and_quality():
    assert client.get('/api/v10/control-tower/queue').status_code==200
    assert 'quality_score' in client.get('/api/v10/quality/summary').json()
