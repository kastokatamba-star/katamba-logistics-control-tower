import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from fastapi.testclient import TestClient
from backend.app.main import app

client=TestClient(app)

def test_v15_health():
    r=client.get('/api/v15/health'); assert r.status_code==200; assert r.json()['status']=='READY'

def test_v15_network():
    r=client.get('/api/v15/network/overview'); assert r.status_code==200; assert 'route' in r.json()
