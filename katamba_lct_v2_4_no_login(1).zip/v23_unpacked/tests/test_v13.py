import sys, os
sys.path.insert(0, os.path.abspath('backend'))
from app.main import app
from fastapi.testclient import TestClient
c=TestClient(app)

def test_health():
 r=c.get('/api/v13/health'); assert r.status_code==200; assert r.json()['status']=='READY'
def test_eta():
 r=c.post('/api/v13/eta/predictions',json={'shipment_id':'V13TEST','predicted_eta':'2026-08-20T12:00:00+03:00','confidence':0.82,'factors':{'route':'Tunduma'}}); assert r.status_code==200
 r=c.get('/api/v13/eta/V13TEST'); assert r.status_code==200 and r.json()['predictions']
def test_risk():
 r=c.post('/api/v13/risk/calculate',json={'entity_type':'SHIPMENT','entity_id':'V13TEST','score':78,'level':'HIGH','factors':[{'factor':'border_delay'}],'recommended_actions':['INVESTIGATE']}); assert r.status_code==200
 r=c.get('/api/v13/risk/SHIPMENT/V13TEST'); assert r.status_code==200 and r.json()['decisions']
def test_twin():
 r=c.post('/api/v13/digital-twin/snapshot',json={'entity_type':'SHIPMENT','entity_id':'V13TEST','state':{'status':'IN_TRANSIT'},'health_score':80,'risk_score':20,'location':'Tunduma'}); assert r.status_code==200
 r=c.get('/api/v13/digital-twin/SHIPMENT/V13TEST'); assert r.status_code==200 and r.json()['latest']
def test_stream():
 r=c.get('/api/v13/event-stream'); assert r.status_code==200 and 'next_after_id' in r.json()
def test_command():
 r=c.get('/api/v13/command-centre'); assert r.status_code==200 and r.json()['version']=='1.3.0'
