import os,sys
sys.path.insert(0,os.path.join(os.path.dirname(__file__),'..'))
from fastapi.testclient import TestClient
from backend.app.main import app
client=TestClient(app)

def test_health():
    r=client.get('/api/v16/health'); assert r.status_code==200; assert r.json()['status']=='READY'
def test_geofences():
    r=client.get('/api/v16/geofences'); assert r.status_code==200; assert len(r.json()['geofences'])>=5
def test_live_trip():
    r=client.get('/api/v16/trip/1/live'); assert r.status_code==200; assert 'maps_url' in r.json()
def test_gps_and_stream():
    r=client.post('/api/v16/gps/position',json={'trip_sn':1,'latitude':-6.7924,'longitude':39.2083,'source':'TEST'}); assert r.status_code==200
    r=client.get('/api/v16/gps/trip/1'); assert r.status_code==200; assert len(r.json()['positions'])>=1
def test_eta():
    r=client.post('/api/v16/eta/forecast',json={'trip_sn':1,'predicted_eta':'2026-08-20T12:00:00+00:00','confidence':0.8}); assert r.status_code==200
    assert client.get('/api/v16/eta/trip/1').status_code==200
def test_command():
    r=client.get('/api/v16/command-centre'); assert r.status_code==200; assert r.json()['version']=='1.6.0'
