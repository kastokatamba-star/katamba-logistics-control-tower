import sys
sys.path.insert(0,'backend/app')
from main import exact_rate
from decimal import Decimal

def test_exact_rate():
    assert exact_rate('18.00','vat_rate') == '18.00'
    assert Decimal(exact_rate('0','duty')) == Decimal('0')

def test_reject_non_numeric():
    try:
        exact_rate('18%','vat_rate')
    except Exception as e:
        assert 'exact numeric string' in str(e.detail)
    else:
        raise AssertionError('expected rejection')
