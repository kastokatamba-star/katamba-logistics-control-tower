from fastapi import FastAPI, HTTPException, Request, Header
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from fastapi.responses import StreamingResponse, JSONResponse
from pydantic import BaseModel
from datetime import datetime, date, timezone
from pathlib import Path
from io import BytesIO
from typing import Optional, Any
import sqlite3, json, os, uuid, time, hashlib, hmac, secrets, base64
from openpyxl import Workbook
from decimal import Decimal, ROUND_HALF_UP, InvalidOperation

BASE=Path(__file__).resolve().parent
DB=BASE/'katamba.db'
def now_utc(): return datetime.now(timezone.utc).isoformat()
app=FastAPI(title='Katamba Logistics Control Tower', version='1.2.0')

# Allow the frontend to be opened either from the built-in server or a separate local dev server.
app.add_middleware(
    CORSMiddleware,
    allow_origins=['*'],
    allow_credentials=False,
    allow_methods=['*'],
    allow_headers=['*'],
)

@app.middleware('http')
async def request_context(request: Request, call_next):
    request_id = request.headers.get('X-Request-ID') or str(uuid.uuid4())
    started = time.perf_counter()
    try:
        response = await call_next(request)
    except Exception as exc:
        response = JSONResponse(status_code=500, content={'error':'internal_error','message':'Unexpected server error','request_id':request_id})
    response.headers['X-Request-ID'] = request_id
    response.headers['X-Response-Time-ms'] = f'{(time.perf_counter()-started)*1000:.2f}'
    return response

@app.exception_handler(HTTPException)
async def http_error_handler(request: Request, exc: HTTPException):
    rid = request.headers.get('X-Request-ID') or str(uuid.uuid4())
    return JSONResponse(status_code=exc.status_code, content={'error':'request_error','message':str(exc.detail),'request_id':rid}, headers={'X-Request-ID':rid})

PROCEDURES=[
 ('EX1','Export'),('EX2','Temporary Export'),('EX3','Re-export'),('IM4','Home Use'),
 ('IM5','Temporary Importation'),('IM6','Re-importation'),('IM7','Warehousing'),('IM8','Transit'),('IM9','Other import procedures')]
MILESTONES=['allocation','loading','dispatch','tunduma_arrival','tunduma_dispatch','nakonde_arrival','nakonde_dispatch','zambia_arrival','zambia_dispatch','zambia_entry_card','drc_arrival','drc_dispatch','drc_entry_card','whishky_in','whishky_out','arrival','offloaded']


def db():
    c=sqlite3.connect(DB, timeout=10)
    c.row_factory=sqlite3.Row
    c.execute('PRAGMA foreign_keys=ON')
    c.execute('PRAGMA journal_mode=WAL')
    c.execute('PRAGMA synchronous=NORMAL')
    c.execute('PRAGMA busy_timeout=10000')
    return c

def init():
    c=db()
    c.executescript('''
    CREATE TABLE IF NOT EXISTS shipments(id TEXT PRIMARY KEY, customer TEXT, tin TEXT, contact TEXT, phone TEXT, email TEXT, address TEXT, bl TEXT, origin TEXT, pol TEXT, pod TEXT, destination TEXT, vessel TEXT, voyage TEXT, cargo TEXT, containers INTEGER, status TEXT, created_at TEXT);
    CREATE TABLE IF NOT EXISTS trips(sn INTEGER PRIMARY KEY AUTOINCREMENT, truck TEXT, trailer1 TEXT, trailer2 TEXT, capacity TEXT, bl TEXT, container TEXT, location TEXT, driver TEXT, contact TEXT, licence TEXT, routing TEXT, passport TEXT, gross_weight REAL, free_days INTEGER DEFAULT 0, status TEXT DEFAULT 'PLANNED', created_at TEXT, allocation TEXT, loading TEXT, dispatch TEXT, tunduma_arrival TEXT, tunduma_dispatch TEXT, nakonde_arrival TEXT, nakonde_dispatch TEXT, zambia_arrival TEXT, zambia_dispatch TEXT, zambia_entry_card TEXT, drc_arrival TEXT, drc_dispatch TEXT, drc_entry_card TEXT, whishky_in TEXT, whishky_out TEXT, arrival TEXT, offloaded TEXT);
    CREATE TABLE IF NOT EXISTS documents(id INTEGER PRIMARY KEY AUTOINCREMENT, shipment_id TEXT, doc_type TEXT, number TEXT, status TEXT, file_name TEXT, created_at TEXT);
    CREATE TABLE IF NOT EXISTS exceptions(id INTEGER PRIMARY KEY AUTOINCREMENT, severity TEXT, category TEXT, title TEXT, description TEXT, owner TEXT, status TEXT, created_at TEXT);
    CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY AUTOINCREMENT, entity TEXT, entity_id TEXT, action TEXT, user TEXT, reason TEXT, old_value TEXT, new_value TEXT, created_at TEXT);
    CREATE TABLE IF NOT EXISTS masters(id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT, code TEXT, name TEXT, status TEXT, effective_from TEXT, effective_to TEXT);
    CREATE TABLE IF NOT EXISTS finance(id INTEGER PRIMARY KEY AUTOINCREMENT, shipment_id TEXT, type TEXT, reference TEXT, amount REAL, currency TEXT, status TEXT, created_at TEXT);
    CREATE TABLE IF NOT EXISTS containers(id INTEGER PRIMARY KEY AUTOINCREMENT, shipment_id TEXT, bl TEXT, container_no TEXT UNIQUE, size_type TEXT, seal_no TEXT, gross_weight REAL, status TEXT DEFAULT 'PLANNED', current_location TEXT, free_days INTEGER DEFAULT 0, discharge_date TEXT, empty_return_date TEXT, created_at TEXT);
    CREATE TABLE IF NOT EXISTS demurrage(id INTEGER PRIMARY KEY AUTOINCREMENT, container_no TEXT, shipment_id TEXT, tariff_code TEXT, currency TEXT DEFAULT 'USD', free_days INTEGER DEFAULT 0, start_date TEXT, end_date TEXT, chargeable_days INTEGER DEFAULT 0, accrued_amount REAL DEFAULT 0, status TEXT DEFAULT 'OPEN', waiver_amount REAL DEFAULT 0, notes TEXT, created_at TEXT);
    CREATE TABLE IF NOT EXISTS milestones(id INTEGER PRIMARY KEY AUTOINCREMENT, entity_type TEXT, entity_id TEXT, code TEXT, event_time TEXT, location TEXT, source TEXT, notes TEXT, created_at TEXT);
    CREATE TABLE IF NOT EXISTS rules(id INTEGER PRIMARY KEY AUTOINCREMENT, rule_type TEXT, code TEXT, version TEXT, effective_from TEXT, effective_to TEXT, source TEXT, status TEXT DEFAULT 'DRAFT', payload TEXT);
    CREATE TABLE IF NOT EXISTS declarations(id INTEGER PRIMARY KEY AUTOINCREMENT, shipment_id TEXT, bl TEXT, declaration_no TEXT UNIQUE, procedure_code TEXT, customs_office TEXT, declarant TEXT, importer TEXT, exporter TEXT, status TEXT DEFAULT 'DRAFT', hs_code TEXT, origin TEXT, destination TEXT, currency TEXT, customs_value REAL DEFAULT 0, duties_taxes REAL DEFAULT 0, query_reason TEXT, submitted_at TEXT, released_at TEXT, created_at TEXT);
    CREATE TABLE IF NOT EXISTS sla_events(id INTEGER PRIMARY KEY AUTOINCREMENT, entity_type TEXT, entity_id TEXT, category TEXT, due_at TEXT, status TEXT DEFAULT 'OPEN', owner TEXT, completed_at TEXT, notes TEXT, created_at TEXT);
    CREATE TABLE IF NOT EXISTS waiver_requests(id INTEGER PRIMARY KEY AUTOINCREMENT, demurrage_id INTEGER, container_no TEXT, reason TEXT, evidence TEXT, delay_days INTEGER DEFAULT 0, financial_impact REAL DEFAULT 0, relief_requested TEXT, status TEXT DEFAULT 'DRAFT', created_at TEXT);
    CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY AUTOINCREMENT, event_type TEXT, entity_type TEXT, entity_id TEXT, event_time TEXT, location TEXT, source TEXT, payload TEXT, created_at TEXT);
    CREATE TABLE IF NOT EXISTS notifications(id INTEGER PRIMARY KEY AUTOINCREMENT, severity TEXT, category TEXT, title TEXT, message TEXT, entity_type TEXT, entity_id TEXT, status TEXT DEFAULT 'OPEN', created_at TEXT, acknowledged_at TEXT);
    CREATE TABLE IF NOT EXISTS reconciliations(id INTEGER PRIMARY KEY AUTOINCREMENT, shipment_id TEXT, check_type TEXT, source_a TEXT, source_b TEXT, field_name TEXT, value_a TEXT, value_b TEXT, status TEXT, material INTEGER DEFAULT 0, notes TEXT, created_at TEXT);
    CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE, display_name TEXT, role TEXT, status TEXT DEFAULT 'ACTIVE', created_at TEXT);
    CREATE TABLE IF NOT EXISTS user_credentials(user_id INTEGER PRIMARY KEY, password_hash TEXT NOT NULL, salt TEXT NOT NULL, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE);
    CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL, expires_at TEXT NOT NULL, created_at TEXT NOT NULL, last_seen_at TEXT NOT NULL, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE);
    CREATE TABLE IF NOT EXISTS user_credentials(user_id INTEGER PRIMARY KEY, password_hash TEXT NOT NULL, salt TEXT NOT NULL, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE);
    CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL, expires_at TEXT NOT NULL, created_at TEXT NOT NULL, last_seen_at TEXT NOT NULL, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE);
    CREATE TABLE IF NOT EXISTS approvals(id INTEGER PRIMARY KEY AUTOINCREMENT, entity_type TEXT, entity_id TEXT, action TEXT, requested_by TEXT, approver_role TEXT, status TEXT DEFAULT 'PENDING', decision_reason TEXT, created_at TEXT, decided_at TEXT);
    CREATE TABLE IF NOT EXISTS permissions(id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT UNIQUE, name TEXT, module TEXT, description TEXT);
    CREATE TABLE IF NOT EXISTS role_permissions(id INTEGER PRIMARY KEY AUTOINCREMENT, role TEXT, permission_code TEXT, UNIQUE(role,permission_code));
    CREATE TABLE IF NOT EXISTS workflows(id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT UNIQUE, name TEXT, entity_type TEXT, version TEXT, status TEXT DEFAULT 'DRAFT', definition TEXT, effective_from TEXT, effective_to TEXT, source TEXT, created_at TEXT);
    CREATE TABLE IF NOT EXISTS workflow_runs(id INTEGER PRIMARY KEY AUTOINCREMENT, workflow_id INTEGER, entity_type TEXT, entity_id TEXT, state TEXT, current_step TEXT, started_at TEXT, updated_at TEXT, data TEXT);
    CREATE TABLE IF NOT EXISTS tariff_rules(id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT UNIQUE, name TEXT, currency TEXT, free_days INTEGER DEFAULT 0, tiers TEXT, source TEXT, version TEXT, effective_from TEXT, effective_to TEXT, status TEXT DEFAULT 'DRAFT');
    CREATE TABLE IF NOT EXISTS tariff_catalog(id INTEGER PRIMARY KEY AUTOINCREMENT, hs_code TEXT NOT NULL, description TEXT NOT NULL, unit TEXT, import_duty_rate TEXT, excise_rate TEXT, vat_rate TEXT, levy_rate TEXT, additional_measures TEXT, source_system TEXT NOT NULL, source_url TEXT, tariff_version TEXT NOT NULL, effective_from TEXT NOT NULL, effective_to TEXT, snapshot_ref TEXT NOT NULL, verified_at TEXT, verified_by TEXT, status TEXT DEFAULT 'UNVERIFIED', UNIQUE(hs_code, tariff_version, snapshot_ref));
    CREATE TABLE IF NOT EXISTS tariff_import_batches(id INTEGER PRIMARY KEY AUTOINCREMENT, source_system TEXT NOT NULL, source_url TEXT, tariff_version TEXT NOT NULL, snapshot_ref TEXT NOT NULL, record_count INTEGER DEFAULT 0, checksum TEXT NOT NULL, imported_at TEXT NOT NULL, imported_by TEXT, status TEXT DEFAULT 'IMPORTED');
    CREATE TABLE IF NOT EXISTS operational_tasks(id INTEGER PRIMARY KEY AUTOINCREMENT, entity_type TEXT NOT NULL, entity_id TEXT NOT NULL, task_type TEXT NOT NULL, title TEXT NOT NULL, priority TEXT DEFAULT 'MEDIUM', status TEXT DEFAULT 'OPEN', owner TEXT, due_at TEXT, source_rule TEXT, source_version TEXT, evidence_required INTEGER DEFAULT 0, evidence_complete INTEGER DEFAULT 0, blocking INTEGER DEFAULT 0, created_at TEXT NOT NULL, completed_at TEXT, notes TEXT);
    CREATE TABLE IF NOT EXISTS document_requirements(id INTEGER PRIMARY KEY AUTOINCREMENT, procedure_code TEXT NOT NULL, document_type TEXT NOT NULL, required INTEGER DEFAULT 1, source TEXT, version TEXT, effective_from TEXT, effective_to TEXT, UNIQUE(procedure_code, document_type));
    CREATE TABLE IF NOT EXISTS workflow_actions(id INTEGER PRIMARY KEY AUTOINCREMENT, workflow_run_id INTEGER NOT NULL, step_code TEXT NOT NULL, action TEXT NOT NULL, actor TEXT NOT NULL, outcome TEXT NOT NULL, reason TEXT, created_at TEXT NOT NULL);
    CREATE INDEX IF NOT EXISTS idx_tasks_entity_status ON operational_tasks(entity_type, entity_id, status, priority);
    CREATE INDEX IF NOT EXISTS idx_tasks_due ON operational_tasks(status, due_at);
    CREATE INDEX IF NOT EXISTS idx_docs_shipment_type ON documents(shipment_id, doc_type, status);
    CREATE INDEX IF NOT EXISTS idx_decl_shipment_status ON declarations(shipment_id, status);
    CREATE INDEX IF NOT EXISTS idx_events_entity_time ON events(entity_type, entity_id, event_time);
    CREATE INDEX IF NOT EXISTS idx_recon_ship_status ON reconciliations(shipment_id, status, material);
    CREATE TABLE IF NOT EXISTS classification_cases(id INTEGER PRIMARY KEY AUTOINCREMENT, shipment_id TEXT, declaration_id INTEGER, product_description TEXT NOT NULL, technical_characteristics TEXT, intended_use TEXT, material TEXT, candidate_hs TEXT, selected_hs TEXT, basis TEXT, confidence TEXT DEFAULT 'UNASSESSED', status TEXT DEFAULT 'OPEN', created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS valuation_cases(id INTEGER PRIMARY KEY AUTOINCREMENT, shipment_id TEXT, declaration_id INTEGER, currency TEXT NOT NULL, incoterm TEXT, invoice_value TEXT, freight TEXT, insurance TEXT, additions TEXT, deductions TEXT, method TEXT DEFAULT 'UNASSESSED', customs_value TEXT DEFAULT '0', evidence_ref TEXT, status TEXT DEFAULT 'OPEN', created_at TEXT NOT NULL);
    CREATE INDEX IF NOT EXISTS idx_classification_shipment ON classification_cases(shipment_id);
    CREATE INDEX IF NOT EXISTS idx_valuation_shipment ON valuation_cases(shipment_id);
    CREATE INDEX IF NOT EXISTS idx_tariff_import_version ON tariff_import_batches(tariff_version, snapshot_ref);
    CREATE INDEX IF NOT EXISTS idx_tariff_catalog_hs ON tariff_catalog(hs_code);
    CREATE INDEX IF NOT EXISTS idx_tariff_catalog_version ON tariff_catalog(tariff_version, effective_from);
    CREATE TABLE IF NOT EXISTS api_idempotency(id INTEGER PRIMARY KEY AUTOINCREMENT, idem_key TEXT UNIQUE NOT NULL, method TEXT NOT NULL, path TEXT NOT NULL, request_hash TEXT NOT NULL, status_code INTEGER, response_json TEXT, created_at TEXT NOT NULL, expires_at TEXT);
    CREATE TABLE IF NOT EXISTS risk_decisions(id INTEGER PRIMARY KEY AUTOINCREMENT, entity_type TEXT, entity_id TEXT, score REAL, level TEXT, reasons TEXT, recommended_action TEXT, model_version TEXT, created_at TEXT);
    CREATE TABLE IF NOT EXISTS evidence(id INTEGER PRIMARY KEY AUTOINCREMENT, entity_type TEXT, entity_id TEXT, evidence_type TEXT, reference TEXT, description TEXT, verified INTEGER DEFAULT 0, verified_by TEXT, verified_at TEXT, created_at TEXT);
    CREATE TABLE IF NOT EXISTS integration_endpoints(id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT UNIQUE, name TEXT, direction TEXT, base_url TEXT, status TEXT DEFAULT 'DESIGN', auth_type TEXT, last_check TEXT, notes TEXT);
    CREATE TABLE IF NOT EXISTS system_metrics(id INTEGER PRIMARY KEY AUTOINCREMENT, metric TEXT, value REAL, recorded_at TEXT);
    ''')
    if c.execute('SELECT COUNT(*) n FROM shipments').fetchone()['n']==0:
        c.execute('''INSERT INTO shipments VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',('SHP-0001','MAGETA COMPANY LTD','999-999-999','MAGETA MAGETA JAHN','0612734004','KASTOKATAMBA@GMAIL.COM','KIGAMBONI','12345MAGETA','CHINA','GHUANZOU','DAR ES SALAAM','DRC CONGO','TIPHAN','XW132','SHOES',10,'ON VESSEL',now_utc()))
        containers=['S12345678987','4567898765','567890098765','67890987','6789009876','8902345','4567','5678','456789','345678888']; weights=[123,65,890,34,98,678,456,4567,456,45]
        for i,(cn,w) in enumerate(zip(containers,weights),1):
            c.execute('''INSERT INTO trips(sn,bl,container,location,routing,gross_weight,free_days,created_at) VALUES(?,?,?,?,?,?,?,?)''',(i,'12345MAGETA',cn,'ON VESSEL','DAR–TUNDUMA–NAKONDE–ZAMBIA–DRC',w,7,now_utc()))
        c.execute("INSERT INTO exceptions(severity,category,title,description,owner,status,created_at) VALUES(?,?,?,?,?,?,?)",('INFO','SYSTEM','Project foundation created','Initial operational dataset loaded from customer shipment and trucking sheet.','System','OPEN',now_utc()))
    # Keep the seed shipment internally consistent: the ten sample trucking containers are also registered in the container registry.
    if c.execute("SELECT COUNT(*) FROM containers WHERE shipment_id='SHP-0001'").fetchone()[0] == 0:
        for tr in c.execute("SELECT container,bl,location,gross_weight,free_days FROM trips WHERE bl='12345MAGETA'").fetchall():
            c.execute('INSERT OR IGNORE INTO containers(shipment_id,bl,container_no,size_type,gross_weight,status,current_location,free_days,created_at) VALUES(?,?,?,?,?,?,?,?,?)',('SHP-0001',tr['bl'],tr['container'],'',tr['gross_weight'],'IN_TRANSIT',tr['location'],tr['free_days'],now_utc()))
    c.executescript('''
    CREATE TABLE IF NOT EXISTS status_history(id INTEGER PRIMARY KEY AUTOINCREMENT, entity_type TEXT, entity_id TEXT, old_status TEXT, new_status TEXT, reason TEXT, user TEXT, created_at TEXT);
    CREATE INDEX IF NOT EXISTS idx_status_history_entity ON status_history(entity_type,entity_id,created_at);
    CREATE INDEX IF NOT EXISTS idx_shipments_bl ON shipments(bl);
    CREATE INDEX IF NOT EXISTS idx_trips_container ON trips(container);
    CREATE INDEX IF NOT EXISTS idx_trips_bl ON trips(bl);
    CREATE INDEX IF NOT EXISTS idx_containers_shipment ON containers(shipment_id);
    CREATE INDEX IF NOT EXISTS idx_containers_location ON containers(current_location);
    CREATE INDEX IF NOT EXISTS idx_demurrage_container ON demurrage(container_no);
    CREATE INDEX IF NOT EXISTS idx_demurrage_status ON demurrage(status);
    CREATE INDEX IF NOT EXISTS idx_declarations_shipment ON declarations(shipment_id);
    CREATE INDEX IF NOT EXISTS idx_declarations_status ON declarations(status);
    CREATE INDEX IF NOT EXISTS idx_documents_shipment ON documents(shipment_id);
    CREATE INDEX IF NOT EXISTS idx_exceptions_status_severity ON exceptions(status,severity);
    CREATE INDEX IF NOT EXISTS idx_sla_status_due ON sla_events(status,due_at);
    CREATE INDEX IF NOT EXISTS idx_notifications_status ON notifications(status);
    CREATE INDEX IF NOT EXISTS idx_events_entity ON events(entity_type,entity_id,event_time);
    CREATE INDEX IF NOT EXISTS idx_milestones_entity ON milestones(entity_type,entity_id,event_time);
    CREATE INDEX IF NOT EXISTS idx_audit_entity ON audit(entity,entity_id,created_at);
    CREATE INDEX IF NOT EXISTS idx_reconciliation_shipment ON reconciliations(shipment_id,created_at);
    CREATE INDEX IF NOT EXISTS idx_approvals_status ON approvals(status);
    CREATE TABLE IF NOT EXISTS approval_matrix(id INTEGER PRIMARY KEY AUTOINCREMENT, action_code TEXT NOT NULL, entity_type TEXT NOT NULL, role TEXT NOT NULL, threshold_amount TEXT DEFAULT '', currency TEXT DEFAULT '', required_count INTEGER DEFAULT 1, active INTEGER DEFAULT 1, version TEXT NOT NULL, source TEXT, effective_from TEXT, effective_to TEXT, UNIQUE(action_code,entity_type,role,version));
    CREATE TABLE IF NOT EXISTS escalation_policies(id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT UNIQUE NOT NULL, category TEXT NOT NULL, trigger_minutes INTEGER NOT NULL, severity TEXT DEFAULT 'HIGH', escalate_to TEXT NOT NULL, version TEXT NOT NULL, source TEXT, active INTEGER DEFAULT 1);
    CREATE TABLE IF NOT EXISTS workflow_queue(id INTEGER PRIMARY KEY AUTOINCREMENT, workflow_run_id INTEGER, step_code TEXT NOT NULL, entity_type TEXT NOT NULL, entity_id TEXT NOT NULL, assignee TEXT, status TEXT DEFAULT 'READY', priority TEXT DEFAULT 'MEDIUM', due_at TEXT, created_at TEXT NOT NULL, completed_at TEXT);
    CREATE TABLE IF NOT EXISTS finance_reconciliations(id INTEGER PRIMARY KEY AUTOINCREMENT, shipment_id TEXT NOT NULL, reference TEXT NOT NULL, source_type TEXT NOT NULL, expected_amount TEXT NOT NULL, actual_amount TEXT NOT NULL, currency TEXT NOT NULL, variance TEXT NOT NULL, status TEXT DEFAULT 'OPEN', evidence_ref TEXT, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS exception_actions(id INTEGER PRIMARY KEY AUTOINCREMENT, exception_id INTEGER NOT NULL, action_code TEXT NOT NULL, owner TEXT, status TEXT DEFAULT 'PROPOSED', priority TEXT DEFAULT 'MEDIUM', due_at TEXT, evidence_required INTEGER DEFAULT 0, evidence_complete INTEGER DEFAULT 0, outcome TEXT, created_at TEXT NOT NULL, completed_at TEXT);
    CREATE TABLE IF NOT EXISTS exception_links(id INTEGER PRIMARY KEY AUTOINCREMENT, exception_id INTEGER NOT NULL, entity_type TEXT NOT NULL, entity_id TEXT NOT NULL, relation TEXT NOT NULL, created_at TEXT NOT NULL, UNIQUE(exception_id,entity_type,entity_id,relation));
    CREATE TABLE IF NOT EXISTS control_gates(id INTEGER PRIMARY KEY AUTOINCREMENT, entity_type TEXT NOT NULL, entity_id TEXT NOT NULL, gate_code TEXT NOT NULL, status TEXT NOT NULL, blockers TEXT, checked_at TEXT NOT NULL, rule_version TEXT, UNIQUE(entity_type,entity_id,gate_code));
    CREATE TABLE IF NOT EXISTS integration_messages(id INTEGER PRIMARY KEY AUTOINCREMENT, endpoint_code TEXT NOT NULL, direction TEXT NOT NULL, entity_type TEXT, entity_id TEXT, message_type TEXT NOT NULL, correlation_id TEXT NOT NULL, idempotency_key TEXT NOT NULL UNIQUE, status TEXT DEFAULT 'RECEIVED', payload TEXT, error TEXT, attempts INTEGER DEFAULT 0, created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS route_checkpoints(id INTEGER PRIMARY KEY AUTOINCREMENT, shipment_id TEXT NOT NULL, checkpoint_code TEXT NOT NULL, sequence_no INTEGER NOT NULL, location TEXT, planned_at TEXT, actual_at TEXT, status TEXT DEFAULT 'PENDING', source TEXT, UNIQUE(shipment_id,checkpoint_code));
    CREATE TABLE IF NOT EXISTS cost_exposures(id INTEGER PRIMARY KEY AUTOINCREMENT, shipment_id TEXT NOT NULL, container_no TEXT, exposure_type TEXT NOT NULL, amount TEXT NOT NULL, currency TEXT NOT NULL, status TEXT DEFAULT 'OPEN', source_ref TEXT, created_at TEXT NOT NULL);
    CREATE INDEX IF NOT EXISTS idx_approval_matrix_action ON approval_matrix(action_code,entity_type,active);
    CREATE INDEX IF NOT EXISTS idx_escalation_active ON escalation_policies(active,category);
    CREATE INDEX IF NOT EXISTS idx_workflow_queue_status ON workflow_queue(status,priority,due_at);
    CREATE INDEX IF NOT EXISTS idx_finance_recon_shipment ON finance_reconciliations(shipment_id,status);
    ''')
    c.commit(); c.close()
init()

def parse_dt(v):
    if not v: return None
    try: return datetime.fromisoformat(v.replace('Z','+00:00')).date()
    except: return date.fromisoformat(v[:10])

def days(a,b):
    a,b=parse_dt(a),parse_dt(b)
    return max(0,(b-a).days) if a and b else 0

def enrich(r):
    t=dict(r); end=t.get('offloaded') or date.today().isoformat()
    t['transit_days']=days(t.get('dispatch'),end) if t.get('dispatch') else 0
    t['border_days']=days(t.get('tunduma_arrival'),t.get('drc_dispatch') or t.get('arrival'))
    t['chargeable_days']=max(0,t['transit_days']-int(t.get('free_days') or 0))
    for key,label in [('offloaded','OFFLOADED'),('arrival','ARRIVED DESTINATION'),('drc_dispatch','DRC DISPATCH'),('drc_arrival','DRC ARRIVAL'),('zambia_dispatch','ZAMBIA DISPATCH'),('zambia_arrival','ZAMBIA ARRIVAL'),('nakonde_dispatch','NAKONDE DISPATCH'),('nakonde_arrival','NAKONDE ARRIVAL'),('tunduma_dispatch','TUNDUMA DISPATCH'),('tunduma_arrival','TUNDUMA ARRIVAL'),('dispatch','DISPATCHED'),('loading','LOADED'),('allocation','ALLOCATED')]:
        if t.get(key): t['status']=label; break
    else: t['status']=t.get('status') or 'PLANNED'
    t['current_location']=t.get('location') or '—'
    return t

def rows(table, where='', args=()):
    c=db(); q='SELECT * FROM '+table+((' WHERE '+where) if where else ''); out=[dict(x) for x in c.execute(q,args).fetchall()]; c.close(); return out

def audit(entity,eid,action,user,reason,old=None,new=None):
    c=db(); c.execute('INSERT INTO audit(entity,entity_id,action,user,reason,old_value,new_value,created_at) VALUES(?,?,?,?,?,?,?,?)',(entity,str(eid),action,user,reason,json.dumps(old) if old is not None else None,json.dumps(new) if new is not None else None,now_utc())); c.commit(); c.close()



def money(v): return round(float(v or 0), 2)
def tariff_amount(days_n, tiers):
    total=0; remaining=max(0,int(days_n))
    for span,rate in tiers:
        take=min(remaining,span); total += take*rate; remaining -= take
        if remaining<=0: break
    if remaining>0: total += remaining*tiers[-1][1]
    return money(total)

@app.get('/api/control-tower')
def control_tower():
    t=[enrich(x) for x in rows('trips')]; s=rows('shipments'); c=rows('containers'); d=rows('demurrage'); e=rows('exceptions')
    risks=[]
    for x in t:
        if x['chargeable_days']>0: risks.append({'type':'DEMURRAGE_RISK','severity':'HIGH','entity':x.get('container'),'days':x['chargeable_days'],'message':f"{x.get('container')} is {x['chargeable_days']} chargeable day(s) beyond free time"})
        elif x.get('free_days') and x.get('transit_days',0)>=max(0,int(x['free_days'])-2): risks.append({'type':'FREE_TIME_EXPIRY','severity':'MEDIUM','entity':x.get('container'),'days_remaining':max(0,int(x['free_days'])-x.get('transit_days',0)),'message':'Free time is approaching expiry'})
    for x in e:
        if x['status']=='OPEN': risks.append({'type':'EXCEPTION','severity':x['severity'],'entity':x['id'],'message':x['title']})
    return {'kpis':{'shipments':len(s),'containers':len(c) or sum(x.get('containers',0) or 0 for x in s),'active_transit':sum(x['status'] not in ('OFFLOADED','PLANNED') for x in t),'open_exceptions':sum(x['status']=='OPEN' for x in e),'demurrage_exposure':money(sum(x.get('accrued_amount',0) or 0 for x in d))},'risks':risks[:100]}

@app.get('/api/containers')
def container_list(): return rows('containers')

class ContainerIn(BaseModel):
    shipment_id:str=''; bl:str=''; container_no:str; size_type:str=''; seal_no:str=''; gross_weight:float=0; status:str='PLANNED'; current_location:str=''; free_days:int=0; discharge_date:str=''; empty_return_date:str=''
@app.post('/api/containers')
def create_container(x:ContainerIn):
    c=db()
    try:
        cur=c.execute('INSERT INTO containers(shipment_id,bl,container_no,size_type,seal_no,gross_weight,status,current_location,free_days,discharge_date,empty_return_date,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',(x.shipment_id,x.bl,x.container_no,x.size_type,x.seal_no,x.gross_weight,x.status,x.current_location,x.free_days,x.discharge_date,x.empty_return_date,now_utc())); c.commit(); i=cur.lastrowid
    except sqlite3.IntegrityError: c.close(); raise HTTPException(409,'Container already exists')
    c.close(); audit('CONTAINER',i,'CREATE','Operator','Container registered'); return {'id':i}

@app.get('/api/demurrage')
def demurrage(): return rows('demurrage')

class DemurrageIn(BaseModel):
    container_no:str; shipment_id:str=''; tariff_code:str='CUSTOM'; currency:str='USD'; free_days:int=0; start_date:str; end_date:str=''; chargeable_days:int=0; accrued_amount:float=0; status:str='OPEN'; waiver_amount:float=0; notes:str=''
@app.post('/api/demurrage')
def create_demurrage(x:DemurrageIn):
    chargeable=x.chargeable_days
    if not chargeable and x.end_date: chargeable=max(0,days(x.start_date,x.end_date)-x.free_days)
    amount=x.accrued_amount
    # Do not invent a live shipping-line tariff. Custom/manual amounts remain explicit.
    c=db(); cur=c.execute('INSERT INTO demurrage(container_no,shipment_id,tariff_code,currency,free_days,start_date,end_date,chargeable_days,accrued_amount,status,waiver_amount,notes,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',(x.container_no,x.shipment_id,x.tariff_code,x.currency,x.free_days,x.start_date,x.end_date,chargeable,amount,x.status,x.waiver_amount,x.notes,now_utc())); c.commit(); i=cur.lastrowid; c.close(); audit('DEMURRAGE',i,'CREATE','Operator','Demurrage record created'); return {'id':i,'chargeable_days':chargeable,'accrued_amount':money(amount)}

@app.get('/api/risk')
def risk(): return control_tower()['risks']

@app.get('/api/rules')
def rules(): return rows('rules')

class RuleIn(BaseModel): rule_type:str; code:str; version:str; effective_from:str; effective_to:str=''; source:str=''; status:str='DRAFT'; payload:dict={}
@app.post('/api/rules')
def create_rule(x:RuleIn):
    c=db(); cur=c.execute('INSERT INTO rules(rule_type,code,version,effective_from,effective_to,source,status,payload) VALUES(?,?,?,?,?,?,?,?)',(x.rule_type,x.code,x.version,x.effective_from,x.effective_to,x.source,x.status,json.dumps(x.payload))); c.commit(); i=cur.lastrowid; c.close(); audit('RULE',i,'CREATE','Operator','Versioned rule created'); return {'id':i}

@app.get('/api/health')
def health():
    c=db(); tables=[r['name'] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()]; c.close()
    return {'status':'ok','version':'0.9.0','database':str(DB),'capabilities':['event-stream','risk-engine','reconciliation','approval-workflow','rbac','workflow-engine','tariff-engine','evidence-control','integration-contracts','observability'],'tables':len(tables)}

# --- V7 Enterprise hardening ---
DEFAULT_PERMISSIONS=[
 ('DASHBOARD.VIEW','View control tower','DASHBOARD','Executive and operational dashboards'),
 ('SHIPMENT.READ','View shipments','SHIPMENTS','Shipment records and 360 view'),
 ('SHIPMENT.WRITE','Update shipments','SHIPMENTS','Create/update shipment data'),
 ('CUSTOMS.READ','View customs','CUSTOMS','Declarations and validation'),
 ('CUSTOMS.SUBMIT','Submit customs workflow','CUSTOMS','Move declarations through submission'),
 ('FINANCE.READ','View finance','FINANCE','Financial exposure and transactions'),
 ('DEMURRAGE.CALCULATE','Calculate demurrage','FINANCE','Run versioned demurrage tariff calculations'),
 ('DEMURRAGE.WAIVER','Request demurrage waiver','FINANCE','Create and route waiver requests'),
 ('WORKFLOW.MANAGE','Manage workflows','ADMIN','Create and execute workflow definitions'),
 ('RBAC.MANAGE','Manage access','ADMIN','Manage users and role permissions'),
 ('EVIDENCE.VERIFY','Verify evidence','COMPLIANCE','Verify operational/customs evidence'),
 ('INTEGRATION.READ','View integrations','ADMIN','Integration contracts and health'),
 ('AUDIT.READ','View audit','COMPLIANCE','Audit and governance'),
]
DEFAULT_ROLES={'ADMIN':['*'],'MANAGER':['DASHBOARD.VIEW','SHIPMENT.READ','SHIPMENT.WRITE','CUSTOMS.READ','CUSTOMS.SUBMIT','FINANCE.READ','DEMURRAGE.CALCULATE','DEMURRAGE.WAIVER','WORKFLOW.MANAGE','EVIDENCE.VERIFY','INTEGRATION.READ','AUDIT.READ'],'DECLARATION_OFFICER':['DASHBOARD.VIEW','SHIPMENT.READ','CUSTOMS.READ','CUSTOMS.SUBMIT','EVIDENCE.VERIFY','AUDIT.READ'],'OPERATIONS':['DASHBOARD.VIEW','SHIPMENT.READ','SHIPMENT.WRITE','FINANCE.READ','DEMURRAGE.CALCULATE','DEMURRAGE.WAIVER','EVIDENCE.VERIFY'],'VIEWER':['DASHBOARD.VIEW','SHIPMENT.READ','CUSTOMS.READ','FINANCE.READ']}

def seed_v6():
    c=db()
    for code,name,module,desc in DEFAULT_PERMISSIONS:
        c.execute('INSERT OR IGNORE INTO permissions(code,name,module,description) VALUES(?,?,?,?)',(code,name,module,desc))
    for role,codes in DEFAULT_ROLES.items():
        for code in codes:
            if code=='*':
                for pr in DEFAULT_PERMISSIONS: c.execute('INSERT OR IGNORE INTO role_permissions(role,permission_code) VALUES(?,?)',(role,pr[0]))
            else: c.execute('INSERT OR IGNORE INTO role_permissions(role,permission_code) VALUES(?,?)',(role,code))
    for username,display,role in [('admin','System Administrator','ADMIN'),('manager','Operations Manager','MANAGER'),('declaration.officer','Declaration Officer','DECLARATION_OFFICER'),('operator','Control Tower Operator','OPERATIONS'),('viewer','Read Only User','VIEWER')]:
        c.execute('INSERT OR IGNORE INTO users(username,display_name,role,created_at) VALUES(?,?,?,?)',(username,display,role,now_utc()))
    c.commit(); c.close()
seed_v6()

def has_permission(role,code):
    c=db(); ok=bool(c.execute('SELECT 1 FROM role_permissions WHERE role=? AND permission_code=?',(role,code)).fetchone()); c.close(); return ok

class AccessCheck(BaseModel): role:str; permission:str
@app.post('/api/access/check')
def access_check(x:AccessCheck): return {'allowed':has_permission(x.role,x.permission),'role':x.role,'permission':x.permission}
@app.get('/api/permissions')
def permissions(): return rows('permissions')
@app.get('/api/roles')
def roles():
    c=db(); out=[]
    for role in sorted(DEFAULT_ROLES):
        perms=[r['permission_code'] for r in c.execute('SELECT permission_code FROM role_permissions WHERE role=?',(role,)).fetchall()]
        out.append({'role':role,'permissions':perms})
    c.close(); return out
@app.get('/api/users')
def users(): return rows('users')

class WorkflowIn(BaseModel):
    code:str; name:str; entity_type:str; version:str='1.0'; status:str='DRAFT'; definition:dict={}; effective_from:str=''; effective_to:str=''; source:str=''
@app.get('/api/workflows')
def workflows(): return rows('workflows')
@app.post('/api/workflows')
def create_workflow(x:WorkflowIn):
    c=db(); cur=c.execute('INSERT INTO workflows(code,name,entity_type,version,status,definition,effective_from,effective_to,source,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)',(x.code,x.name,x.entity_type,x.version,x.status,json.dumps(x.definition),x.effective_from,x.effective_to,x.source,now_utc())); c.commit(); i=cur.lastrowid; c.close(); audit('WORKFLOW',i,'CREATE','Admin','Workflow definition created'); return {'id':i}
@app.get('/api/workflows/{id}/run')
def workflow_run(id:int,entity_type:str,entity_id:str):
    r=rows('workflows','id=?',(id,))
    if not r: raise HTTPException(404,'Workflow not found')
    wf=r[0]; definition=json.loads(wf['definition'] or '{}'); steps=definition.get('steps',[])
    first=steps[0]['code'] if steps and isinstance(steps[0],dict) else (steps[0] if steps else 'START')
    c=db(); cur=c.execute('INSERT INTO workflow_runs(workflow_id,entity_type,entity_id,state,current_step,started_at,updated_at,data) VALUES(?,?,?,?,?,?,?,?)',(id,entity_type,entity_id,'RUNNING',first,now_utc(),now_utc(),json.dumps({}))); c.commit(); rid=cur.lastrowid; c.close(); audit('WORKFLOW_RUN',rid,'START','Operator','Workflow started'); return {'id':rid,'state':'RUNNING','current_step':first}
@app.get('/api/workflow-runs')
def workflow_runs(): return rows('workflow_runs')

# --- V9: Customs intelligence and controlled official tariff ingestion ---
def exact_rate(value: Any, field: str) -> str:
    if value is None or str(value).strip() == '':
        return ''
    text=str(value).strip()
    try:
        Decimal(text)
    except InvalidOperation:
        raise HTTPException(400, f'{field} must be an exact numeric string')
    return text

class OfficialTariffRow(BaseModel):
    hs_code:str
    description:str
    unit:str=''
    import_duty_rate:str=''
    excise_rate:str=''
    vat_rate:str=''
    levy_rate:str=''
    additional_measures:str=''
    source_system:str='TANeSW/TRA'
    source_url:str=''
    tariff_version:str
    effective_from:str
    effective_to:str=''
    snapshot_ref:str

class TariffImportIn(BaseModel):
    source_system:str='TANeSW/TRA'
    source_url:str=''
    tariff_version:str
    effective_from:str
    effective_to:str=''
    snapshot_ref:str
    imported_by:str='Admin'
    rows:list[OfficialTariffRow]

@app.get('/api/customs/tariff-catalog')
def tariff_catalog(hs_code:str='', tariff_version:str='', snapshot_ref:str='', status:str=''):
    clauses=[]; vals=[]
    for field,val in [('hs_code',hs_code),('tariff_version',tariff_version),('snapshot_ref',snapshot_ref),('status',status)]:
        if val:
            clauses.append(f'{field}=?'); vals.append(val)
    where=' AND '.join(clauses) if clauses else '1=1'
    return rows('tariff_catalog',where,tuple(vals))[:500]

@app.get('/api/customs/tariff-imports')
def tariff_imports(): return rows('tariff_import_batches')[:200]

@app.post('/api/customs/tariff-import')
def import_official_tariff(x:TariffImportIn):
    if not x.rows: raise HTTPException(400,'Tariff import cannot be empty')
    if any(r.source_system != x.source_system or r.tariff_version != x.tariff_version or r.snapshot_ref != x.snapshot_ref for r in x.rows):
        raise HTTPException(400,'Every tariff row must match the import batch authority/version/snapshot')
    import hashlib
    canonical=json.dumps([r.model_dump() for r in x.rows],sort_keys=True,separators=(',',':')).encode()
    checksum=hashlib.sha256(canonical).hexdigest()
    c=db()
    try:
        now=now_utc()
        cur=c.execute('INSERT INTO tariff_import_batches(source_system,source_url,tariff_version,snapshot_ref,record_count,checksum,imported_at,imported_by) VALUES(?,?,?,?,?,?,?,?)',(x.source_system,x.source_url,x.tariff_version,x.snapshot_ref,len(x.rows),checksum,now,x.imported_by))
        batch_id=cur.lastrowid
        for r in x.rows:
            values={k:exact_rate(v,k) for k,v in [('import_duty_rate',r.import_duty_rate),('excise_rate',r.excise_rate),('vat_rate',r.vat_rate),('levy_rate',r.levy_rate)]}
            sql="INSERT INTO tariff_catalog(hs_code,description,unit,import_duty_rate,excise_rate,vat_rate,levy_rate,additional_measures,source_system,source_url,tariff_version,effective_from,effective_to,snapshot_ref,status) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
            c.execute(sql,(r.hs_code.strip(),r.description.strip(),r.unit,values['import_duty_rate'],values['excise_rate'],values['vat_rate'],values['levy_rate'],r.additional_measures,r.source_system,r.source_url,x.tariff_version,x.effective_from,x.effective_to,x.snapshot_ref,'UNVERIFIED'))
        c.commit()
    except sqlite3.IntegrityError:
        c.rollback(); c.close(); raise HTTPException(409,'Tariff row already exists in this version/snapshot or another uniqueness constraint failed')
    c.close(); audit('TARIFF_IMPORT',batch_id,'IMPORT',x.imported_by,'Official tariff snapshot imported',{'rows':len(x.rows)},{'checksum':checksum,'version':x.tariff_version,'snapshot_ref':x.snapshot_ref})
    return {'batch_id':batch_id,'records':len(x.rows),'checksum':checksum,'status':'IMPORTED','verification_required':True}

class ClassificationIn(BaseModel):
    shipment_id:str=''; declaration_id:int=0; product_description:str; technical_characteristics:str=''; intended_use:str=''; material:str=''; candidate_hs:list[str]=[]; selected_hs:str=''; basis:str=''; confidence:str='UNASSESSED'
@app.get('/api/customs/classification')
def classifications(shipment_id:str=''):
    return rows('classification_cases','shipment_id=?',(shipment_id,)) if shipment_id else rows('classification_cases')[:500]
@app.post('/api/customs/classification')
def create_classification(x:ClassificationIn):
    if not x.product_description.strip(): raise HTTPException(400,'Product description is required')
    if x.selected_hs and x.selected_hs not in x.candidate_hs: raise HTTPException(400,'Selected HS must be one of the recorded candidates')
    c=db(); cur=c.execute('INSERT INTO classification_cases(shipment_id,declaration_id,product_description,technical_characteristics,intended_use,material,candidate_hs,selected_hs,basis,confidence,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)',(x.shipment_id,x.declaration_id,x.product_description,x.technical_characteristics,x.intended_use,x.material,json.dumps(x.candidate_hs),x.selected_hs,x.basis,x.confidence,now_utc())); c.commit(); i=cur.lastrowid; c.close(); audit('CLASSIFICATION',i,'CREATE','Operator','Classification case created'); return {'id':i}

class ValuationIn(BaseModel):
    shipment_id:str=''; declaration_id:int=0; currency:str; incoterm:str=''; invoice_value:str; freight:str='0'; insurance:str='0'; additions:str='0'; deductions:str='0'; method:str='UNASSESSED'; evidence_ref:str=''
@app.get('/api/customs/valuation')
def valuations(shipment_id:str=''):
    return rows('valuation_cases','shipment_id=?',(shipment_id,)) if shipment_id else rows('valuation_cases')[:500]
@app.post('/api/customs/valuation')
def create_valuation(x:ValuationIn):
    try:
        nums={k:Decimal(str(v)) for k,v in {'invoice_value':x.invoice_value,'freight':x.freight,'insurance':x.insurance,'additions':x.additions,'deductions':x.deductions}.items()}
    except InvalidOperation: raise HTTPException(400,'Valuation inputs must be numeric strings')
    if any(v<0 for v in nums.values()): raise HTTPException(400,'Valuation inputs cannot be negative')
    customs=(nums['invoice_value']+nums['freight']+nums['insurance']+nums['additions']-nums['deductions']).quantize(Decimal('0.01'),rounding=ROUND_HALF_UP)
    if customs<0: raise HTTPException(400,'Computed customs value cannot be negative')
    c=db(); cur=c.execute('INSERT INTO valuation_cases(shipment_id,declaration_id,currency,incoterm,invoice_value,freight,insurance,additions,deductions,method,customs_value,evidence_ref,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',(x.shipment_id,x.declaration_id,x.currency,x.incoterm,x.invoice_value,x.freight,x.insurance,x.additions,x.deductions,x.method,str(customs),x.evidence_ref,now_utc())); c.commit(); i=cur.lastrowid; c.close(); audit('VALUATION',i,'CREATE','Operator','Valuation case created'); return {'id':i,'illustrative_customs_value':str(customs),'note':'Controlled data-preparation aid; legally applicable valuation method must be verified against current customs rules/advance rulings.'}

@app.get('/api/customs/360/{shipment_id}')
def customs_360(shipment_id:str):
    s=rows('shipments','id=?',(shipment_id,))
    if not s: raise HTTPException(404,'Shipment not found')
    d=rows('declarations','shipment_id=?',(shipment_id,)); docs=rows('documents','shipment_id=?',(shipment_id,)); rc=rows('reconciliations','shipment_id=?',(shipment_id,)); cls=rows('classification_cases','shipment_id=?',(shipment_id,)); val=rows('valuation_cases','shipment_id=?',(shipment_id,))
    return {'shipment':s[0],'declarations':d,'documents':docs,'reconciliations':rc,'classification':cls,'valuation':val,'tariff_lookups':sum(1 for x in d if x.get('hs_code'))}

class TariffIn(BaseModel):
    code:str; name:str; currency:str='USD'; free_days:int=0; tiers:list; source:str=''; version:str='1.0'; effective_from:str=''; effective_to:str=''; status:str='DRAFT'
@app.get('/api/tariffs')
def tariffs():
    out=rows('tariff_rules')
    for x in out: x['tiers']=json.loads(x['tiers'] or '[]')
    return out
@app.post('/api/tariffs')
def create_tariff(x:TariffIn):
    c=db(); cur=c.execute('INSERT INTO tariff_rules(code,name,currency,free_days,tiers,source,version,effective_from,effective_to,status) VALUES(?,?,?,?,?,?,?,?,?,?)',(x.code,x.name,x.currency,x.free_days,json.dumps(x.tiers),x.source,x.version,x.effective_from,x.effective_to,x.status)); c.commit(); i=cur.lastrowid; c.close(); audit('TARIFF',i,'CREATE','Admin','Versioned tariff rule created'); return {'id':i}
class TariffCalcIn(BaseModel):
    days_elapsed:int; free_days:int; tiers:list
@app.post('/api/tariffs/calculate')
def calculate_tariff(x:TariffCalcIn):
    chargeable=max(0,int(x.days_elapsed)-int(x.free_days)); amount=tariff_amount(chargeable,[(int(t[0]),float(t[1])) for t in x.tiers]) if x.tiers else 0
    return {'days_elapsed':x.days_elapsed,'free_days':x.free_days,'chargeable_days':chargeable,'amount':money(amount)}

class EvidenceIn(BaseModel): entity_type:str; entity_id:str; evidence_type:str; reference:str=''; description:str=''; verified:bool=False; verified_by:str=''
@app.get('/api/evidence')
def evidence(entity_type:str='',entity_id:str=''): return rows('evidence','entity_type=? AND entity_id=?',(entity_type,entity_id)) if entity_type and entity_id else rows('evidence')
@app.post('/api/evidence')
def create_evidence(x:EvidenceIn):
    now=now_utc(); c=db(); cur=c.execute('INSERT INTO evidence(entity_type,entity_id,evidence_type,reference,description,verified,verified_by,verified_at,created_at) VALUES(?,?,?,?,?,?,?,?,?)',(x.entity_type,x.entity_id,x.evidence_type,x.reference,x.description,int(x.verified),x.verified_by,now if x.verified else None,now)); c.commit(); i=cur.lastrowid; c.close(); audit('EVIDENCE',i,'CREATE','Operator','Evidence registered'); return {'id':i}
@app.patch('/api/evidence/{id}/verify')
def verify_evidence(id:int,user:str='Compliance Officer'):
    c=db(); old=c.execute('SELECT * FROM evidence WHERE id=?',(id,)).fetchone()
    if not old: c.close(); raise HTTPException(404,'Evidence not found')
    now=now_utc(); c.execute('UPDATE evidence SET verified=1,verified_by=?,verified_at=? WHERE id=?',(user,now,id)); c.commit(); new=dict(c.execute('SELECT * FROM evidence WHERE id=?',(id,)).fetchone()); c.close(); audit('EVIDENCE',id,'VERIFY',user,'Evidence verified',dict(old),new); return new

class IntegrationIn(BaseModel): code:str; name:str; direction:str='OUTBOUND'; base_url:str=''; status:str='DESIGN'; auth_type:str=''; notes:str=''
@app.get('/api/integrations')
def integrations(): return rows('integration_endpoints')
@app.post('/api/integrations')
def create_integration(x:IntegrationIn):
    c=db(); cur=c.execute('INSERT INTO integration_endpoints(code,name,direction,base_url,status,auth_type,notes) VALUES(?,?,?,?,?,?,?)',(x.code,x.name,x.direction,x.base_url,x.status,x.auth_type,x.notes)); c.commit(); i=cur.lastrowid; c.close(); audit('INTEGRATION',i,'CREATE','Admin','Integration contract created'); return {'id':i}
@app.get('/api/observability')
def observability():
    c=db(); metrics={
      'shipments':c.execute('SELECT COUNT(*) n FROM shipments').fetchone()['n'],
      'events':c.execute('SELECT COUNT(*) n FROM events').fetchone()['n'],
      'audit_records':c.execute('SELECT COUNT(*) n FROM audit').fetchone()['n'],
      'open_notifications':c.execute("SELECT COUNT(*) n FROM notifications WHERE status='OPEN'").fetchone()['n'],
      'pending_approvals':c.execute("SELECT COUNT(*) n FROM approvals WHERE status='PENDING'").fetchone()['n'],
      'open_sla':c.execute("SELECT COUNT(*) n FROM sla_events WHERE status='OPEN'").fetchone()['n'],
    }; c.close(); return {'status':'healthy','metrics':metrics,'checked_at':now_utc()}
@app.get('/api/procedures')
def procedures(): return [{'code':a,'name':b} for a,b in PROCEDURES]
@app.get('/api/shipments')
def shipments(): return rows('shipments')
@app.get('/api/trucking')
def trucking(): return [enrich(x) for x in rows('trips')]
@app.get('/api/documents')
def documents(): return rows('documents')
@app.get('/api/exceptions')
def exceptions(): return rows('exceptions')
@app.get('/api/audit')
def audits(): return rows('audit')
@app.get('/api/finance')
def finance(): return rows('finance')
@app.get('/api/masters')
def masters(): return rows('masters')


# --- V4: Advanced operational controls ---
class DeclarationIn(BaseModel):
    shipment_id:str=''; bl:str=''; declaration_no:str; procedure_code:str; customs_office:str=''; declarant:str=''; importer:str=''; exporter:str=''; status:str='DRAFT'; hs_code:str=''; origin:str=''; destination:str=''; currency:str='USD'; customs_value:float=0; duties_taxes:float=0; query_reason:str=''

@app.get('/api/declarations')
def declarations(): return rows('declarations')

@app.post('/api/declarations')
def create_declaration(x:DeclarationIn):
    if x.procedure_code not in dict(PROCEDURES): raise HTTPException(400,'Unsupported procedure code')
    c=db()
    try:
        cur=c.execute("INSERT INTO declarations(shipment_id,bl,declaration_no,procedure_code,customs_office,declarant,importer,exporter,status,hs_code,origin,destination,currency,customs_value,duties_taxes,query_reason,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", (x.shipment_id,x.bl,x.declaration_no,x.procedure_code,x.customs_office,x.declarant,x.importer,x.exporter,x.status,x.hs_code,x.origin,x.destination,x.currency,x.customs_value,x.duties_taxes,x.query_reason,now_utc()))
        c.commit(); i=cur.lastrowid
    except sqlite3.IntegrityError: c.close(); raise HTTPException(409,'Declaration number already exists')
    c.close(); audit('DECLARATION',i,'CREATE','Operator','Declaration created'); return {'id':i}

class DeclarationStatusIn(BaseModel): status:str; user:str='Operator'; reason:str='Status update'; query_reason:str=''
@app.patch('/api/declarations/{id}')
def update_declaration(id:int,x:DeclarationStatusIn):
    allowed={'DRAFT','VALIDATION','DOCUMENTS','ASSESSMENT','QUERY','INSPECTION','SUBMITTED','APPROVED','RELEASED','HOLD','CLOSED'}
    if x.status not in allowed: raise HTTPException(400,'Invalid declaration status')
    c=db(); old=c.execute('SELECT * FROM declarations WHERE id=?',(id,)).fetchone()
    if not old: c.close(); raise HTTPException(404,'Declaration not found')
    now=now_utc(); c.execute('UPDATE declarations SET status=?,query_reason=?,submitted_at=CASE WHEN ?="SUBMITTED" AND submitted_at IS NULL THEN ? ELSE submitted_at END,released_at=CASE WHEN ?="RELEASED" THEN ? ELSE released_at END WHERE id=?',(x.status,x.query_reason,x.status,now,x.status,now,id)); c.commit(); new=dict(c.execute('SELECT * FROM declarations WHERE id=?',(id,)).fetchone()); c.close(); audit('DECLARATION',id,'STATUS',x.user,x.reason,dict(old),new); return new

@app.get('/api/declarations/{id}/validation')
def validate_declaration(id:int):
    r=rows('declarations','id=?',(id,))
    if not r: raise HTTPException(404,'Declaration not found')
    d=r[0]; checks=[]
    def check(code,label,ok,msg): checks.append({'code':code,'label':label,'ok':bool(ok),'message':msg})
    check('PROCEDURE','Procedure selected',d['procedure_code'] in dict(PROCEDURES),'Procedure must be one of the configured declaration procedures')
    check('BL','B/L present',bool(d['bl']),'B/L reference is required')
    check('PARTY','Importer/Exporter identified',bool(d['importer'] or d['exporter']),'At least one trading party must be identified')
    check('HS','HS code present',bool(d['hs_code']),'HS classification evidence is required before submission')
    check('ORIGIN','Origin present',bool(d['origin']),'Origin evidence is required')
    check('VALUE','Customs value valid',float(d['customs_value'] or 0)>=0,'Customs value cannot be negative')
    check('DOCUMENTS','Supporting documents',len(rows('documents','shipment_id=?',(d['shipment_id'],)))>0,'At least one linked document should be registered')
    check('QUERY','No unresolved query',d['status']!='QUERY' or not d['query_reason'],'Resolve the declaration query before proceeding')
    return {'declaration_id':id,'ready':all(x['ok'] for x in checks),'checks':checks}

class SLAIn(BaseModel): entity_type:str; entity_id:str; category:str; due_at:str; owner:str=''; notes:str=''
@app.get('/api/sla')
def sla():
    out=[]; now=datetime.utcnow()
    for x in rows('sla_events'):
        y=dict(x)
        try: y['overdue']=y['status']=='OPEN' and datetime.fromisoformat(y['due_at'].replace('Z','+00:00')).replace(tzinfo=None)<now
        except: y['overdue']=False
        out.append(y)
    return out
@app.post('/api/sla')
def create_sla(x:SLAIn):
    c=db(); cur=c.execute('INSERT INTO sla_events(entity_type,entity_id,category,due_at,owner,notes,created_at) VALUES(?,?,?,?,?,?,?)',(x.entity_type,x.entity_id,x.category,x.due_at,x.owner,x.notes,now_utc())); c.commit(); i=cur.lastrowid; c.close(); audit('SLA',i,'CREATE','Operator','SLA created'); return {'id':i}

class WaiverIn(BaseModel): demurrage_id:int=0; container_no:str; reason:str; evidence:str=''; delay_days:int=0; financial_impact:float=0; relief_requested:str='Full waiver'
@app.get('/api/waivers')
def waivers(): return rows('waiver_requests')
@app.post('/api/waivers')
def create_waiver(x:WaiverIn):
    c=db(); cur=c.execute('INSERT INTO waiver_requests(demurrage_id,container_no,reason,evidence,delay_days,financial_impact,relief_requested,created_at) VALUES(?,?,?,?,?,?,?,?)',(x.demurrage_id,x.container_no,x.reason,x.evidence,x.delay_days,x.financial_impact,x.relief_requested,now_utc())); c.commit(); i=cur.lastrowid; c.close(); audit('WAIVER',i,'CREATE','Operator','Waiver request created'); return {'id':i}

@app.get('/api/shipments/{shipment_id}/360')
def shipment_360(shipment_id:str):
    s=rows('shipments','id=?',(shipment_id,))
    if not s: raise HTTPException(404,'Shipment not found')
    return {'shipment':s[0],'containers':rows('containers','shipment_id=?',(shipment_id,)),'declarations':rows('declarations','shipment_id=?',(shipment_id,)),'documents':rows('documents','shipment_id=?',(shipment_id,)),'finance':rows('finance','shipment_id=?',(shipment_id,)),'demurrage':rows('demurrage','shipment_id=?',(shipment_id,)),'milestones':rows('milestones','entity_id=?',(shipment_id,))}

class FieldUpdate(BaseModel): field:str; value:Optional[str]=None; user:str='Operator'; reason:str='Operational update'
@app.patch('/api/trucking/{sn}')
def update_trip(sn:int,change:FieldUpdate):
    c=db(); old=c.execute('SELECT * FROM trips WHERE sn=?',(sn,)).fetchone()
    if not old: c.close(); raise HTTPException(404,'Trip not found')
    if change.field not in old.keys(): c.close(); raise HTTPException(400,'Unknown field')
    oldd=dict(old); c.execute(f'UPDATE trips SET "{change.field}"=? WHERE sn=?',(change.value,sn)); c.commit(); new=dict(c.execute('SELECT * FROM trips WHERE sn=?',(sn,)).fetchone()); c.close()
    audit('TRIP',sn,'UPDATE',change.user,change.reason,{change.field:oldd.get(change.field)},{change.field:change.value}); return enrich(new)

class ShipmentIn(BaseModel): customer:str; bl:str; origin:str=''; pol:str=''; pod:str=''; destination:str=''; cargo:str=''; containers:int=0; status:str='PLANNED'; tin:str=''; contact:str=''; phone:str=''; email:str=''; address:str=''; vessel:str=''; voyage:str=''
@app.post('/api/shipments')
def create_shipment(x:ShipmentIn):
    sid='SHP-'+datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S'); c=db(); c.execute('INSERT INTO shipments VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(sid,x.customer,x.tin,x.contact,x.phone,x.email,x.address,x.bl,x.origin,x.pol,x.pod,x.destination,x.vessel,x.voyage,x.cargo,x.containers,x.status,now_utc())); c.commit(); c.close(); audit('SHIPMENT',sid,'CREATE','Operator','New shipment'); return {'id':sid}

class DocIn(BaseModel): shipment_id:str=''; doc_type:str; number:str=''; status:str='PENDING'; file_name:str=''
@app.post('/api/documents')
def create_doc(x:DocIn):
    c=db(); cur=c.execute('INSERT INTO documents(shipment_id,doc_type,number,status,file_name,created_at) VALUES(?,?,?,?,?,?)',(x.shipment_id,x.doc_type,x.number,x.status,x.file_name,now_utc())); c.commit(); i=cur.lastrowid; c.close(); audit('DOCUMENT',i,'CREATE','Operator','Document registered'); return {'id':i}

class ExIn(BaseModel): severity:str='MEDIUM'; category:str='OPERATIONS'; title:str; description:str=''; owner:str=''; status:str='OPEN'
@app.post('/api/exceptions')
def create_exception(x:ExIn):
    c=db(); cur=c.execute('INSERT INTO exceptions(severity,category,title,description,owner,status,created_at) VALUES(?,?,?,?,?,?,?)',(x.severity,x.category,x.title,x.description,x.owner,x.status,now_utc())); c.commit(); i=cur.lastrowid; c.close(); audit('EXCEPTION',i,'CREATE','Operator','Exception created'); return {'id':i}



# --- V5: Intelligence, automation and governance layer ---
class EventIn(BaseModel):
    event_type:str; entity_type:str; entity_id:str; event_time:str=''; location:str=''; source:str='MANUAL'; payload:dict={}

@app.get('/api/events')
def events(entity_type:str='', entity_id:str=''):
    if entity_type and entity_id: return rows('events','entity_type=? AND entity_id=?',(entity_type,entity_id))
    if entity_type: return rows('events','entity_type=?',(entity_type,))
    return rows('events')

@app.post('/api/events')
def create_event(x:EventIn):
    event_time=x.event_time or now_utc()
    c=db(); cur=c.execute('INSERT INTO events(event_type,entity_type,entity_id,event_time,location,source,payload,created_at) VALUES(?,?,?,?,?,?,?,?)',(x.event_type,x.entity_type,x.entity_id,event_time,x.location,x.source,json.dumps(x.payload),now_utc())); c.commit(); i=cur.lastrowid; c.close()
    audit('EVENT',i,'CREATE','Operator','Operational event recorded',None,x.model_dump())
    return {'id':i,'event_time':event_time}

@app.get('/api/notifications')
def notifications(status:str=''):
    return rows('notifications','status=?',(status,)) if status else rows('notifications')

class NotificationIn(BaseModel):
    severity:str='MEDIUM'; category:str='OPERATIONS'; title:str; message:str; entity_type:str=''; entity_id:str=''

@app.post('/api/notifications')
def create_notification(x:NotificationIn):
    c=db(); cur=c.execute('INSERT INTO notifications(severity,category,title,message,entity_type,entity_id,created_at) VALUES(?,?,?,?,?,?,?)',(x.severity,x.category,x.title,x.message,x.entity_type,x.entity_id,now_utc())); c.commit(); i=cur.lastrowid; c.close(); return {'id':i}

@app.post('/api/notifications/{id}/ack')
def acknowledge_notification(id:int, user:str='Operator'):
    c=db(); old=c.execute('SELECT * FROM notifications WHERE id=?',(id,)).fetchone()
    if not old: c.close(); raise HTTPException(404,'Notification not found')
    now=now_utc(); c.execute('UPDATE notifications SET status="ACKNOWLEDGED",acknowledged_at=? WHERE id=?',(now,id)); c.commit(); new=dict(c.execute('SELECT * FROM notifications WHERE id=?',(id,)).fetchone()); c.close(); audit('NOTIFICATION',id,'ACKNOWLEDGE',user,'Notification acknowledged',dict(old),new); return new

@app.get('/api/reconciliation/{shipment_id}')
def reconciliation(shipment_id:str):
    s=rows('shipments','id=?',(shipment_id,))
    if not s: raise HTTPException(404,'Shipment not found')
    sh=s[0]; docs=rows('documents','shipment_id=?',(shipment_id,)); decl=rows('declarations','shipment_id=?',(shipment_id,)); cons=rows('containers','shipment_id=?',(shipment_id,))
    checks=[]
    def add(code,a,b,field,va,vb,material=False): checks.append({'code':code,'source_a':a,'source_b':b,'field':field,'value_a':va,'value_b':vb,'match':str(va or '')==str(vb or ''),'material':material})
    if decl:
        d=decl[0]; add('BL_DECL','Shipment','Declaration','B/L',sh.get('bl'),d.get('bl'),True); add('ORIGIN','Shipment','Declaration','Origin',sh.get('origin'),d.get('origin'),True); add('DEST','Shipment','Declaration','Destination',''+str(sh.get('destination') or ''),d.get('destination'),True)
    add('DOC_PRESENCE','Shipment','Documents','Document count','expected>0',len(docs),False)
    add('CONTAINER_COUNT','Shipment','Container registry','Container count',sh.get('containers'),len(cons),True)
    return {'shipment_id':shipment_id,'checks':checks,'ready':all(x['match'] or not x['material'] for x in checks)}

@app.post('/api/reconciliation/{shipment_id}/run')
def run_reconciliation(shipment_id:str):
    result=reconciliation(shipment_id); c=db()
    for x in result['checks']:
        c.execute('INSERT INTO reconciliations(shipment_id,check_type,source_a,source_b,field_name,value_a,value_b,status,material,notes,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)',(shipment_id,x['code'],x['source_a'],x['source_b'],x['field'],str(x['value_a'] or ''),str(x['value_b'] or ''),'MATCH' if x['match'] else 'MISMATCH',1 if x['material'] else 0,'' if x['match'] else 'Material discrepancy requires review',now_utc()))
    c.commit(); c.close()
    mismatches=[x for x in result['checks'] if not x['match']]
    if mismatches:
        create_exception(ExIn(severity='HIGH' if any(x['material'] for x in mismatches) else 'MEDIUM',category='RECONCILIATION',title=f'Reconciliation mismatch for {shipment_id}',description='; '.join(f"{x['field']}: {x['value_a']} vs {x['value_b']}" for x in mismatches),owner='Declaration Officer'))
    return result

@app.get('/api/reconciliation/{shipment_id}/history')
def reconciliation_history(shipment_id:str): return rows('reconciliations','shipment_id=? ORDER BY id DESC',(shipment_id,))

@app.get('/api/automation/scan')
def automation_scan():
    created=[]; now=now_utc()
    c=db()
    # SLA overdue
    for x in sla():
        if x.get('overdue'):
            exists=c.execute('SELECT 1 FROM notifications WHERE category="SLA" AND entity_id=? AND status="OPEN"',(str(x['id']),)).fetchone()
            if not exists:
                c.execute('INSERT INTO notifications(severity,category,title,message,entity_type,entity_id,created_at) VALUES(?,?,?,?,?,?,?)',('HIGH','SLA','SLA overdue',f"{x['category']} for {x['entity_type']} {x['entity_id']} is overdue.",'SLA',str(x['id']),now)); created.append('SLA:'+str(x['id']))
    # demurrage exposure
    for d in rows('demurrage'):
        if float(d.get('accrued_amount') or 0)>0 and d.get('status')=='OPEN':
            exists=c.execute('SELECT 1 FROM notifications WHERE category="DEMURRAGE" AND entity_id=? AND status="OPEN"',(str(d['id']),)).fetchone()
            if not exists:
                c.execute('INSERT INTO notifications(severity,category,title,message,entity_type,entity_id,created_at) VALUES(?,?,?,?,?,?,?)',('HIGH','DEMURRAGE','Demurrage exposure',f"{d['container_no']} has accrued exposure {d['currency']} {d['accrued_amount']}.",'DEMURRAGE',str(d['id']),now)); created.append('DEM:'+str(d['id']))
    c.commit(); c.close()
    return {'created':created,'notifications_open':len(rows('notifications','status=?',('OPEN',))),'scanned_at':now}

class ApprovalIn(BaseModel): entity_type:str; entity_id:str; action:str; requested_by:str='Operator'; approver_role:str='MANAGER'
@app.get('/api/approvals')
def approvals(status:str=''):
    return rows('approvals','status=?',(status,)) if status else rows('approvals')
@app.post('/api/approvals')
def request_approval(x:ApprovalIn):
    c=db(); cur=c.execute('INSERT INTO approvals(entity_type,entity_id,action,requested_by,approver_role,created_at) VALUES(?,?,?,?,?,?)',(x.entity_type,x.entity_id,x.action,x.requested_by,x.approver_role,now_utc())); c.commit(); i=cur.lastrowid; c.close(); audit('APPROVAL',i,'REQUEST',x.requested_by,'Approval requested'); return {'id':i,'status':'PENDING'}

class ApprovalDecision(BaseModel): status:str; reason:str=''; user:str='Approver'
@app.patch('/api/approvals/{id}')
def decide_approval(id:int,x:ApprovalDecision):
    if x.status not in {'APPROVED','REJECTED'}: raise HTTPException(400,'Decision must be APPROVED or REJECTED')
    c=db(); old=c.execute('SELECT * FROM approvals WHERE id=?',(id,)).fetchone()
    if not old: c.close(); raise HTTPException(404,'Approval not found')
    now=now_utc(); c.execute('UPDATE approvals SET status=?,decision_reason=?,decided_at=? WHERE id=?',(x.status,x.reason,now,id)); c.commit(); new=dict(c.execute('SELECT * FROM approvals WHERE id=?',(id,)).fetchone()); c.close(); audit('APPROVAL',id,x.status,x.user,x.reason,dict(old),new); return new

@app.get('/api/analytics/overview')
def analytics_overview():
    t=[enrich(x) for x in rows('trips')]; d=rows('demurrage'); e=rows('exceptions'); decl=rows('declarations'); s=rows('shipments'); n=rows('notifications','status=?',('OPEN',))
    exposure=money(sum(float(x.get('accrued_amount') or 0)-float(x.get('waiver_amount') or 0) for x in d if x.get('status')=='OPEN'))
    return {'shipments':len(s),'containers':len(rows('containers')),'active_transit':sum(x['status'] not in ('OFFLOADED','PLANNED') for x in t),'declarations':{'total':len(decl),'released':sum(x['status']=='RELEASED' for x in decl),'query':sum(x['status']=='QUERY' for x in decl),'hold':sum(x['status']=='HOLD' for x in decl)},'demurrage':{'records':len(d),'open_exposure':exposure},'exceptions':{'open':sum(x['status']=='OPEN' for x in e),'high_or_critical':sum(x['status']=='OPEN' and x['severity'] in ('HIGH','CRITICAL') for x in e)},'notifications_open':len(n)}


@app.get('/api/dashboard')
def dashboard():
    t=[enrich(x) for x in rows('trips')]; s=rows('shipments'); e=rows('exceptions');
    return {'shipments':len(s),'trucks':len(t),'active_transit':sum(x['status'] not in ('OFFLOADED','PLANNED') for x in t),'chargeable_risk':sum(x['chargeable_days']>0 for x in t),'exceptions_open':sum(x['status']=='OPEN' for x in e),'containers':sum(x.get('containers',0) or 0 for x in s)}

@app.get('/api/trucking/export.xlsx')
def export_trucking():
    headers=['Sn.','Truck','Trailer I','Trailer II','Truck Capacity','B/L NO','CONTAINER NO','Current Location','Driver Name','CONTACT','D/Licence','ROUTING','PASSPORT NO.','Allocation Date','Loading Date','Dispatch date','Days','Tunduma Arrival','Tunduma Dispatch','Nakonde Arrival','Nakonde Dispatch','Zambia Side Arrival','Zambia Side Dispatch','Zambia Entry Card Submission','DRC Side Arrival','DRC Side Dispatch','DRC Entry Card Submission','Whishky Parking In','Whishky Parking Out','Border Days','Arrival','Offloaded','Transit Days','Free Days','Chargeable Days']
    wb=Workbook(); ws=wb.active; ws.title='Trucking Report'; ws.append(headers)
    for t in [enrich(x) for x in rows('trips')]: ws.append([t.get(k) for k in ['sn','truck','trailer1','trailer2','capacity','bl','container','location','driver','contact','licence','routing','passport','allocation','loading','dispatch','transit_days','tunduma_arrival','tunduma_dispatch','nakonde_arrival','nakonde_dispatch','zambia_arrival','zambia_dispatch','zambia_entry_card','drc_arrival','drc_dispatch','drc_entry_card','whishky_in','whishky_out','border_days','arrival','offloaded','transit_days','free_days','chargeable_days']])
    ws.freeze_panes='A2'; ws.auto_filter.ref=ws.dimensions; ws.sheet_view.showGridLines=False
    for cell in ws[1]: cell.font=__import__('openpyxl').styles.Font(bold=True); cell.alignment=__import__('openpyxl').styles.Alignment(wrap_text=True)
    for col in ws.columns: ws.column_dimensions[col[0].column_letter].width=min(35,max(12,max(len(str(c.value or '')) for c in col)+2))
    out=BytesIO(); wb.save(out); out.seek(0); return StreamingResponse(out,media_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',headers={'Content-Disposition':'attachment; filename=katamba_trucking_report.xlsx'})



# --- V7: Enterprise hardening & operational integrity ---
DECLARATION_TRANSITIONS={
    'DRAFT': {'VALIDATION','HOLD'},
    'VALIDATION': {'DOCUMENTS','HOLD','DRAFT'},
    'DOCUMENTS': {'ASSESSMENT','HOLD','VALIDATION'},
    'ASSESSMENT': {'QUERY','INSPECTION','SUBMITTED','HOLD'},
    'QUERY': {'ASSESSMENT','HOLD'},
    'INSPECTION': {'SUBMITTED','HOLD'},
    'SUBMITTED': {'APPROVED','QUERY','HOLD'},
    'APPROVED': {'RELEASED','HOLD'},
    'RELEASED': {'CLOSED'},
    'HOLD': {'VALIDATION','DOCUMENTS','ASSESSMENT','QUERY','INSPECTION','SUBMITTED','DRAFT'},
    'CLOSED': set(),
}

def now_utc():
    return datetime.now(timezone.utc).isoformat()

def paginated(table, page:int=1, page_size:int=50, where='', args=(), order='id DESC'):
    page=max(1,int(page)); page_size=min(200,max(1,int(page_size))); offset=(page-1)*page_size
    c=db()
    base='SELECT COUNT(*) n FROM '+table+((' WHERE '+where) if where else '')
    total=c.execute(base,args).fetchone()['n']
    q='SELECT * FROM '+table+((' WHERE '+where) if where else '')+' ORDER BY '+order+' LIMIT ? OFFSET ?'
    out=[dict(r) for r in c.execute(q,(*args,page_size,offset)).fetchall()]
    c.close()
    return {'items':out,'page':page,'page_size':page_size,'total':total,'pages':(total+page_size-1)//page_size}

def decimal_money(value):
    try: return Decimal(str(value or 0)).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
    except (InvalidOperation, ValueError, TypeError): raise HTTPException(400,'Invalid monetary value')

def calculate_tiers_decimal(chargeable_days:int, tiers:list[Any]):
    remaining=max(0,int(chargeable_days)); total=Decimal('0.00'); breakdown=[]
    normalised=[]
    for t in tiers:
        if isinstance(t,dict): span=int(t.get('days',0)); rate=decimal_money(t.get('rate',0))
        else: span=int(t[0]); rate=decimal_money(t[1])
        if span<=0 or rate<0: raise HTTPException(400,'Tariff tiers must have positive days and non-negative rates')
        normalised.append((span,rate))
    if not normalised and remaining: raise HTTPException(400,'Tariff tiers are required for chargeable days')
    for span,rate in normalised:
        take=min(remaining,span)
        if take:
            amount=(Decimal(take)*rate).quantize(Decimal('0.01'))
            breakdown.append({'days':take,'rate':float(rate),'amount':float(amount)})
            total+=amount; remaining-=take
        if remaining<=0: break
    if remaining:
        span,rate=normalised[-1]; amount=(Decimal(remaining)*rate).quantize(Decimal('0.01'))
        breakdown.append({'days':remaining,'rate':float(rate),'amount':float(amount),'continuation':True})
        total+=amount
    return total.quantize(Decimal('0.01')),breakdown

@app.get('/api/v7/health/readiness')
def readiness():
    c=db()
    try:
        c.execute('SELECT 1').fetchone()
        required=['shipments','trips','containers','declarations','demurrage','audit','events','rules','tariff_rules']
        missing=[t for t in required if not c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",(t,)).fetchone()]
        return {'ready':not missing,'database':'ok' if not missing else 'degraded','missing_tables':missing,'version':'0.7.0'}
    finally: c.close()

@app.get('/api/v7/health/live')
def liveness():
    return {'alive':True,'version':'0.7.0','timestamp':now_utc()}

@app.get('/api/v7/shipments/search')
def shipment_search(q:str='',page:int=1,page_size:int=50,status:str=''):
    q=q.strip(); where=[]; args=[]
    if q:
        like=f'%{q}%'; where.append('(id LIKE ? OR bl LIKE ? OR customer LIKE ? OR destination LIKE ? OR vessel LIKE ?)'); args += [like]*5
    if status: where.append('status=?'); args.append(status)
    return paginated('shipments',page,page_size,' AND '.join(where),tuple(args),'created_at DESC')

@app.get('/api/v7/containers/search')
def container_search(q:str='',page:int=1,page_size:int=50,status:str=''):
    q=q.strip(); where=[]; args=[]
    if q:
        like=f'%{q}%'; where.append('(container_no LIKE ? OR bl LIKE ? OR shipment_id LIKE ? OR current_location LIKE ?)'); args += [like]*4
    if status: where.append('status=?'); args.append(status)
    return paginated('containers',page,page_size,' AND '.join(where),tuple(args),'created_at DESC')

@app.get('/api/v7/containers/{container_no}/360')
def container_360(container_no:str):
    cons=rows('containers','container_no=?',(container_no,))
    if not cons: raise HTTPException(404,'Container not found')
    con=cons[0]
    return {
        'container':con,
        'shipment': rows('shipments','id=?',(con.get('shipment_id'),)),
        'trips':rows('trips','container=?',(container_no,)),
        'declarations':rows('declarations','shipment_id=?',(con.get('shipment_id'),)),
        'documents':rows('documents','shipment_id=?',(con.get('shipment_id'),)),
        'demurrage':rows('demurrage','container_no=?',(container_no,)),
        'milestones':rows('milestones','entity_id=?',(container_no,)),
        'events':rows('events','entity_type=? AND entity_id=? ORDER BY event_time ASC',('CONTAINER',container_no)),
        'evidence':rows('evidence','entity_type=? AND entity_id=?',('CONTAINER',container_no)),
    }

class EventIn(BaseModel):
    event_type:str
    entity_type:str
    entity_id:str
    event_time:str=''
    location:str=''
    source:str='MANUAL'
    payload:dict={}
    notes:str=''

@app.post('/api/v7/events')
def create_event(x:EventIn, idempotency_key:Optional[str]=Header(default=None,alias='Idempotency-Key')):
    if idempotency_key:
        existing=rows('events','source=? AND payload LIKE ? LIMIT 1',(f'IDEMPOTENCY:{idempotency_key}',f'%"idempotency_key": "{idempotency_key}"%'))
        if existing: return existing[0]
    payload=dict(x.payload or {}); payload['idempotency_key']=idempotency_key if idempotency_key else None; payload['notes']=x.notes
    event_time=x.event_time or now_utc(); c=db()
    cur=c.execute('INSERT INTO events(event_type,entity_type,entity_id,event_time,location,source,payload,created_at) VALUES(?,?,?,?,?,?,?,?)',(x.event_type,x.entity_type,x.entity_id,event_time,x.location,f'IDEMPOTENCY:{idempotency_key}' if idempotency_key else x.source,json.dumps(payload),now_utc()))
    c.commit(); event_id=cur.lastrowid; row=dict(c.execute('SELECT * FROM events WHERE id=?',(event_id,)).fetchone()); c.close()
    audit('EVENT',event_id,'CREATE','Operator','Operational event recorded')
    return row

@app.get('/api/v7/events')
def list_events(entity_type:str='',entity_id:str='',page:int=1,page_size:int=100):
    where=[]; args=[]
    if entity_type: where.append('entity_type=?'); args.append(entity_type)
    if entity_id: where.append('entity_id=?'); args.append(entity_id)
    return paginated('events',page,page_size,' AND '.join(where),tuple(args),'event_time DESC,id DESC')

@app.post('/api/v7/declarations/{id}/transition')
def declaration_transition(id:int, target_status:str, user:str='Operator', reason:str='Lifecycle transition'):
    c=db(); old=c.execute('SELECT * FROM declarations WHERE id=?',(id,)).fetchone()
    if not old: c.close(); raise HTTPException(404,'Declaration not found')
    current=old['status']; target=target_status.upper()
    if target not in DECLARATION_TRANSITIONS.get(current,set()):
        c.close(); raise HTTPException(409,f'Illegal declaration transition: {current} -> {target}')
    if target=='SUBMITTED':
        c.close(); validation=validate_declaration(id)
        if not validation['ready']: raise HTTPException(409,{'message':'Declaration failed pre-submission validation','checks':validation['checks']})
        c=db()
    stamp=now_utc()
    c.execute('UPDATE declarations SET status=?,query_reason=CASE WHEN ?<>"QUERY" THEN "" ELSE query_reason END,submitted_at=CASE WHEN ?="SUBMITTED" AND submitted_at IS NULL THEN ? ELSE submitted_at END,released_at=CASE WHEN ?="RELEASED" THEN ? ELSE released_at END WHERE id=?',(target,target,target,stamp,target,stamp,id))
    c.execute('INSERT INTO status_history(entity_type,entity_id,old_status,new_status,reason,user,created_at) VALUES(?,?,?,?,?,?,?)',('DECLARATION',str(id),current,target,reason,user,stamp))
    c.commit(); new=dict(c.execute('SELECT * FROM declarations WHERE id=?',(id,)).fetchone()); c.close()
    audit('DECLARATION',id,'TRANSITION',user,reason,dict(old),new)
    return new

@app.get('/api/v7/reconciliation/{shipment_id}')
def reconciliation_v7(shipment_id:str):
    s=rows('shipments','id=?',(shipment_id,))
    if not s: raise HTTPException(404,'Shipment not found')
    sh=s[0]; docs=rows('documents','shipment_id=?',(shipment_id,)); decls=rows('declarations','shipment_id=?',(shipment_id,)); cons=rows('containers','shipment_id=?',(shipment_id,))
    d=decls[0] if decls else None
    required_doc_types={'INVOICE','PACKING_LIST'}
    present={str(x.get('doc_type','')).upper() for x in docs}
    checks=[]
    def add(code,field,a,b,material=True,source_a='Shipment',source_b='Declaration'):
        match=str(a or '').strip().upper()==str(b or '').strip().upper()
        checks.append({'code':code,'field':field,'value_a':a,'value_b':b,'match':match,'material':material,'source_a':source_a,'source_b':source_b})
    if d:
        add('BL_DECL','B/L',sh.get('bl'),d.get('bl'))
        add('ORIGIN_DECL','Origin',sh.get('origin'),d.get('origin'))
        add('DEST_DECL','Destination',sh.get('destination'),d.get('destination'))
    else: checks.append({'code':'DECLARATION','field':'Declaration','match':False,'material':True,'message':'No declaration linked'})
    for typ in sorted(required_doc_types): checks.append({'code':f'DOC_{typ}','field':typ,'match':typ in present,'material':True,'source_a':'Shipment','source_b':'Documents','message':'Required commercial document registered' if typ in present else 'Required document missing'})
    declared_count=len(cons); expected=int(sh.get('containers') or 0)
    checks.append({'code':'CONTAINER_COUNT','field':'Container count','value_a':expected,'value_b':declared_count,'match':expected==declared_count,'material':True,'source_a':'Shipment','source_b':'Container Registry'})
    return {'shipment_id':shipment_id,'four_way_model':'B/L ↔ Invoice ↔ Packing List ↔ Declaration','checks':checks,'ready':all(x.get('match',False) or not x.get('material') for x in checks)}

class TariffCalcV7(BaseModel):
    elapsed_days:int
    free_days:int
    tiers:list[Any]
    currency:str='USD'
    rule_code:str='MANUAL'
    rule_version:str=''
    source:str=''

@app.post('/api/v7/tariffs/calculate')
def tariff_calculate_v7(x:TariffCalcV7):
    if x.elapsed_days<0 or x.free_days<0: raise HTTPException(400,'Days cannot be negative')
    chargeable=max(0,x.elapsed_days-x.free_days)
    amount,breakdown=calculate_tiers_decimal(chargeable,x.tiers)
    return {'rule_code':x.rule_code,'rule_version':x.rule_version,'source':x.source,'currency':x.currency,'elapsed_days':x.elapsed_days,'free_days':x.free_days,'chargeable_days':chargeable,'amount':float(amount),'breakdown':breakdown,'calculation_status':'CALCULATED_FROM_SUPPLIED_RULE'}

@app.get('/api/v7/control-tower/summary')
def control_tower_summary():
    c=db()
    q=lambda sql,args=(): c.execute(sql,args).fetchone()[0]
    d_exposure=q("SELECT COALESCE(SUM(accrued_amount-waiver_amount),0) FROM demurrage WHERE status='OPEN'")
    return {
        'version':'0.7.0',
        'shipments':q('SELECT COUNT(*) FROM shipments'),
        'containers':q('SELECT COUNT(*) FROM containers'),
        'active_transit':q("SELECT COUNT(*) FROM trips WHERE status NOT IN ('OFFLOADED','PLANNED')"),
        'customs_pending':q("SELECT COUNT(*) FROM declarations WHERE status NOT IN ('RELEASED','CLOSED')"),
        'customs_queries':q("SELECT COUNT(*) FROM declarations WHERE status='QUERY'"),
        'demurrage_open_exposure':float(decimal_money(d_exposure)),
        'open_exceptions':q("SELECT COUNT(*) FROM exceptions WHERE status='OPEN'"),
        'critical_exceptions':q("SELECT COUNT(*) FROM exceptions WHERE status='OPEN' AND severity='CRITICAL'"),
        'overdue_sla':q("SELECT COUNT(*) FROM sla_events WHERE status='OPEN' AND due_at < ?",(now_utc(),)),
        'pending_approvals':q("SELECT COUNT(*) FROM approvals WHERE status='PENDING'"),
    }

@app.get('/api/v7/metrics')
def metrics_v7():
    c=db(); tables=['shipments','containers','trips','declarations','documents','demurrage','exceptions','events','audit','notifications','approvals','sla_events']
    counts={t:c.execute(f'SELECT COUNT(*) FROM {t}').fetchone()[0] for t in tables}; c.close()
    return {'status':'healthy','version':'0.7.0','counts':counts,'timestamp':now_utc()}

# --- V8 Advanced Intelligence & Official Tariff Governance ---
OFFICIAL_TARIFF_SOURCE='TANeSW / Tanzania Revenue Authority'
OFFICIAL_TARIFF_URL='https://tanesw.tra.go.tz/'

class TariffCatalogIn(BaseModel):
    hs_code:str; description:str; unit:str=''
    import_duty_rate:str=''; excise_rate:str=''; vat_rate:str=''; levy_rate:str=''
    additional_measures:dict={}; source_system:str=OFFICIAL_TARIFF_SOURCE; source_url:str=OFFICIAL_TARIFF_URL
    tariff_version:str; effective_from:str; effective_to:str=''; snapshot_ref:str
    verified_at:str=''; verified_by:str=''; status:str='UNVERIFIED'

@app.get('/api/v8/tariff-catalog')
def tariff_catalog(hs_code:str='', tariff_version:str='', status:str=''):
    c=db(); q='SELECT * FROM tariff_catalog WHERE 1=1'; args=[]
    if hs_code: q+=' AND hs_code=?'; args.append(hs_code)
    if tariff_version: q+=' AND tariff_version=?'; args.append(tariff_version)
    if status: q+=' AND status=?'; args.append(status)
    q+=' ORDER BY hs_code LIMIT 1000'; out=[dict(r) for r in c.execute(q,args).fetchall()]; c.close()
    for r in out: r['additional_measures']=json.loads(r['additional_measures'] or '{}')
    return {'source':OFFICIAL_TARIFF_SOURCE,'source_url':OFFICIAL_TARIFF_URL,'records':out}

@app.post('/api/v8/tariff-catalog')
def create_tariff_catalog(x:TariffCatalogIn):
    if x.source_system != OFFICIAL_TARIFF_SOURCE: raise HTTPException(400,'Production tariff catalogue must identify the official TANeSW/TRA source')
    if not x.snapshot_ref.strip(): raise HTTPException(400,'snapshot_ref is required')
    c=db(); cur=c.execute("INSERT INTO tariff_catalog(hs_code,description,unit,import_duty_rate,excise_rate,vat_rate,levy_rate,additional_measures,source_system,source_url,tariff_version,effective_from,effective_to,snapshot_ref,verified_at,verified_by,status) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",(x.hs_code,x.description,x.unit,x.import_duty_rate,x.excise_rate,x.vat_rate,x.levy_rate,json.dumps(x.additional_measures),x.source_system,x.source_url,x.tariff_version,x.effective_from,x.effective_to,x.snapshot_ref,x.verified_at or None,x.verified_by or None,x.status)); c.commit(); i=cur.lastrowid; c.close(); audit('TARIFF_CATALOG',i,'CREATE','Admin','Official-source tariff snapshot registered'); return {'id':i,'snapshot_ref':x.snapshot_ref}

class TariffLookupIn(BaseModel): hs_code:str; tariff_version:str; snapshot_ref:str=''
@app.post('/api/v8/tariff-catalog/lookup')
def tariff_lookup(x:TariffLookupIn):
    c=db(); q='SELECT * FROM tariff_catalog WHERE hs_code=? AND tariff_version=?'; args=[x.hs_code,x.tariff_version]
    if x.snapshot_ref: q+=' AND snapshot_ref=?'; args.append(x.snapshot_ref)
    q+=' ORDER BY id DESC LIMIT 1'; r=c.execute(q,args).fetchone(); c.close()
    if not r: raise HTTPException(404,'No tariff snapshot found for requested HS/version')
    out=dict(r); out['additional_measures']=json.loads(out['additional_measures'] or '{}'); return out

@app.get('/api/v8/tariff-governance')
def tariff_governance():
    c=db(); counts={s:c.execute('SELECT COUNT(*) n FROM tariff_catalog WHERE status=?',(s,)).fetchone()['n'] for s in ('VERIFIED','UNVERIFIED','SUPERSEDED')}; versions=[dict(r) for r in c.execute('SELECT tariff_version,MIN(effective_from) effective_from,MAX(effective_to) effective_to,COUNT(*) records FROM tariff_catalog GROUP BY tariff_version ORDER BY tariff_version DESC').fetchall()]; c.close()
    return {'authoritative_source':OFFICIAL_TARIFF_SOURCE,'source_url':OFFICIAL_TARIFF_URL,'integrity_rule':'Production tariff values require official source, snapshot, version and effective date.','counts':counts,'versions':versions}

@app.get('/api/v8/intelligence/overview')
def intelligence_overview():
    c=db(); now=now_utc(); overdue=c.execute("SELECT COUNT(*) n FROM sla_events WHERE status='OPEN' AND due_at < ?",(now,)).fetchone()['n']; customs=c.execute("SELECT COUNT(*) n FROM declarations WHERE status IN ('QUERY','HOLD','REJECTED')").fetchone()['n']; dem=c.execute("SELECT COALESCE(SUM(accrued_amount-waiver_amount),0) n FROM demurrage WHERE status='OPEN'").fetchone()['n']; unresolved=c.execute("SELECT COUNT(*) n FROM reconciliations WHERE status IN ('OPEN','MISMATCH') AND material=1").fetchone()['n']; containers=c.execute("SELECT COUNT(*) n FROM containers WHERE status NOT IN ('DELIVERED','CLOSED')").fetchone()['n']; score=min(100,overdue*12+customs*15+unresolved*18+(20 if float(dem)>0 else 0)); level='CRITICAL' if score>=70 else 'HIGH' if score>=45 else 'MEDIUM' if score>=20 else 'LOW'; reasons=[]
    if overdue: reasons.append(f'{overdue} overdue SLA item(s)')
    if customs: reasons.append(f'{customs} customs blocker(s)')
    if unresolved: reasons.append(f'{unresolved} material reconciliation issue(s)')
    if float(dem)>0: reasons.append('Open demurrage financial exposure')
    action='Prioritise blocking controls and contain financial exposure.' if reasons else 'Routine monitoring.'
    cur=c.execute('INSERT INTO risk_decisions(entity_type,entity_id,score,level,reasons,recommended_action,model_version,created_at) VALUES(?,?,?,?,?,?,?,?)',('CONTROL_TOWER','GLOBAL',score,level,json.dumps(reasons),action,'deterministic-v1',now)); c.commit(); rid=cur.lastrowid; c.close(); return {'decision_id':rid,'score':score,'level':level,'reasons':reasons,'recommended_action':action,'model_version':'deterministic-v1','open_containers':containers,'demurrage_exposure':money(dem),'customs_blockers':customs,'overdue_slas':overdue,'material_reconciliation_issues':unresolved}

@app.get('/api/v8/intelligence/shipment/{shipment_id}')
def shipment_intelligence(shipment_id:str):
    c=db(); sh=c.execute('SELECT * FROM shipments WHERE id=?',(shipment_id,)).fetchone()
    if not sh: c.close(); raise HTTPException(404,'Shipment not found')
    cid=c.execute("SELECT COUNT(*) n FROM containers WHERE shipment_id=? AND status NOT IN ('DELIVERED','CLOSED')",(shipment_id,)).fetchone()['n']; dem=c.execute("SELECT COALESCE(SUM(accrued_amount-waiver_amount),0) n FROM demurrage WHERE shipment_id=? AND status='OPEN'",(shipment_id,)).fetchone()['n']; dec=c.execute("SELECT COUNT(*) n FROM declarations WHERE shipment_id=? AND status IN ('QUERY','HOLD','REJECTED')",(shipment_id,)).fetchone()['n']; rec=c.execute("SELECT COUNT(*) n FROM reconciliations WHERE shipment_id=? AND material=1 AND status IN ('OPEN','MISMATCH')",(shipment_id,)).fetchone()['n']; c.close(); score=min(100,cid*4+(25 if dem else 0)+dec*20+rec*25); level='CRITICAL' if score>=70 else 'HIGH' if score>=45 else 'MEDIUM' if score>=20 else 'LOW'; reasons=[]
    if cid: reasons.append(f'{cid} active container(s)')
    if dem: reasons.append('Open demurrage exposure')
    if dec: reasons.append(f'{dec} customs blocker(s)')
    if rec: reasons.append(f'{rec} material reconciliation issue(s)')
    return {'shipment_id':shipment_id,'score':score,'level':level,'reasons':reasons,'recommended_action':'Prioritise customs/reconciliation blockers and contain financial exposure.' if reasons else 'Routine monitoring.','model_version':'deterministic-v1'}

@app.get('/api/v8/enterprise/manifest')
def enterprise_manifest():
    return {'platform':'Katamba Logistics Control Tower','version':'0.9.0','authoritative_sources':{'tariff':OFFICIAL_TARIFF_SOURCE,'tanesw':OFFICIAL_TARIFF_URL},'customs_procedures':[x[0] for x in PROCEDURES],'corridors':['Dar es Salaam → Tunduma → Zambia','Dar es Salaam → Nakonde → onward destination','Dar es Salaam → Kasumbalesa → DRC'],'controls':['B/L↔Invoice↔Packing List↔Declaration reconciliation','Customs lifecycle','Container 360','Demurrage/waiver','Transit/bond','Evidence','SLA/escalation','RBAC','Audit','Versioned official tariff snapshots','Deterministic risk engine']}


# --- V10 Enterprise Workflow, Task Orchestration & Decision Controls ---
V10_VERSION='1.0.0'
V11_VERSION='1.1.0'

class TaskIn(BaseModel):
    entity_type:str; entity_id:str; task_type:str; title:str; priority:str='MEDIUM'; owner:str=''; due_at:str=''; source_rule:str=''; source_version:str=''; evidence_required:bool=False; blocking:bool=False; notes:str=''
class TaskStatusIn(BaseModel):
    status:str; actor:str='Operator'; notes:str=''
class DocumentRequirementIn(BaseModel):
    procedure_code:str; document_type:str; required:bool=True; source:str=''; version:str=''; effective_from:str=''; effective_to:str=''
V10_ALLOWED_TASK_STATUSES={'OPEN','IN_PROGRESS','BLOCKED','COMPLETED','CANCELLED'}
V10_PRIORITIES={'LOW','MEDIUM','HIGH','CRITICAL'}

def _task_row(r):
    x=dict(r); x['evidence_required']=bool(x['evidence_required']); x['evidence_complete']=bool(x['evidence_complete']); x['blocking']=bool(x['blocking']); return x

@app.get('/api/v10/tasks')
def v10_tasks(status:str='', entity_type:str='', entity_id:str='', limit:int=100):
    limit=max(1,min(limit,500)); c=db(); q='SELECT * FROM operational_tasks WHERE 1=1'; args=[]
    if status: q+=' AND status=?'; args.append(status)
    if entity_type: q+=' AND entity_type=?'; args.append(entity_type)
    if entity_id: q+=' AND entity_id=?'; args.append(entity_id)
    q+=' ORDER BY CASE priority WHEN "CRITICAL" THEN 4 WHEN "HIGH" THEN 3 WHEN "MEDIUM" THEN 2 ELSE 1 END DESC, CASE WHEN due_at IS NULL OR due_at="" THEN 1 ELSE 0 END, due_at ASC LIMIT ?'; args.append(limit)
    out=[_task_row(r) for r in c.execute(q,args).fetchall()]; c.close(); return out

@app.post('/api/v10/tasks')
def v10_create_task(x:TaskIn):
    if x.priority not in V10_PRIORITIES: raise HTTPException(400,'Invalid priority')
    c=db(); cur=c.execute('INSERT INTO operational_tasks(entity_type,entity_id,task_type,title,priority,status,owner,due_at,source_rule,source_version,evidence_required,evidence_complete,blocking,created_at,notes) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(x.entity_type,x.entity_id,x.task_type,x.title,x.priority,'OPEN',x.owner,x.due_at,x.source_rule,x.source_version,int(x.evidence_required),0,int(x.blocking),now_utc(),x.notes)); c.commit(); r=dict(c.execute('SELECT * FROM operational_tasks WHERE id=?',(cur.lastrowid,)).fetchone()); c.close(); audit('TASK',r['id'],'CREATE',x.owner or 'Operator','V10 task created',None,r); return _task_row(r)

@app.patch('/api/v10/tasks/{task_id}')
def v10_update_task(task_id:int,x:TaskStatusIn):
    if x.status not in V10_ALLOWED_TASK_STATUSES: raise HTTPException(400,'Invalid task status')
    c=db(); old=c.execute('SELECT * FROM operational_tasks WHERE id=?',(task_id,)).fetchone()
    if not old: c.close(); raise HTTPException(404,'Task not found')
    if x.status=='COMPLETED' and old['evidence_required'] and not old['evidence_complete']:
        c.close(); raise HTTPException(409,'Required evidence is incomplete; task cannot be completed')
    completed=now_utc() if x.status=='COMPLETED' else None
    c.execute('UPDATE operational_tasks SET status=?,completed_at=?,notes=? WHERE id=?',(x.status,completed,x.notes,task_id)); c.commit(); new=dict(c.execute('SELECT * FROM operational_tasks WHERE id=?',(task_id,)).fetchone()); c.close(); audit('TASK',task_id,'STATUS',x.actor,x.notes,dict(old),new); return _task_row(new)

@app.post('/api/v10/tasks/{task_id}/evidence-complete')
def v10_task_evidence(task_id:int, actor:str='Operator'):
    c=db(); r=c.execute('SELECT * FROM operational_tasks WHERE id=?',(task_id,)).fetchone()
    if not r: c.close(); raise HTTPException(404,'Task not found')
    c.execute('UPDATE operational_tasks SET evidence_complete=1 WHERE id=?',(task_id,)); c.commit(); new=dict(c.execute('SELECT * FROM operational_tasks WHERE id=?',(task_id,)).fetchone()); c.close(); audit('TASK',task_id,'EVIDENCE_COMPLETE',actor,'Evidence requirement marked complete',dict(r),new); return _task_row(new)

@app.get('/api/v10/document-requirements')
def v10_document_requirements(procedure_code:str=''):
    c=db(); q='SELECT * FROM document_requirements'; args=[]
    if procedure_code: q+=' WHERE procedure_code=?'; args.append(procedure_code)
    q+=' ORDER BY procedure_code,document_type'; out=[dict(r) for r in c.execute(q,args).fetchall()]; c.close(); return out

@app.post('/api/v10/document-requirements')
def v10_document_requirement(x:DocumentRequirementIn):
    if x.procedure_code not in dict(PROCEDURES): raise HTTPException(400,'Unknown customs procedure')
    c=db(); c.execute('INSERT INTO document_requirements(procedure_code,document_type,required,source,version,effective_from,effective_to) VALUES(?,?,?,?,?,?,?) ON CONFLICT(procedure_code,document_type) DO UPDATE SET required=excluded.required,source=excluded.source,version=excluded.version,effective_from=excluded.effective_from,effective_to=excluded.effective_to',(x.procedure_code,x.document_type,int(x.required),x.source,x.version,x.effective_from,x.effective_to)); c.commit(); r=dict(c.execute('SELECT * FROM document_requirements WHERE procedure_code=? AND document_type=?',(x.procedure_code,x.document_type)).fetchone()); c.close(); return r

def v10_decl_ready(d):
    return bool(d['procedure_code'] in dict(PROCEDURES) and d['bl'] and d['importer'] and d['hs_code'] and d['origin'] and d['destination'] and float(d['customs_value'] or 0)>=0 and d['status'] not in ('QUERY','HOLD','REJECTED'))

@app.get('/api/v10/shipments/{shipment_id}/readiness')
def v10_shipment_readiness(shipment_id:str):
    c=db(); sh=c.execute('SELECT * FROM shipments WHERE id=?',(shipment_id,)).fetchone()
    if not sh: c.close(); raise HTTPException(404,'Shipment not found')
    decls=[dict(r) for r in c.execute('SELECT * FROM declarations WHERE shipment_id=?',(shipment_id,)).fetchall()]
    docs=[dict(r) for r in c.execute('SELECT * FROM documents WHERE shipment_id=?',(shipment_id,)).fetchall()]
    containers=[dict(r) for r in c.execute('SELECT * FROM containers WHERE shipment_id=?',(shipment_id,)).fetchall()]
    tasks=[_task_row(r) for r in c.execute('SELECT * FROM operational_tasks WHERE entity_type="SHIPMENT" AND entity_id=? AND status NOT IN ("COMPLETED","CANCELLED")',(shipment_id,)).fetchall()]
    recon=[dict(r) for r in c.execute('SELECT material,status FROM reconciliations WHERE shipment_id=?',(shipment_id,)).fetchall()]
    c.close()
    checks=[]
    def check(code,label,ok,blocking=True,detail=''): checks.append({'code':code,'label':label,'ok':bool(ok),'blocking':blocking,'detail':detail})
    check('SHIPMENT','Shipment master data',bool(sh['bl'] and sh['customer']),True,'B/L and customer are required')
    check('CONTAINER','Container linkage',bool(containers) if sh['containers'] else True,True,'Expected container records must be registered')
    req=[]
    if decls:
        d=decls[0]; check('DECLARATION','Declaration readiness',v10_decl_ready(d),True,'Procedure, B/L, importer, HS, origin and destination must be present and no blocker status')
        c2=db(); req=[dict(r) for r in c2.execute('SELECT * FROM document_requirements WHERE procedure_code=? AND required=1',(d['procedure_code'],)).fetchall()]; c2.close()
    else: check('DECLARATION','Declaration exists',False,True,'No declaration linked to shipment')
    present={x['doc_type'] for x in docs if x['status'] not in ('REJECTED','EXPIRED')}
    missing=[x['document_type'] for x in req if x['document_type'] not in present]
    check('DOCUMENTS','Required documents',not missing,True,'Missing: '+', '.join(missing) if missing else 'Complete')
    bad_recon=any(r['material'] and r['status'] in ('OPEN','MISMATCH') for r in recon)
    check('RECON','Material reconciliation',not bad_recon,True,'Resolve material mismatches before closure')
    check('TASKS','Blocking tasks',not any(t['blocking'] for t in tasks),True,'Blocking operational tasks remain open' if tasks else 'No blocking tasks')
    return {'shipment_id':shipment_id,'ready':all(x['ok'] for x in checks if x['blocking']),'checks':checks,'missing_documents':missing,'open_tasks':tasks}

@app.post('/api/v10/shipments/{shipment_id}/control-scan')
def v10_control_scan(shipment_id:str, actor:str='ControlTower'):
    ready=v10_shipment_readiness(shipment_id); c=db(); created=[]
    for chk in ready['checks']:
        if chk['ok']: continue
        existing=c.execute('SELECT id FROM operational_tasks WHERE entity_type="SHIPMENT" AND entity_id=? AND task_type=? AND status NOT IN ("COMPLETED","CANCELLED")',(shipment_id,chk['code'])).fetchone()
        if existing: continue
        cur=c.execute('INSERT INTO operational_tasks(entity_type,entity_id,task_type,title,priority,status,owner,due_at,source_rule,source_version,evidence_required,evidence_complete,blocking,created_at,notes) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',('SHIPMENT',shipment_id,chk['code'],chk['label'],'CRITICAL','OPEN',actor,'','V10_CONTROL_SCAN','1.0.0',0,0,1,now_utc(),chk['detail'])); created.append(cur.lastrowid)
    c.commit(); c.close(); return {'shipment_id':shipment_id,'ready':ready['ready'],'created_task_ids':created,'checks':ready['checks']}

@app.get('/api/v10/control-tower/queue')
def v10_control_queue(limit:int=100):
    limit=max(1,min(limit,500)); c=db(); now=now_utc(); q="SELECT t.*, s.customer, s.bl FROM operational_tasks t LEFT JOIN shipments s ON t.entity_type='SHIPMENT' AND t.entity_id=s.id WHERE t.status NOT IN ('COMPLETED','CANCELLED') ORDER BY CASE t.priority WHEN 'CRITICAL' THEN 4 WHEN 'HIGH' THEN 3 WHEN 'MEDIUM' THEN 2 ELSE 1 END DESC, CASE WHEN t.due_at<>'' AND t.due_at < ? THEN 0 ELSE 1 END, t.due_at ASC LIMIT ?"; out=[dict(r) for r in c.execute(q,(now,limit)).fetchall()]; c.close(); return {'generated_at':now,'items':out,'count':len(out)}

@app.get('/api/v10/quality/summary')
def v10_quality_summary():
    c=db(); now=now_utc(); checks={'material_reconciliation_open':c.execute("SELECT COUNT(*) FROM reconciliations WHERE material=1 AND status IN ('OPEN','MISMATCH')").fetchone()[0],'blocked_tasks':c.execute("SELECT COUNT(*) FROM operational_tasks WHERE blocking=1 AND status NOT IN ('COMPLETED','CANCELLED')").fetchone()[0],'overdue_tasks':c.execute("SELECT COUNT(*) FROM operational_tasks WHERE status NOT IN ('COMPLETED','CANCELLED') AND due_at<>'' AND due_at<?",(now,)).fetchone()[0],'unverified_tariff_records':c.execute("SELECT COUNT(*) FROM tariff_catalog WHERE status<>'VERIFIED'").fetchone()[0],'customs_blockers':c.execute("SELECT COUNT(*) FROM declarations WHERE status IN ('QUERY','HOLD','REJECTED')").fetchone()[0],'orphan_containers':c.execute("SELECT COUNT(*) FROM containers WHERE shipment_id IS NULL OR shipment_id=''").fetchone()[0]}; c.close(); score=max(0,100-sum(min(v*10,30) for v in checks.values())); return {'version':V10_VERSION,'quality_score':score,'checks':checks,'principles':['accuracy_before_speed','evidence_before_assumption','reconciliation_before_submission','official_source_for_regulated_rules','no_silent_overwrite']}

@app.get('/api/v10/enterprise/manifest')
def v10_manifest():
    return {'platform':'Katamba Logistics Control Tower','version':V10_VERSION,'focus':'Enterprise Workflow, Decision Controls & Operational Integrity','customs_procedures':[x[0] for x in PROCEDURES],'official_tariff_source':OFFICIAL_TARIFF_SOURCE,'official_tariff_url':OFFICIAL_TARIFF_URL,'corridors':['Dar es Salaam → Tunduma → Zambia','Dar es Salaam → Nakonde → onward destination','Dar es Salaam → Kasumbalesa → DRC'],'core_controls':['B/L↔Invoice↔Packing List↔Declaration','Customs lifecycle','Document readiness','Container 360','Demurrage/waiver','Transit/bond','SLA/task orchestration','Approval','Evidence','RBAC','Audit','Versioned official tariff snapshots','Deterministic risk engine','No silent regulatory-rule overwrite']}


# --- V11 Enterprise orchestration ---
class ApprovalMatrixIn(BaseModel):
    action_code:str; entity_type:str; role:str; threshold_amount:str=''; currency:str=''; required_count:int=1; version:str='1.0'; source:str=''; effective_from:str=''; effective_to:str=''
class FinanceReconIn(BaseModel):
    shipment_id:str; reference:str; source_type:str; expected_amount:str; actual_amount:str; currency:str='USD'; evidence_ref:str=''
class WorkflowStartIn(BaseModel):
    workflow_code:str; entity_type:str; entity_id:str; actor:str='ControlTower'; data:dict={}
class WorkflowAdvanceIn(BaseModel):
    actor:str='Operator'; outcome:str='COMPLETED'; reason:str=''

@app.get('/api/v11/manifest')
def v11_manifest():
    return {'platform':'Katamba Logistics Control Tower','version':V11_VERSION,'focus':'Advanced Workflow Orchestration, SLA Escalation, Approval Matrix & Financial Reconciliation','preserved_customs_procedures':[x[0] for x in PROCEDURES],'official_tariff_source':OFFICIAL_TARIFF_SOURCE,'controls':['deterministic workflow state','approval matrix','SLA escalation','evidence gates','finance reconciliation','versioned rules','no silent regulatory-rule overwrite']}

@app.get('/api/v11/approval-matrix')
def v11_approval_matrix(action_code:str='',entity_type:str=''):
    c=db(); q='SELECT * FROM approval_matrix WHERE active=1'; a=[]
    if action_code:q+=' AND action_code=?';a.append(action_code)
    if entity_type:q+=' AND entity_type=?';a.append(entity_type)
    out=[dict(r) for r in c.execute(q,a).fetchall()];c.close();return out
@app.post('/api/v11/approval-matrix')
def v11_add_matrix(x:ApprovalMatrixIn):
    if x.required_count<1: raise HTTPException(400,'required_count must be >= 1')
    c=db()
    try:c.execute('INSERT INTO approval_matrix(action_code,entity_type,role,threshold_amount,currency,required_count,active,version,source,effective_from,effective_to) VALUES(?,?,?,?,?,?,?,?,?,?,?)',(x.action_code,x.entity_type,x.role,x.threshold_amount,x.currency,x.required_count,1,x.version,x.source,x.effective_from,x.effective_to));c.commit()
    except sqlite3.IntegrityError:c.close();raise HTTPException(409,'Approval rule already exists for this version')
    r=dict(c.execute('SELECT * FROM approval_matrix WHERE id=last_insert_rowid()').fetchone());c.close();return r

@app.post('/api/v11/workflows/start')
def v11_start_workflow(x:WorkflowStartIn):
    c=db(); w=c.execute('SELECT * FROM workflows WHERE code=? AND status="ACTIVE" ORDER BY id DESC LIMIT 1',(x.workflow_code,)).fetchone()
    if not w:c.close();raise HTTPException(404,'Active workflow not found')
    definition=json.loads(w['definition']);steps=definition.get('steps',[])
    if not steps:c.close();raise HTTPException(400,'Workflow has no steps')
    now=now_utc();cur=c.execute('INSERT INTO workflow_runs(workflow_id,entity_type,entity_id,state,current_step,started_at,updated_at,data) VALUES(?,?,?,?,?,?,?,?)',(w['id'],x.entity_type,x.entity_id,'RUNNING',steps[0]['code'],now,now,json.dumps(x.data)));rid=cur.lastrowid;st=steps[0]
    c.execute('INSERT INTO workflow_queue(workflow_run_id,step_code,entity_type,entity_id,assignee,status,priority,due_at,created_at) VALUES(?,?,?,?,?,?,?,?,?)',(rid,st['code'],x.entity_type,x.entity_id,st.get('assignee',''),'READY',st.get('priority','MEDIUM'),st.get('due_at',''),now));c.commit();c.close();audit('WORKFLOW_RUN',rid,'START',x.actor,'Workflow started');return {'run_id':rid,'state':'RUNNING','current_step':st['code']}

@app.post('/api/v11/workflows/{run_id}/advance')
def v11_advance_workflow(run_id:int,x:WorkflowAdvanceIn):
    c=db();run=c.execute('SELECT * FROM workflow_runs WHERE id=?',(run_id,)).fetchone()
    if not run:c.close();raise HTTPException(404,'Workflow run not found')
    w=c.execute('SELECT * FROM workflows WHERE id=?',(run['workflow_id'],)).fetchone();steps=json.loads(w['definition']).get('steps',[]);idx=next((i for i,z in enumerate(steps) if z['code']==run['current_step']),-1)
    if idx<0:c.close();raise HTTPException(409,'Invalid workflow state')
    if x.outcome!='COMPLETED':return {'run_id':run_id,'state':'RUNNING','current_step':run['current_step']}
    c.execute('UPDATE workflow_queue SET status="COMPLETED",completed_at=? WHERE workflow_run_id=? AND step_code=? AND status="READY"',(now_utc(),run_id,run['current_step']))
    if idx+1>=len(steps):c.execute('UPDATE workflow_runs SET state="COMPLETED",current_step="",updated_at=? WHERE id=?',(now_utc(),run_id));state='COMPLETED';nxt=''
    else:
        nxt=steps[idx+1];c.execute('UPDATE workflow_runs SET current_step=?,updated_at=? WHERE id=?',(nxt['code'],now_utc(),run_id));c.execute('INSERT INTO workflow_queue(workflow_run_id,step_code,entity_type,entity_id,assignee,status,priority,due_at,created_at) VALUES(?,?,?,?,?,?,?,?,?)',(run_id,nxt['code'],run['entity_type'],run['entity_id'],nxt.get('assignee',''),'READY',nxt.get('priority','MEDIUM'),nxt.get('due_at',''),now_utc()));state='RUNNING'
    c.execute('INSERT INTO workflow_actions(workflow_run_id,step_code,action,actor,outcome,reason,created_at) VALUES(?,?,?,?,?,?,?)',(run_id,run['current_step'],'ADVANCE',x.actor,x.outcome,x.reason,now_utc()));c.commit();c.close();audit('WORKFLOW_RUN',run_id,'ADVANCE',x.actor,x.reason);return {'run_id':run_id,'state':state,'current_step':nxt}

@app.get('/api/v11/workflow-queue')
def v11_workflow_queue(limit:int=100):
    limit=max(1,min(limit,500));c=db();out=[dict(r) for r in c.execute('SELECT * FROM workflow_queue WHERE status="READY" ORDER BY CASE priority WHEN "CRITICAL" THEN 4 WHEN "HIGH" THEN 3 WHEN "MEDIUM" THEN 2 ELSE 1 END DESC,due_at LIMIT ?',(limit,)).fetchall()];c.close();return {'items':out,'count':len(out),'generated_at':now_utc()}

@app.post('/api/v11/finance/reconcile')
def v11_finance_reconcile(x:FinanceReconIn):
    try:exp=Decimal(str(x.expected_amount));act=Decimal(str(x.actual_amount));var=(act-exp).quantize(Decimal('0.01'),rounding=ROUND_HALF_UP)
    except:raise HTTPException(400,'Invalid monetary amount')
    status='MATCHED' if var==0 else 'VARIANCE';c=db();cur=c.execute('INSERT INTO finance_reconciliations(shipment_id,reference,source_type,expected_amount,actual_amount,currency,variance,status,evidence_ref,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)',(x.shipment_id,x.reference,x.source_type,str(exp),str(act),x.currency,str(var),status,x.evidence_ref,now_utc()));c.commit();rid=cur.lastrowid;c.close();audit('FINANCE_RECON',rid,'CREATE','Operator',f'Finance reconciliation {status}');return {'id':rid,'status':status,'variance':str(var)}

@app.get('/api/v11/finance/reconciliation/{shipment_id}')
def v11_finance_history(shipment_id:str):return rows('finance_reconciliations','shipment_id=? ORDER BY id DESC',(shipment_id,))

@app.get('/api/v11/escalations/scan')
def v11_escalation_scan():
    c=db();now=now_utc();created=[]
    for t in [dict(r) for r in c.execute("SELECT * FROM operational_tasks WHERE status NOT IN ('COMPLETED','CANCELLED') AND due_at<>'' AND due_at<?",(now,)).fetchall()]:
        exists=c.execute("SELECT 1 FROM notifications WHERE category='ESCALATION' AND entity_id=? AND status='OPEN'",(str(t['id']),)).fetchone()
        if not exists:
            c.execute('INSERT INTO notifications(severity,category,title,message,entity_type,entity_id,created_at) VALUES(?,?,?,?,?,?,?)',('HIGH','ESCALATION','Task escalation',f"Task {t['id']} ({t['title']}) is overdue.",'TASK',str(t['id']),now));created.append(t['id'])
    c.commit();c.close();return {'created_notifications':created,'count':len(created),'scanned_at':now}

@app.get('/api/v11/health/enterprise')
def v11_health():
    c=db();r={'database':bool(c.execute('SELECT 1').fetchone()),'foreign_keys':bool(c.execute('PRAGMA foreign_keys').fetchone()[0]),'wal_mode':c.execute('PRAGMA journal_mode').fetchone()[0].lower()=='wal','approval_rules':c.execute('SELECT COUNT(*) FROM approval_matrix').fetchone()[0],'workflow_ready':c.execute('SELECT COUNT(*) FROM workflow_queue WHERE status="READY"').fetchone()[0]};c.close();return {'version':V11_VERSION,'status':'READY','checks':r}


# --- V12: Autonomous Control Tower, Exception Resolution & Integration Integrity ---
V12_VERSION='1.2.0'
V12_GATES=['IDENTITY','DOCUMENTS','CUSTOMS','RECONCILIATION','RELEASE','EQUIPMENT','TRANSIT','FINANCE']

class ExceptionActionIn(BaseModel):
    exception_id:int; action_code:str; owner:str=''; priority:str='MEDIUM'; due_at:str=''; evidence_required:bool=False
class ExceptionLinkIn(BaseModel):
    exception_id:int; entity_type:str; entity_id:str; relation:str='BLOCKS'
class GateCheckIn(BaseModel):
    entity_type:str; entity_id:str; gate_code:str; status:str; blockers:list[str]=[]; rule_version:str='V12.0'; actor:str='ControlTower'
class IntegrationMessageIn(BaseModel):
    endpoint_code:str; direction:str='INBOUND'; entity_type:str=''; entity_id:str=''; message_type:str; correlation_id:str=''; idempotency_key:str; payload:dict={}
class RouteCheckpointIn(BaseModel):
    shipment_id:str; checkpoint_code:str; sequence_no:int; location:str=''; planned_at:str=''; actual_at:str=''; status:str='PENDING'; source:str='MANUAL'
class ExposureIn(BaseModel):
    shipment_id:str; container_no:str=''; exposure_type:str; amount:str; currency:str='USD'; status:str='OPEN'; source_ref:str=''

@app.get('/api/v12/manifest')
def v12_manifest():
    return {'platform':'Katamba Logistics Control Tower','version':V12_VERSION,'vision':'Autonomous, evidence-driven enterprise logistics control tower','focus':['exception resolution','control gates','integration integrity','route intelligence','financial exposure'],'preserved_customs_procedures':[x[0] for x in PROCEDURES],'official_tariff_source':OFFICIAL_TARIFF_SOURCE,'principles':['evidence before closure','deterministic state','idempotent integration','versioned rules','no invented regulatory rates','audit every material action']}

@app.post('/api/v12/exceptions/actions')
def v12_exception_action(x:ExceptionActionIn):
    c=db()
    if not c.execute('SELECT 1 FROM exceptions WHERE id=?',(x.exception_id,)).fetchone(): c.close(); raise HTTPException(404,'Exception not found')
    cur=c.execute('INSERT INTO exception_actions(exception_id,action_code,owner,status,priority,due_at,evidence_required,evidence_complete,created_at) VALUES(?,?,?,?,?,?,?,?,?)',(x.exception_id,x.action_code,x.owner,'PROPOSED',x.priority,x.due_at,1 if x.evidence_required else 0,0,now_utc()))
    c.commit(); i=cur.lastrowid; c.close(); audit('EXCEPTION_ACTION',i,'CREATE',x.owner or 'ControlTower','Resolution action created'); return {'id':i,'status':'PROPOSED'}

@app.get('/api/v12/exceptions/{exception_id}/actions')
def v12_exception_actions(exception_id:int): return rows('exception_actions','exception_id=? ORDER BY id DESC',(exception_id,))

@app.post('/api/v12/exceptions/links')
def v12_exception_link(x:ExceptionLinkIn):
    c=db()
    if not c.execute('SELECT 1 FROM exceptions WHERE id=?',(x.exception_id,)).fetchone(): c.close(); raise HTTPException(404,'Exception not found')
    try: c.execute('INSERT INTO exception_links(exception_id,entity_type,entity_id,relation,created_at) VALUES(?,?,?,?,?)',(x.exception_id,x.entity_type,x.entity_id,x.relation,now_utc())); c.commit()
    except sqlite3.IntegrityError: c.close(); raise HTTPException(409,'Exception link already exists')
    c.close(); return {'status':'LINKED'}

@app.post('/api/v12/gates/check')
def v12_gate_check(x:GateCheckIn):
    if x.gate_code not in V12_GATES: raise HTTPException(400,'Unknown control gate')
    status=x.status.upper()
    if status not in ('PASS','BLOCKED','PENDING'): raise HTTPException(400,'Gate status must be PASS, BLOCKED or PENDING')
    c=db(); now=now_utc(); blockers=json.dumps(x.blockers)
    c.execute('INSERT INTO control_gates(entity_type,entity_id,gate_code,status,blockers,checked_at,rule_version) VALUES(?,?,?,?,?,?,?) ON CONFLICT(entity_type,entity_id,gate_code) DO UPDATE SET status=excluded.status,blockers=excluded.blockers,checked_at=excluded.checked_at,rule_version=excluded.rule_version',(x.entity_type,x.entity_id,x.gate_code,status,blockers,now,x.rule_version)); c.commit(); c.close(); audit('CONTROL_GATE',f'{x.entity_type}:{x.entity_id}:{x.gate_code}','CHECK',x.actor,f'Gate {status}'); return {'entity_type':x.entity_type,'entity_id':x.entity_id,'gate_code':x.gate_code,'status':status,'blockers':x.blockers}

@app.get('/api/v12/gates/{entity_type}/{entity_id}')
def v12_gates(entity_type:str,entity_id:str):
    data=rows('control_gates','entity_type=? AND entity_id=? ORDER BY gate_code',(entity_type,entity_id))
    for x in data:
        try:x['blockers']=json.loads(x.get('blockers') or '[]')
        except:x['blockers']=[]
    return {'entity_type':entity_type,'entity_id':entity_id,'gates':data,'ready':bool(data) and all(x['status']=='PASS' for x in data)}

@app.post('/api/v12/integrations/messages')
def v12_integration_message(x:IntegrationMessageIn):
    cid=x.correlation_id or str(uuid.uuid4()); now=now_utc(); payload=json.dumps(x.payload,separators=(',',':'))
    c=db(); existing=c.execute('SELECT * FROM integration_messages WHERE idempotency_key=?',(x.idempotency_key,)).fetchone()
    if existing:
        out=dict(existing); c.close(); return {'id':out['id'],'status':out['status'],'idempotent_replay':True,'correlation_id':out['correlation_id']}
    cur=c.execute('INSERT INTO integration_messages(endpoint_code,direction,entity_type,entity_id,message_type,correlation_id,idempotency_key,status,payload,attempts,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',(x.endpoint_code,x.direction,x.entity_type,x.entity_id,x.message_type,cid,x.idempotency_key,'RECEIVED',payload,1,now,now)); c.commit(); i=cur.lastrowid; c.close(); audit('INTEGRATION_MESSAGE',i,'RECEIVE','Integration',f'{x.message_type} received'); return {'id':i,'status':'RECEIVED','correlation_id':cid,'idempotent_replay':False}

@app.get('/api/v12/integrations/messages')
def v12_integration_messages(status:str='',limit:int=100):
    limit=max(1,min(limit,500)); c=db(); q='SELECT * FROM integration_messages'; args=[]
    if status:q+=' WHERE status=?';args.append(status)
    q+=' ORDER BY id DESC LIMIT ?';args.append(limit); out=[dict(r) for r in c.execute(q,args).fetchall()]; c.close(); return {'items':out,'count':len(out)}

@app.post('/api/v12/route/checkpoints')
def v12_route_checkpoint(x:RouteCheckpointIn):
    if x.sequence_no<1: raise HTTPException(400,'sequence_no must be >= 1')
    c=db(); c.execute('INSERT INTO route_checkpoints(shipment_id,checkpoint_code,sequence_no,location,planned_at,actual_at,status,source) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(shipment_id,checkpoint_code) DO UPDATE SET sequence_no=excluded.sequence_no,location=excluded.location,planned_at=excluded.planned_at,actual_at=excluded.actual_at,status=excluded.status,source=excluded.source',(x.shipment_id,x.checkpoint_code,x.sequence_no,x.location,x.planned_at,x.actual_at,x.status,x.source)); c.commit(); c.close(); return {'status':'UPSERTED','shipment_id':x.shipment_id,'checkpoint_code':x.checkpoint_code}

@app.get('/api/v12/route/{shipment_id}')
def v12_route(shipment_id:str):
    cps=rows('route_checkpoints','shipment_id=? ORDER BY sequence_no',(shipment_id,)); now=datetime.now(timezone.utc); overdue=[]
    for x in cps:
        if x.get('status')=='PENDING' and x.get('planned_at'):
            try:
                if datetime.fromisoformat(x['planned_at'].replace('Z','+00:00'))<now: overdue.append(x['checkpoint_code'])
            except: pass
    return {'shipment_id':shipment_id,'checkpoints':cps,'overdue_checkpoints':overdue,'route_risk':'HIGH' if overdue else 'NORMAL'}

@app.post('/api/v12/exposures')
def v12_exposure(x:ExposureIn):
    try: amount=Decimal(x.amount).quantize(Decimal('0.01'),rounding=ROUND_HALF_UP)
    except: raise HTTPException(400,'Invalid exposure amount')
    if amount<0: raise HTTPException(400,'Exposure amount cannot be negative')
    c=db(); cur=c.execute('INSERT INTO cost_exposures(shipment_id,container_no,exposure_type,amount,currency,status,source_ref,created_at) VALUES(?,?,?,?,?,?,?,?)',(x.shipment_id,x.container_no,x.exposure_type,str(amount),x.currency,x.status,x.source_ref,now_utc())); c.commit(); i=cur.lastrowid; c.close(); return {'id':i,'amount':str(amount),'currency':x.currency}

@app.get('/api/v12/exposures/{shipment_id}')
def v12_exposures(shipment_id:str):
    data=rows('cost_exposures','shipment_id=? ORDER BY id DESC',(shipment_id,)); totals={}
    for x in data:
        key=x['currency']; totals[key]=str((Decimal(totals.get(key,'0'))+Decimal(x['amount'])).quantize(Decimal('0.01')))
    return {'shipment_id':shipment_id,'items':data,'totals_by_currency':totals}

@app.post('/api/v12/control-tower/scan')
def v12_control_scan():
    now=now_utc(); created=[]; c=db()
    # Open high/critical exceptions become resolution actions unless already actionable.
    exs=c.execute("SELECT * FROM exceptions WHERE status NOT IN ('CLOSED','RESOLVED') AND severity IN ('HIGH','CRITICAL')").fetchall()
    for e in exs:
        if not c.execute("SELECT 1 FROM exception_actions WHERE exception_id=? AND status IN ('PROPOSED','OPEN','IN_PROGRESS')",(e['id'],)).fetchone():
            due=now; c.execute('INSERT INTO exception_actions(exception_id,action_code,owner,status,priority,due_at,evidence_required,evidence_complete,created_at) VALUES(?,?,?,?,?,?,?,?,?)',(e['id'],'INVESTIGATE',e['owner'] or 'Operations','PROPOSED','HIGH',due,1,0,now)); created.append(e['id'])
    # Open cost exposures create a management notification once per shipment.
    for sh in c.execute("SELECT DISTINCT shipment_id FROM cost_exposures WHERE status='OPEN'").fetchall():
        exists=c.execute("SELECT 1 FROM notifications WHERE category='COST_EXPOSURE' AND entity_id=? AND status='OPEN'",(sh['shipment_id'],)).fetchone()
        if not exists:
            c.execute('INSERT INTO notifications(severity,category,title,message,entity_type,entity_id,created_at) VALUES(?,?,?,?,?,?,?)',('HIGH','COST_EXPOSURE','Open financial exposure',f'Shipment {sh["shipment_id"]} has open cost exposure.','SHIPMENT',sh['shipment_id'],now)); created.append('EXP:'+sh['shipment_id'])
    c.commit(); c.close(); return {'actions_created':created,'count':len(created),'scanned_at':now}

@app.get('/api/v12/health/enterprise')
def v12_health():
    c=db(); checks={'database':bool(c.execute('SELECT 1').fetchone()),'foreign_keys':bool(c.execute('PRAGMA foreign_keys').fetchone()[0]),'wal_mode':c.execute('PRAGMA journal_mode').fetchone()[0].lower()=='wal','v12_tables':all(c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",(t,)).fetchone() for t in ['exception_actions','control_gates','integration_messages','route_checkpoints','cost_exposures']),'open_exposures':c.execute("SELECT COUNT(*) FROM cost_exposures WHERE status='OPEN'").fetchone()[0],'pending_messages':c.execute("SELECT COUNT(*) FROM integration_messages WHERE status NOT IN ('PROCESSED','FAILED')").fetchone()[0]}; c.close(); return {'version':V12_VERSION,'status':'READY' if all(v is True or isinstance(v,int) for v in checks.values()) else 'DEGRADED','checks':checks}


# --- V13 Digital Twin + Predictive Operations ---
V13_VERSION='1.3.0'
# ---------------- Identity & Access ----------------
AUTH_SECRET=os.getenv('KATAMBA_AUTH_SECRET') or 'CHANGE_THIS_IN_PRODUCTION_'+secrets.token_hex(16)
SESSION_HOURS=int(os.getenv('KATAMBA_SESSION_HOURS','12'))
DEFAULT_ADMIN_USERNAME=os.getenv('KATAMBA_ADMIN_USERNAME','admin')
DEFAULT_ADMIN_PASSWORD=os.getenv('KATAMBA_ADMIN_PASSWORD','Katamba@2026!')

def _hash_password(password:str, salt:bytes|None=None):
    salt=salt or secrets.token_bytes(16); dk=hashlib.pbkdf2_hmac('sha256',password.encode(),salt,210000)
    return base64.urlsafe_b64encode(dk).decode(),base64.urlsafe_b64encode(salt).decode()
def _verify_password(password,stored,salt):
    h,_=_hash_password(password,base64.urlsafe_b64decode(salt.encode())); return hmac.compare_digest(h,stored)
def _token_hash(token): return hashlib.sha256(token.encode()).hexdigest()
def _seed_admin():
    c=db(); row=c.execute('SELECT id FROM users WHERE username=?',(DEFAULT_ADMIN_USERNAME,)).fetchone()
    if not row:
        cur=c.execute("INSERT INTO users(username,display_name,role,status,created_at) VALUES(?,?,?,?,?)",(DEFAULT_ADMIN_USERNAME,'Kasto Katamba','SUPER_ADMIN','ACTIVE',now_utc()))
        uid=cur.lastrowid
    else:
        uid=row['id']; c.execute("UPDATE users SET role='SUPER_ADMIN',status='ACTIVE',display_name=COALESCE(display_name,'Kasto Katamba') WHERE id=?",(uid,))
    # Demo/local recovery: ensure the documented bootstrap credential works.
    # Set KATAMBA_RESET_ADMIN_ON_STARTUP=0 in production after creating a real admin password.
    reset_on_startup=os.getenv('KATAMBA_RESET_ADMIN_ON_STARTUP','1').lower() in ('1','true','yes','on')
    if reset_on_startup or not c.execute('SELECT 1 FROM user_credentials WHERE user_id=?',(uid,)).fetchone():
        ph,salt=_hash_password(DEFAULT_ADMIN_PASSWORD); c.execute('INSERT OR REPLACE INTO user_credentials(user_id,password_hash,salt) VALUES(?,?,?)',(uid,ph,salt))
    c.commit(); c.close()
LOCAL_SINGLE_USER_MODE=os.getenv('KATAMBA_SINGLE_USER_MODE','1').lower() in ('1','true','yes','on')
def _current_user(request:Request):
    # Local single-user mode: no login screen is required. Authentication infrastructure
    # remains in place for a future production/RBAC mode.
    if LOCAL_SINGLE_USER_MODE:
        return {'id':1,'username':'local','display_name':'Kasto Katamba','role':'SUPER_ADMIN','status':'ACTIVE','expires_at':'9999-12-31T23:59:59+00:00'}
    token=request.headers.get('Authorization','')
    if not token.startswith('Bearer '): raise HTTPException(401,'Authentication required')
    raw=token[7:].strip(); c=db(); row=c.execute('SELECT u.id,u.username,u.display_name,u.role,u.status,s.expires_at FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=?',(_token_hash(raw),)).fetchone()
    if not row or row['status']!='ACTIVE' or row['expires_at'] < now_utc(): c.close(); raise HTTPException(401,'Session expired or invalid')
    c.execute('UPDATE sessions SET last_seen_at=? WHERE token_hash=?',(now_utc(),_token_hash(raw))); c.commit(); c.close(); return dict(row)
class LoginIn(BaseModel): username:str; password:str
@app.post('/api/auth/login')
def auth_login(x:LoginIn):
    username=x.username.strip().lower()
    c=db(); row=c.execute('SELECT u.*,c.password_hash,c.salt FROM users u JOIN user_credentials c ON c.user_id=u.id WHERE lower(u.username)=?',(username,)).fetchone(); c.close()
    if not row:
        raise HTTPException(401,'Invalid username or password')
    if row['status']!='ACTIVE':
        raise HTTPException(403,'User account is not active')
    if not _verify_password(x.password,row['password_hash'],row['salt']):
        raise HTTPException(401,'Invalid username or password')
    token=secrets.token_urlsafe(48); exp=datetime.now(timezone.utc).timestamp()+SESSION_HOURS*3600; expires=datetime.fromtimestamp(exp,timezone.utc).isoformat(); now=now_utc(); c=db(); c.execute('INSERT INTO sessions(token_hash,user_id,expires_at,created_at,last_seen_at) VALUES(?,?,?,?,?)',(_token_hash(token),row['id'],expires,now,now)); c.execute('INSERT INTO audit(entity,entity_id,action,user,reason,created_at) VALUES(?,?,?,?,?,?)',('AUTH',str(row['id']),'LOGIN',row['username'],'Successful login',now)); c.commit(); c.close(); return {'access_token':token,'token_type':'bearer','expires_at':expires,'user':{'id':row['id'],'username':row['username'],'display_name':row['display_name'],'role':row['role']}}
@app.post('/api/auth/logout')
def auth_logout(request:Request):
    token=request.headers.get('Authorization',''); c=db();
    if token.startswith('Bearer '): c.execute('DELETE FROM sessions WHERE token_hash=?',(_token_hash(token[7:].strip()),)); c.commit()
    c.close(); return {'ok':True}
@app.get('/api/auth/me')
def auth_me(request:Request): return {'user':_current_user(request)}
@app.get('/api/auth/health')
def auth_health():
    c=db(); users=c.execute('SELECT COUNT(*) n FROM users').fetchone()['n']; sessions=c.execute('SELECT COUNT(*) n FROM sessions').fetchone()['n']; c.close(); return {'status':'READY','users':users,'sessions':sessions,'default_admin':DEFAULT_ADMIN_USERNAME}

@app.get('/api/auth/bootstrap-status')
def auth_bootstrap_status():
    return {'status':'READY','username':DEFAULT_ADMIN_USERNAME,'bootstrap_login_enabled':os.getenv('KATAMBA_RESET_ADMIN_ON_STARTUP','1').lower() in ('1','true','yes','on'),'message':'Use the bootstrap credentials once, then change the password in production.'}

def init_v13():
    c=db(); c.executescript("""
    CREATE TABLE IF NOT EXISTS twin_snapshots(id INTEGER PRIMARY KEY AUTOINCREMENT, entity_type TEXT NOT NULL, entity_id TEXT NOT NULL, state TEXT NOT NULL, health_score REAL DEFAULT 100, risk_score REAL DEFAULT 0, eta TEXT, location TEXT, blockers TEXT, model_version TEXT NOT NULL, captured_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS eta_predictions(id INTEGER PRIMARY KEY AUTOINCREMENT, shipment_id TEXT NOT NULL, predicted_eta TEXT NOT NULL, confidence REAL NOT NULL, method TEXT NOT NULL, model_version TEXT NOT NULL, factors TEXT, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS risk_v2(id INTEGER PRIMARY KEY AUTOINCREMENT, entity_type TEXT NOT NULL, entity_id TEXT NOT NULL, score REAL NOT NULL, level TEXT NOT NULL, factors TEXT NOT NULL, recommended_actions TEXT NOT NULL, model_version TEXT NOT NULL, calculated_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS event_stream_offsets(consumer TEXT PRIMARY KEY, last_event_id INTEGER DEFAULT 0, updated_at TEXT NOT NULL);
    CREATE INDEX IF NOT EXISTS idx_twin_entity ON twin_snapshots(entity_type,entity_id,captured_at DESC);
    CREATE INDEX IF NOT EXISTS idx_eta_shipment ON eta_predictions(shipment_id,created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_risk2_entity ON risk_v2(entity_type,entity_id,calculated_at DESC);
    CREATE INDEX IF NOT EXISTS idx_events_stream ON events(id,event_time);
    """); c.commit(); c.close()
init_v13()
class EtaIn(BaseModel):
    shipment_id:str; predicted_eta:str; confidence:float=0.0; method:str='RULE_BASED'; factors:dict={}; model_version:str='eta-v1'
class Risk2In(BaseModel):
    entity_type:str; entity_id:str; score:float; level:str; factors:list[dict]=[]; recommended_actions:list[str]=[]; model_version:str='risk-v2'
class TwinIn(BaseModel):
    entity_type:str; entity_id:str; state:dict={}; health_score:float=100; risk_score:float=0; eta:str=''; location:str=''; blockers:list[str]=[]; model_version:str='twin-v1'
@app.post('/api/v13/eta/predictions')
def v13_eta(x:EtaIn):
    if not 0 <= x.confidence <= 1: raise HTTPException(400,'confidence must be between 0 and 1')
    c=db(); cur=c.execute('INSERT INTO eta_predictions(shipment_id,predicted_eta,confidence,method,model_version,factors,created_at) VALUES(?,?,?,?,?,?,?)',(x.shipment_id,x.predicted_eta,x.confidence,x.method,x.model_version,json.dumps(x.factors,separators=(',',':')),now_utc())); c.commit(); i=cur.lastrowid; c.close(); return {'id':i,'shipment_id':x.shipment_id,'predicted_eta':x.predicted_eta,'confidence':x.confidence,'model_version':x.model_version}
@app.get('/api/v13/eta/{shipment_id}')
def v13_eta_get(shipment_id:str): return {'shipment_id':shipment_id,'predictions':rows('eta_predictions','shipment_id=? ORDER BY id DESC LIMIT 50',(shipment_id,))}
@app.post('/api/v13/risk/calculate')
def v13_risk(x:Risk2In):
    score=max(0,min(100,float(x.score))); level=x.level.upper()
    if level not in {'LOW','MEDIUM','HIGH','CRITICAL'}: raise HTTPException(400,'Invalid risk level')
    c=db(); cur=c.execute('INSERT INTO risk_v2(entity_type,entity_id,score,level,factors,recommended_actions,model_version,calculated_at) VALUES(?,?,?,?,?,?,?,?)',(x.entity_type,x.entity_id,score,level,json.dumps(x.factors,separators=(',',':')),json.dumps(x.recommended_actions,separators=(',',':')),x.model_version,now_utc())); c.commit(); i=cur.lastrowid; c.close(); return {'id':i,'score':score,'level':level,'model_version':x.model_version}
@app.get('/api/v13/risk/{entity_type}/{entity_id}')
def v13_risk_get(entity_type:str,entity_id:str): return {'entity_type':entity_type,'entity_id':entity_id,'decisions':rows('risk_v2','entity_type=? AND entity_id=? ORDER BY id DESC LIMIT 20',(entity_type,entity_id))}
@app.post('/api/v13/digital-twin/snapshot')
def v13_twin(x:TwinIn):
    if not 0 <= x.health_score <= 100 or not 0 <= x.risk_score <= 100: raise HTTPException(400,'scores must be 0..100')
    c=db(); cur=c.execute('INSERT INTO twin_snapshots(entity_type,entity_id,state,health_score,risk_score,eta,location,blockers,model_version,captured_at) VALUES(?,?,?,?,?,?,?,?,?,?)',(x.entity_type,x.entity_id,json.dumps(x.state,separators=(',',':')),x.health_score,x.risk_score,x.eta,x.location,json.dumps(x.blockers),x.model_version,now_utc())); c.commit(); i=cur.lastrowid; c.close(); return {'id':i,'entity_type':x.entity_type,'entity_id':x.entity_id}
@app.get('/api/v13/digital-twin/{entity_type}/{entity_id}')
def v13_twin_get(entity_type:str,entity_id:str):
    data=rows('twin_snapshots','entity_type=? AND entity_id=? ORDER BY id DESC LIMIT 25',(entity_type,entity_id)); return {'entity_type':entity_type,'entity_id':entity_id,'latest':data[0] if data else None,'history':data}
@app.get('/api/v13/event-stream')
def v13_event_stream(after_id:int=0,limit:int=100):
    limit=max(1,min(limit,500)); c=db(); out=[dict(r) for r in c.execute('SELECT * FROM events WHERE id>? ORDER BY id ASC LIMIT ?',(after_id,limit)).fetchall()]; c.close(); return {'events':out,'next_after_id':out[-1]['id'] if out else after_id,'count':len(out)}
@app.get('/api/v13/command-centre')
def v13_command_centre():
    c=db(); critical=c.execute("SELECT COUNT(*) n FROM exceptions WHERE status='OPEN' AND severity='CRITICAL'").fetchone()['n']; high=c.execute("SELECT COUNT(*) n FROM exceptions WHERE status='OPEN' AND severity='HIGH'").fetchone()['n']; overdue=c.execute("SELECT COUNT(*) n FROM operational_tasks WHERE status NOT IN ('COMPLETED','CLOSED') AND due_at IS NOT NULL AND due_at < ?",(now_utc(),)).fetchone()['n']; pending=c.execute("SELECT COUNT(*) n FROM integration_messages WHERE status NOT IN ('PROCESSED','FAILED')").fetchone()['n']; open_exp=c.execute("SELECT currency, SUM(CAST(amount AS REAL)) total FROM cost_exposures WHERE status='OPEN' GROUP BY currency").fetchall(); latest_risk=[dict(r) for r in c.execute('SELECT * FROM risk_v2 ORDER BY id DESC LIMIT 20').fetchall()]; c.close(); return {'version':V13_VERSION,'posture':{'critical_exceptions':critical,'high_exceptions':high,'overdue_tasks':overdue,'pending_integrations':pending,'open_exposure':{r['currency']:round(r['total'] or 0,2) for r in open_exp}},'latest_risks':latest_risk,'principle':'decision support requires evidence and authorised rules'}
@app.get('/api/v13/health')
def v13_health():
    c=db(); required=['twin_snapshots','eta_predictions','risk_v2','event_stream_offsets']; checks={t:bool(c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",(t,)).fetchone()) for t in required}; checks['foreign_keys']=bool(c.execute('PRAGMA foreign_keys').fetchone()[0]); checks['wal']=c.execute('PRAGMA journal_mode').fetchone()[0].lower()=='wal'; c.close(); return {'version':V13_VERSION,'status':'READY' if all(checks.values()) else 'DEGRADED','checks':checks}


# ---------------- V14: REAL-TIME COMMAND CENTRE / MAP / CALENDAR ----------------
V14_VERSION='1.4.0'
class MapLinkIn(BaseModel):
    origin:str='Dar es Salaam, Tanzania'; destination:str; waypoints:list[str]=[]
@app.get('/api/v14/health')
def v14_health():
    c=db(); fk=bool(c.execute('PRAGMA foreign_keys').fetchone()[0]); wal=c.execute('PRAGMA journal_mode').fetchone()[0].lower()=='wal'; tables=[r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()]; c.close(); return {'version':V14_VERSION,'status':'READY' if fk and wal else 'DEGRADED','checks':{'database':True,'foreign_keys':fk,'wal':wal,'frontend_same_origin':True},'tables':len(tables)}
@app.get('/api/v14/clock')
def v14_clock(): return {'utc':now_utc(),'timezone':'Africa/Dar_es_Salaam','note':'Operational timestamps are stored in UTC; UI converts for display.'}
@app.get('/api/v14/map/trip/{sn}')
def v14_trip_map(sn:int):
    c=db(); r=c.execute('SELECT * FROM trips WHERE sn=?',(sn,)).fetchone(); c.close()
    if not r: raise HTTPException(404,'Trip not found')
    x=dict(r); origin='Dar es Salaam, Tanzania'; destination=x.get('location') or 'Dar es Salaam, Tanzania';
    waypoints=[w for w in ['Tunduma, Tanzania','Nakonde, Zambia','Kasumbalesa, Zambia'] if w.lower() not in destination.lower()]
    import urllib.parse
    url='https://www.google.com/maps/dir/?api=1&origin='+urllib.parse.quote(origin)+'&destination='+urllib.parse.quote(destination)+'&waypoints='+urllib.parse.quote('|'.join(waypoints))
    return {'trip':x,'google_maps_url':url,'route':['Dar es Salaam','Tunduma','Nakonde','Zambia','Kasumbalesa','DRC','Destination']}
@app.get('/api/v14/calendar/trucking')
def v14_calendar(start_date:str|None=None,end_date:str|None=None):
    c=db(); rs=[dict(r) for r in c.execute("SELECT sn,truck,container,bl,location,status,dispatch,tunduma_arrival,nakonde_arrival,zambia_arrival,drc_arrival,arrival,offloaded FROM trips ORDER BY sn").fetchall()]; c.close()
    events=[]
    fields=[('dispatch','DISPATCH'),('tunduma_arrival','TUNDUMA ARRIVAL'),('nakonde_arrival','NAKONDE ARRIVAL'),('zambia_arrival','ZAMBIA ARRIVAL'),('drc_arrival','DRC ARRIVAL'),('arrival','DESTINATION ARRIVAL'),('offloaded','OFFLOADED')]
    for r in rs:
        for f,label in fields:
            if r.get(f): events.append({'trip_sn':r['sn'],'container':r['container'],'bl':r['bl'],'truck':r['truck'],'type':label,'time':r[f],'location':r['location'],'status':r['status']})
    return {'timezone':'Africa/Dar_es_Salaam','events':events}
@app.get('/api/v14/command-centre')
def v14_command():
    c=db(); trips=c.execute("SELECT COUNT(*) n FROM trips").fetchone()['n']; active=c.execute("SELECT COUNT(*) n FROM trips WHERE status NOT IN ('OFFLOADED','DELIVERED','CLOSED')").fetchone()['n']; open_exc=c.execute("SELECT COUNT(*) n FROM exceptions WHERE status='OPEN'").fetchone()['n']; c.close(); return {'version':V14_VERSION,'live':True,'trucking':{'total':trips,'active':active},'exceptions_open':open_exc,'maps':'google-maps-links','calendar':'trucking-milestones','time_zone':'Africa/Dar_es_Salaam'}


# ---------------- V16: REAL-TIME GPS / EVENT INTELLIGENCE ----------------
V16_VERSION='1.6.0'

def init_v16():
    c=db()
    c.executescript('''
    CREATE TABLE IF NOT EXISTS gps_positions(id INTEGER PRIMARY KEY AUTOINCREMENT, trip_sn INTEGER NOT NULL, latitude REAL NOT NULL, longitude REAL NOT NULL, recorded_at TEXT NOT NULL, source TEXT NOT NULL, accuracy_m REAL, speed_kph REAL, heading_deg REAL, payload TEXT, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS geofences(id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT UNIQUE NOT NULL, name TEXT NOT NULL, latitude REAL NOT NULL, longitude REAL NOT NULL, radius_km REAL NOT NULL, sequence_no INTEGER, status TEXT DEFAULT 'ACTIVE');
    CREATE TABLE IF NOT EXISTS route_events(id INTEGER PRIMARY KEY AUTOINCREMENT, trip_sn INTEGER NOT NULL, event_code TEXT NOT NULL, checkpoint TEXT, event_time TEXT NOT NULL, source TEXT NOT NULL, confidence REAL DEFAULT 1, created_at TEXT NOT NULL, UNIQUE(trip_sn,event_code,event_time));
    CREATE TABLE IF NOT EXISTS operational_alerts(id INTEGER PRIMARY KEY AUTOINCREMENT, severity TEXT NOT NULL, category TEXT NOT NULL, entity_type TEXT NOT NULL, entity_id TEXT NOT NULL, title TEXT NOT NULL, message TEXT NOT NULL, status TEXT DEFAULT 'OPEN', dedupe_key TEXT UNIQUE, created_at TEXT NOT NULL, acknowledged_at TEXT);
    CREATE TABLE IF NOT EXISTS eta_forecasts(id INTEGER PRIMARY KEY AUTOINCREMENT, trip_sn INTEGER NOT NULL, predicted_eta TEXT NOT NULL, confidence REAL NOT NULL, method TEXT NOT NULL, factors TEXT, model_version TEXT NOT NULL, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS demurrage_forecasts(id INTEGER PRIMARY KEY AUTOINCREMENT, container_no TEXT NOT NULL, forecast_date TEXT NOT NULL, projected_amount TEXT NOT NULL, currency TEXT NOT NULL, chargeable_days INTEGER NOT NULL, method TEXT NOT NULL, rule_version TEXT NOT NULL, created_at TEXT NOT NULL);
    CREATE INDEX IF NOT EXISTS idx_gps_trip_time ON gps_positions(trip_sn, recorded_at DESC);
    CREATE INDEX IF NOT EXISTS idx_route_trip_time ON route_events(trip_sn, event_time DESC);
    CREATE INDEX IF NOT EXISTS idx_alert_status ON operational_alerts(status, severity, created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_eta_trip ON eta_forecasts(trip_sn, created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_dem_forecast_container ON demurrage_forecasts(container_no, created_at DESC);
    ''')
    # Corridor geofences are operational reference points; coordinates are configuration, not customs/legal rules.
    for code,name,lat,lon,radius,seq in [
        ('DAR','Dar es Salaam',-6.7924,39.2083,20,1),('TUNDUMA','Tunduma',-9.3036,32.7667,15,2),
        ('NAKONDE','Nakonde',-9.3425,32.7569,15,3),('KASUMBALESA','Kasumbalesa',-12.5736,28.9769,15,4),('LUBUMBASHI','Lubumbashi',-11.6876,27.5026,25,5)]:
        c.execute('INSERT OR IGNORE INTO geofences(code,name,latitude,longitude,radius_km,sequence_no) VALUES(?,?,?,?,?,?)',(code,name,lat,lon,radius,seq))
    c.commit(); c.close()
init_v16()

class GPSIn(BaseModel):
    trip_sn:int; latitude:float; longitude:float; recorded_at:str=''; source:str='MANUAL'; accuracy_m:float|None=None; speed_kph:float|None=None; heading_deg:float|None=None; payload:dict={}
class ETAForecastIn(BaseModel):
    trip_sn:int; predicted_eta:str; confidence:float=0.0; method:str='RULE_BASED'; factors:dict={}; model_version:str='eta-v2'

def _haversine_km(lat1,lon1,lat2,lon2):
    import math
    r=6371.0088; p1=math.radians(lat1); p2=math.radians(lat2); dp=math.radians(lat2-lat1); dl=math.radians(lon2-lon1)
    a=math.sin(dp/2)**2+math.cos(p1)*math.cos(p2)*math.sin(dl/2)**2
    return 2*r*math.asin(math.sqrt(a))

@app.get('/api/v16/health')
def v16_health():
    c=db(); required=['gps_positions','geofences','route_events','operational_alerts','eta_forecasts','demurrage_forecasts']; checks={t:bool(c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",(t,)).fetchone()) for t in required}; fk=bool(c.execute('PRAGMA foreign_keys').fetchone()[0]); wal=c.execute('PRAGMA journal_mode').fetchone()[0].lower()=='wal'; c.close(); return {'version':V16_VERSION,'status':'READY' if all(checks.values()) and fk and wal else 'DEGRADED','checks':{**checks,'foreign_keys':fk,'wal':wal}}

@app.post('/api/v16/gps/position')
def v16_gps(x:GPSIn):
    if not -90<=x.latitude<=90 or not -180<=x.longitude<=180: raise HTTPException(400,'Invalid coordinates')
    c=db(); trip=c.execute('SELECT * FROM trips WHERE sn=?',(x.trip_sn,)).fetchone()
    if not trip: c.close(); raise HTTPException(404,'Trip not found')
    ts=x.recorded_at or now_utc(); cur=c.execute('INSERT INTO gps_positions(trip_sn,latitude,longitude,recorded_at,source,accuracy_m,speed_kph,heading_deg,payload,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)',(x.trip_sn,x.latitude,x.longitude,ts,x.source,x.accuracy_m,x.speed_kph,x.heading_deg,json.dumps(x.payload,separators=(',',':')),now_utc()))
    c.execute('UPDATE trips SET location=? WHERE sn=?',(f'{x.latitude:.6f},{x.longitude:.6f}',x.trip_sn))
    c.execute('INSERT INTO events(event_type,entity_type,entity_id,event_time,location,source,payload,created_at) VALUES(?,?,?,?,?,?,?,?)',('GPS_POSITION','TRIP',str(x.trip_sn),ts,f'{x.latitude:.6f},{x.longitude:.6f}',x.source,json.dumps({'accuracy_m':x.accuracy_m,'speed_kph':x.speed_kph},separators=(',',':')),now_utc()))
    c.commit(); i=cur.lastrowid; c.close(); return {'id':i,'trip_sn':x.trip_sn,'recorded_at':ts,'location':{'latitude':x.latitude,'longitude':x.longitude},'status':'ACCEPTED'}

@app.get('/api/v16/gps/trip/{trip_sn}')
def v16_gps_get(trip_sn:int,limit:int=100):
    limit=max(1,min(limit,500)); c=db(); data=[dict(r) for r in c.execute('SELECT * FROM gps_positions WHERE trip_sn=? ORDER BY recorded_at DESC LIMIT ?',(trip_sn,limit)).fetchall()]; c.close(); return {'trip_sn':trip_sn,'positions':data}

@app.get('/api/v16/geofences')
def v16_geofences(): return {'version':V16_VERSION,'geofences':rows('geofences','status=? ORDER BY sequence_no',('ACTIVE',))}

@app.get('/api/v16/trip/{trip_sn}/live')
def v16_trip_live(trip_sn:int):
    c=db(); trip=c.execute('SELECT * FROM trips WHERE sn=?',(trip_sn,)).fetchone();
    if not trip: c.close(); raise HTTPException(404,'Trip not found')
    pos=c.execute('SELECT * FROM gps_positions WHERE trip_sn=? ORDER BY recorded_at DESC LIMIT 1',(trip_sn,)).fetchone(); events=[dict(r) for r in c.execute('SELECT * FROM route_events WHERE trip_sn=? ORDER BY event_time DESC LIMIT 20',(trip_sn,)).fetchall()]; alerts=[dict(r) for r in c.execute("SELECT * FROM operational_alerts WHERE entity_type='TRIP' AND entity_id=? AND status='OPEN' ORDER BY id DESC",(str(trip_sn),)).fetchall()]; c.close();
    return {'trip':dict(trip),'latest_position':dict(pos) if pos else None,'route_events':events,'alerts':alerts,'maps_url':('https://www.google.com/maps/dir/?api=1&origin=Dar%20es%20Salaam%2C%20Tanzania&destination=Lubumbashi%2C%20DRC&waypoints=Tunduma%2C%20Tanzania%7CNakonde%2C%20Zambia%7CKasumbalesa%2C%20Zambia'),'timezone':'Africa/Dar_es_Salaam'}

@app.post('/api/v16/eta/forecast')
def v16_eta(x:ETAForecastIn):
    if not 0<=x.confidence<=1: raise HTTPException(400,'confidence must be between 0 and 1')
    c=db(); trip=c.execute('SELECT sn FROM trips WHERE sn=?',(x.trip_sn,)).fetchone();
    if not trip: c.close(); raise HTTPException(404,'Trip not found')
    cur=c.execute('INSERT INTO eta_forecasts(trip_sn,predicted_eta,confidence,method,factors,model_version,created_at) VALUES(?,?,?,?,?,?,?)',(x.trip_sn,x.predicted_eta,x.confidence,x.method,json.dumps(x.factors,separators=(',',':')),x.model_version,now_utc())); c.commit(); i=cur.lastrowid; c.close(); return {'id':i,'trip_sn':x.trip_sn,'predicted_eta':x.predicted_eta,'confidence':x.confidence,'model_version':x.model_version}

@app.get('/api/v16/eta/trip/{trip_sn}')
def v16_eta_get(trip_sn:int): return {'trip_sn':trip_sn,'forecasts':rows('eta_forecasts','trip_sn=? ORDER BY id DESC LIMIT 20',(trip_sn,))}

@app.get('/api/v16/demurrage/forecast/{container_no}')
def v16_dem_forecast(container_no:str):
    c=db(); d=c.execute('SELECT * FROM demurrage WHERE container_no=? ORDER BY id DESC LIMIT 1',(container_no,)).fetchone(); c.close()
    if not d: raise HTTPException(404,'Demurrage record not found')
    d=dict(d); chargeable=int(d.get('chargeable_days') or 0); amount=Decimal(str(d.get('accrued_amount') or 0)); forecast=amount
    if d.get('end_date') and d.get('start_date'): forecast=amount
    return {'container_no':container_no,'current_chargeable_days':chargeable,'current_amount':str(amount),'projected_amount':str(forecast),'currency':d.get('currency') or 'USD','method':'CURRENT_OFFICIAL_RULE_RECORD','rule_version':d.get('tariff_code') or 'UNSPECIFIED','warning':'Projection uses the stored rule record; no tariff is inferred.'}

@app.get('/api/v16/alerts')
def v16_alerts(status:str='OPEN',limit:int=100):
    limit=max(1,min(limit,500)); return {'alerts':rows('operational_alerts',"status=? ORDER BY CASE severity WHEN 'CRITICAL' THEN 1 WHEN 'HIGH' THEN 2 WHEN 'MEDIUM' THEN 3 ELSE 4 END,id DESC LIMIT ?",(status,limit))}

@app.get('/api/v16/command-centre')
def v16_command():
    c=db(); active=c.execute("SELECT COUNT(*) n FROM trips WHERE status NOT IN ('OFFLOADED','DELIVERED','CLOSED')").fetchone()['n']; gps=c.execute('SELECT COUNT(*) n FROM gps_positions').fetchone()['n']; alerts=c.execute("SELECT COUNT(*) n FROM operational_alerts WHERE status='OPEN'").fetchone()['n']; high=c.execute("SELECT COUNT(*) n FROM operational_alerts WHERE status='OPEN' AND severity IN ('HIGH','CRITICAL')").fetchone()['n']; c.close(); return {'version':V16_VERSION,'live':True,'trucking':{'active':active},'gps_positions':gps,'open_alerts':alerts,'high_critical_alerts':high,'maps':'Google Maps directions integration','calendar':'Trucking milestones','timezone':'Africa/Dar_es_Salaam','architecture':'GPS → Event Stream → Digital Twin → ETA → Risk → Alert → Command Centre'}


# ---------------- V17: LCT 2.0 MISSION CONTROL / FINAL NORTH STAR ----------------
V17_VERSION='2.0.0'
V17_NAME='Katamba Logistics Control Tower — Mission Control'

@app.get('/api/v17/health')
def v17_health():
    c=db()
    required=['shipments','containers','trips','declarations','documents','demurrage','events','gps_positions','geofences','eta_forecasts','demurrage_forecasts','operational_alerts','operational_tasks','tariff_catalog','audit']
    checks={t:bool(c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",(t,)).fetchone()) for t in required}
    fk=bool(c.execute('PRAGMA foreign_keys').fetchone()[0]); wal=c.execute('PRAGMA journal_mode').fetchone()[0].lower()=='wal'
    c.close()
    return {'version':V17_VERSION,'name':V17_NAME,'status':'READY' if all(checks.values()) and fk and wal else 'DEGRADED','checks':{**checks,'foreign_keys':fk,'wal':wal},'principles':['official-source rules','evidence-first','decimal finance','immutable audit intent','idempotent events','UTC storage','Africa/Dar_es_Salaam display']}

def _maps_url(destination='Lubumbashi, DRC'):
    return 'https://www.google.com/maps/dir/?api=1&origin='+__import__('urllib.parse').parse.quote('Dar es Salaam, Tanzania')+'&destination='+__import__('urllib.parse').parse.quote(destination)+'&waypoints='+__import__('urllib.parse').parse.quote('Tunduma, Tanzania|Nakonde, Zambia|Kasumbalesa, Zambia')

@app.get('/api/v17/mission-control')
def v17_mission_control(request:Request):
    _current_user(request)
    c=db()
    shipments=c.execute('SELECT COUNT(*) n FROM shipments').fetchone()['n']
    containers=c.execute('SELECT COUNT(*) n FROM containers').fetchone()['n']
    active_trucks=c.execute("SELECT COUNT(*) n FROM trips WHERE status NOT IN ('OFFLOADED','DELIVERED','CLOSED')").fetchone()['n']
    open_exceptions=c.execute("SELECT COUNT(*) n FROM exceptions WHERE status NOT IN ('CLOSED','RESOLVED')").fetchone()['n']
    open_alerts=c.execute("SELECT COUNT(*) n FROM operational_alerts WHERE status='OPEN'").fetchone()['n']
    critical_alerts=c.execute("SELECT COUNT(*) n FROM operational_alerts WHERE status='OPEN' AND severity='CRITICAL'").fetchone()['n']
    overdue_tasks=c.execute("SELECT COUNT(*) n FROM operational_tasks WHERE status NOT IN ('COMPLETED','CLOSED') AND due_at IS NOT NULL AND due_at < ?",(now_utc(),)).fetchone()['n']
    open_dem=c.execute("SELECT COUNT(*) n FROM demurrage WHERE status='OPEN'").fetchone()['n']
    unverified_tariffs=c.execute("SELECT COUNT(*) n FROM tariff_catalog WHERE status!='VERIFIED'").fetchone()['n']
    gps=c.execute('SELECT COUNT(*) n FROM gps_positions').fetchone()['n']
    latest=c.execute('SELECT id,bl,customer,destination,status,created_at FROM shipments ORDER BY created_at DESC LIMIT 20').fetchall()
    risk_rows=[]
    for x in c.execute("SELECT severity,title,description,status FROM exceptions WHERE status NOT IN ('CLOSED','RESOLVED') ORDER BY CASE severity WHEN 'CRITICAL' THEN 1 WHEN 'HIGH' THEN 2 WHEN 'MEDIUM' THEN 3 ELSE 4 END, id DESC LIMIT 20").fetchall():
        risk_rows.append({'severity':x['severity'],'message':x['title'] or x['description'] or 'Open exception','entity':'EXCEPTION'})
    for x in c.execute("SELECT severity,title,message FROM operational_alerts WHERE status='OPEN' ORDER BY CASE severity WHEN 'CRITICAL' THEN 1 WHEN 'HIGH' THEN 2 WHEN 'MEDIUM' THEN 3 ELSE 4 END, id DESC LIMIT 20").fetchall():
        risk_rows.append({'severity':x['severity'],'message':x['title'] or x['message'] or 'Operational alert','entity':'ALERT'})
    c.close()
    return {'version':V17_VERSION,'mode':'MISSION_CONTROL','posture':{'shipments':shipments,'containers':containers,'active_trucks':active_trucks,'open_exceptions':open_exceptions,'open_alerts':open_alerts,'critical_alerts':critical_alerts,'overdue_tasks':overdue_tasks,'open_demurrage':open_dem,'unverified_tariffs':unverified_tariffs,'gps_events':gps},'corridor':['Dar es Salaam','Tunduma','Nakonde','Zambia','Kasumbalesa','DRC','Destination'],'timezone':'Africa/Dar_es_Salaam','maps_url':_maps_url(),'shipments': [dict(x) for x in latest],'risks':risk_rows[:20]}

@app.get('/api/v17/shipment/{shipment_id}/360')
def v17_shipment_360(shipment_id:str, request:Request):
    _current_user(request)
    c=db()
    try:
        data=_shipment_twin(c,shipment_id)
        trips=data['trips']
        trip_ids=[x['sn'] for x in trips]
        gps=[]
        if trip_ids:
            q=','.join('?' for _ in trip_ids)
            gps=[dict(r) for r in c.execute(f'SELECT * FROM gps_positions WHERE trip_sn IN ({q}) ORDER BY recorded_at DESC LIMIT 50',tuple(trip_ids)).fetchall()]
        return {'version':V17_VERSION,'shipment':data['shipment'],'digital_twin':data['digital_twin'],'containers':data['containers'],'trucking':trips,'customs':data['declarations'],'documents':data['documents'],'demurrage':data['demurrage'],'events':data['events'],'exposures':data['exposures'],'tasks':data['open_tasks'],'eta':data['eta'],'risk':data['latest_risk'],'gps':gps,'maps_url':_maps_url(data['shipment'].get('destination') or 'Lubumbashi, DRC'),'calendar_timezone':'Africa/Dar_es_Salaam'}
    finally: c.close()

@app.get('/api/v17/tariff-governance')
def v17_tariff_governance():
    c=db(); total=c.execute('SELECT COUNT(*) n FROM tariff_catalog').fetchone()['n']; verified=c.execute("SELECT COUNT(*) n FROM tariff_catalog WHERE status='VERIFIED'").fetchone()['n']; batches=c.execute('SELECT COUNT(*) n FROM tariff_import_batches').fetchone()['n']; c.close()
    return {'version':V17_VERSION,'authority':'TRA/TANeSW official source','policy':'No invented production rates. Import exact official snapshots with source, version, effective date and checksum.','records':total,'verified_records':verified,'import_batches':batches,'status':'READY_FOR_OFFICIAL_DATASET' if total==0 or verified==total else 'REVIEW_REQUIRED'}

@app.get('/api/v17/architecture')
def v17_architecture():
    return {'version':V17_VERSION,'north_star':'One operational truth for the full cargo lifecycle','layers':['Experience & Command Centre','Digital Twin','Event & GPS Intelligence','Workflow & Exception Orchestration','Customs & Trade Rules','Shipment/Container/Trucking Core','Finance & Demurrage','Documents & Evidence','Integration/API Gateway','Security/RBAC/Audit','Analytics/AI Decision Support','Observability/DR/Offline Resilience'],'lifecycle':['B/L','Manifest','Documents','Customs','TRA/OGA controls','Release','Delivery Order','Port/ICD','Truck','Transit','Border','DRC destination','Delivery','Bond closure','Finance reconciliation'],'guardrails':['AI is decision support unless explicitly authorised','official regulatory/rate data is source-controlled','financial calculations use decimal arithmetic','every material action is auditable','events are idempotent','timestamps are stored in UTC and displayed in operational timezone']}



# ---------------- V18: Client / Cargo / Shipment / Container hierarchy ----------------
def _safe_code(prefix, value):
    import re, hashlib
    raw=re.sub(r'[^A-Z0-9]+','-',str(value or '').upper()).strip('-')
    raw=raw[:28] or 'UNKNOWN'
    return f"{prefix}-{raw}-{hashlib.sha1(str(value).encode()).hexdigest()[:6].upper()}"

def ensure_v18_model():
    c=db()
    c.executescript('''
    CREATE TABLE IF NOT EXISTS clients(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      client_code TEXT UNIQUE,
      legal_name TEXT UNIQUE,
      tin TEXT DEFAULT '', contact TEXT DEFAULT '', phone TEXT DEFAULT '',
      email TEXT DEFAULT '', address TEXT DEFAULT '', status TEXT DEFAULT 'ACTIVE',
      created_at TEXT
    );
    CREATE TABLE IF NOT EXISTS cargo_items(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      client_id INTEGER,
      shipment_id TEXT,
      bl TEXT DEFAULT '',
      description TEXT DEFAULT '',
      packages REAL DEFAULT 0,
      package_unit TEXT DEFAULT '',
      gross_weight REAL DEFAULT 0,
      net_weight REAL DEFAULT 0,
      volume_cbm REAL DEFAULT 0,
      hs_code TEXT DEFAULT '',
      origin TEXT DEFAULT '', destination TEXT DEFAULT '',
      value REAL DEFAULT 0, currency TEXT DEFAULT 'USD',
      container_no TEXT DEFAULT '', status TEXT DEFAULT 'ACTIVE', created_at TEXT,
      FOREIGN KEY(client_id) REFERENCES clients(id) ON DELETE SET NULL
    );
    CREATE INDEX IF NOT EXISTS idx_clients_name ON clients(legal_name);
    CREATE INDEX IF NOT EXISTS idx_cargo_client ON cargo_items(client_id);
    CREATE INDEX IF NOT EXISTS idx_cargo_shipment ON cargo_items(shipment_id);
    CREATE INDEX IF NOT EXISTS idx_cargo_container ON cargo_items(container_no);
    ''')
    # Backfill the normalized hierarchy from the existing V2 shipment records.
    shipments=c.execute('SELECT * FROM shipments').fetchall()
    for sh in shipments:
        name=sh['customer'] or 'Unknown Client'
        row=c.execute('SELECT id FROM clients WHERE legal_name=?',(name,)).fetchone()
        if row:
            cid=row['id']
        else:
            cur=c.execute('INSERT INTO clients(client_code,legal_name,tin,contact,phone,email,address,status,created_at) VALUES(?,?,?,?,?,?,?,?,?)',
                          (_safe_code('CLI',name),name,sh['tin'] or '',sh['contact'] or '',sh['phone'] or '',sh['email'] or '',sh['address'] or '','ACTIVE',sh['created_at'] or now_utc()))
            cid=cur.lastrowid
        # Ensure each shipment has at least one cargo node.
        if not c.execute('SELECT 1 FROM cargo_items WHERE shipment_id=?',(sh['id'],)).fetchone():
            cont=c.execute('SELECT container_no FROM containers WHERE shipment_id=? ORDER BY id',(sh['id'],)).fetchall()
            if cont:
                for r in cont:
                    c.execute('INSERT INTO cargo_items(client_id,shipment_id,bl,description,origin,destination,container_no,status,created_at) VALUES(?,?,?,?,?,?,?,?,?)',
                              (cid,sh['id'],sh['bl'] or '',sh['cargo'] or '',sh['origin'] or '',sh['destination'] or '',r['container_no'] or '','ACTIVE',now_utc()))
            else:
                c.execute('INSERT INTO cargo_items(client_id,shipment_id,bl,description,origin,destination,status,created_at) VALUES(?,?,?,?,?,?,?,?)',
                          (cid,sh['id'],sh['bl'] or '',sh['cargo'] or '',sh['origin'] or '',sh['destination'] or '','ACTIVE',now_utc()))
    c.commit(); c.close()

@app.get('/api/v18/clients')
def v18_clients(request:Request):
    _current_user(request); c=db()
    rows_out=[]
    for r in c.execute('SELECT * FROM clients ORDER BY legal_name').fetchall():
        d=dict(r)
        d['shipment_count']=c.execute('SELECT COUNT(*) n FROM shipments WHERE customer=?',(r['legal_name'],)).fetchone()['n']
        d['cargo_count']=c.execute('SELECT COUNT(*) n FROM cargo_items WHERE client_id=?',(r['id'],)).fetchone()['n']
        d['container_count']=c.execute('SELECT COUNT(*) n FROM containers WHERE shipment_id IN (SELECT id FROM shipments WHERE customer=?)',(r['legal_name'],)).fetchone()['n']
        rows_out.append(d)
    c.close(); return rows_out

@app.get('/api/v18/clients/{client_id}/360')
def v18_client_360(client_id:int, request:Request):
    _current_user(request); c=db()
    client=c.execute('SELECT * FROM clients WHERE id=?',(client_id,)).fetchone()
    if not client: c.close(); raise HTTPException(404,'Client not found')
    name=client['legal_name']
    shipments=[dict(x) for x in c.execute('SELECT * FROM shipments WHERE customer=? ORDER BY created_at DESC',(name,)).fetchall()]
    sids=[x['id'] for x in shipments]
    cargo=[dict(x) for x in c.execute('SELECT * FROM cargo_items WHERE client_id=? ORDER BY id DESC',(client_id,)).fetchall()]
    containers=[]; declarations=[]; documents=[]; finance=[]; demurrage=[]; trips=[]
    if sids:
        q=','.join('?' for _ in sids)
        containers=[dict(x) for x in c.execute(f'SELECT * FROM containers WHERE shipment_id IN ({q}) ORDER BY id DESC',tuple(sids)).fetchall()]
        declarations=[dict(x) for x in c.execute(f'SELECT * FROM declarations WHERE shipment_id IN ({q}) ORDER BY id DESC',tuple(sids)).fetchall()]
        documents=[dict(x) for x in c.execute(f'SELECT * FROM documents WHERE shipment_id IN ({q}) ORDER BY id DESC',tuple(sids)).fetchall()]
        finance=[dict(x) for x in c.execute(f'SELECT * FROM finance WHERE shipment_id IN ({q}) ORDER BY id DESC',tuple(sids)).fetchall()]
        demurrage=[dict(x) for x in c.execute(f'SELECT * FROM demurrage WHERE shipment_id IN ({q}) ORDER BY id DESC',tuple(sids)).fetchall()]
        for x in sids:
            trips += [dict(t) for t in c.execute('SELECT * FROM trips WHERE bl=? ORDER BY sn DESC',(next((z['bl'] for z in shipments if z['id']==x),''),)).fetchall()]
    c.close()
    return {'version':'2.1.0','client':dict(client),'shipments':shipments,'cargo':cargo,'containers':containers,'declarations':declarations,'documents':documents,'finance':finance,'demurrage':demurrage,'trips':trips}

@app.get('/api/v18/cargo')
def v18_cargo(request:Request):
    _current_user(request); c=db()
    out=[]
    for r in c.execute('SELECT * FROM cargo_items ORDER BY id DESC').fetchall():
        d=dict(r)
        d['client_name']=(c.execute('SELECT legal_name FROM clients WHERE id=?',(r['client_id'],)).fetchone() or {'legal_name':''})['legal_name']
        out.append(d)
    c.close(); return out

@app.get('/api/v18/containers/{container_no}/360')
def v18_container_360(container_no:str, request:Request):
    _current_user(request); c=db()
    r=c.execute('SELECT * FROM containers WHERE container_no=?',(container_no,)).fetchone()
    if not r: c.close(); raise HTTPException(404,'Container not found')
    shipment=c.execute('SELECT * FROM shipments WHERE id=?',(r['shipment_id'],)).fetchone()
    client=c.execute('SELECT * FROM clients WHERE legal_name=?',(shipment['customer'] if shipment else '',)).fetchone()
    cargo=[dict(x) for x in c.execute('SELECT * FROM cargo_items WHERE container_no=? OR shipment_id=?',(container_no,r['shipment_id'] or '')).fetchall()]
    declarations=[dict(x) for x in c.execute('SELECT * FROM declarations WHERE shipment_id=?',(r['shipment_id'],)).fetchall()]
    documents=[dict(x) for x in c.execute('SELECT * FROM documents WHERE shipment_id=?',(r['shipment_id'],)).fetchall()]
    dem=[dict(x) for x in c.execute('SELECT * FROM demurrage WHERE container_no=?',(container_no,)).fetchall()]
    trips=[dict(x) for x in c.execute('SELECT * FROM trips WHERE container=?',(container_no,)).fetchall()]
    events=[dict(x) for x in c.execute('SELECT * FROM events WHERE entity_type=? AND entity_id=? ORDER BY event_time DESC, id DESC',( 'CONTAINER',container_no)).fetchall()]
    c.close()
    return {'version':'2.1.0','container':dict(r),'client':dict(client) if client else None,'shipment':dict(shipment) if shipment else None,'cargo':cargo,'declarations':declarations,'documents':documents,'demurrage':dem,'trips':trips,'events':events}

class CargoIn(BaseModel):
    client_id:int=0; shipment_id:str=''; bl:str=''; description:str=''; packages:float=0; package_unit:str=''; gross_weight:float=0; net_weight:float=0; volume_cbm:float=0; hs_code:str=''; origin:str=''; destination:str=''; value:float=0; currency:str='USD'; container_no:str=''; status:str='ACTIVE'

@app.post('/api/v18/cargo')
def v18_create_cargo(x:CargoIn, request:Request):
    _current_user(request); c=db()
    if x.client_id and not c.execute('SELECT 1 FROM clients WHERE id=?',(x.client_id,)).fetchone(): c.close(); raise HTTPException(404,'Client not found')
    cur=c.execute('INSERT INTO cargo_items(client_id,shipment_id,bl,description,packages,package_unit,gross_weight,net_weight,volume_cbm,hs_code,origin,destination,value,currency,container_no,status,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
      (x.client_id or None,x.shipment_id,x.bl,x.description,x.packages,x.package_unit,x.gross_weight,x.net_weight,x.volume_cbm,x.hs_code,x.origin,x.destination,x.value,x.currency,x.container_no,x.status,now_utc()))
    c.commit(); i=cur.lastrowid; c.close(); audit('CARGO',i,'CREATE','Operator','Cargo item created'); return {'id':i}

# Extend the existing shipment endpoint with the same hierarchical relationships.
@app.get('/api/v18/shipments/{shipment_id}/360')
def v18_shipment_360(shipment_id:str, request:Request):
    _current_user(request); c=db()
    sh=c.execute('SELECT * FROM shipments WHERE id=?',(shipment_id,)).fetchone()
    if not sh: c.close(); raise HTTPException(404,'Shipment not found')
    client=c.execute('SELECT * FROM clients WHERE legal_name=?',(sh['customer'],)).fetchone()
    cargo=[dict(x) for x in c.execute('SELECT * FROM cargo_items WHERE shipment_id=?',(shipment_id,)).fetchall()]
    containers=[dict(x) for x in c.execute('SELECT * FROM containers WHERE shipment_id=?',(shipment_id,)).fetchall()]
    declarations=[dict(x) for x in c.execute('SELECT * FROM declarations WHERE shipment_id=?',(shipment_id,)).fetchall()]
    documents=[dict(x) for x in c.execute('SELECT * FROM documents WHERE shipment_id=?',(shipment_id,)).fetchall()]
    finance=[dict(x) for x in c.execute('SELECT * FROM finance WHERE shipment_id=?',(shipment_id,)).fetchall()]
    demurrage=[dict(x) for x in c.execute('SELECT * FROM demurrage WHERE shipment_id=?',(shipment_id,)).fetchall()]
    trips=[dict(x) for x in c.execute('SELECT * FROM trips WHERE bl=?',(sh['bl'],)).fetchall()]
    milestones=[dict(x) for x in c.execute('SELECT * FROM milestones WHERE entity_id=?',(shipment_id,)).fetchall()]
    c.close()
    return {'version':'2.1.0','shipment':dict(sh),'client':dict(client) if client else None,'cargo':cargo,'containers':containers,'declarations':declarations,'documents':documents,'finance':finance,'demurrage':demurrage,'trips':trips,'milestones':milestones}

@app.on_event('startup')
def startup_identity():
    init()
    ensure_v18_model()
    _seed_admin()

# Serve the frontend from the same FastAPI process so users do not need a second server.
FRONTEND_DIR=BASE.parent.parent/'frontend'
if FRONTEND_DIR.exists():
    @app.get('/', include_in_schema=False)
    def frontend_index():
        return FileResponse(FRONTEND_DIR/'index.html')
    app.mount('/frontend', StaticFiles(directory=FRONTEND_DIR), name='frontend')
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=False, allow_methods=["*"], allow_headers=["*"])

# ---------------- V15: LIVE LOGISTICS DIGITAL TWIN ----------------
V15_VERSION='1.5.0'
class TwinBuildIn(BaseModel):
    shipment_id:str
    model_version:str='v15.0'

@app.get('/api/v15/health')
def v15_health():
    c=db();
    required=['shipments','containers','trips','declarations','documents','demurrage','events','twin_snapshots','eta_predictions','risk_v2']
    checks={t:bool(c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",(t,)).fetchone()) for t in required}
    checks['foreign_keys']=bool(c.execute('PRAGMA foreign_keys').fetchone()[0]); checks['wal']=c.execute('PRAGMA journal_mode').fetchone()[0].lower()=='wal'
    c.close(); return {'version':V15_VERSION,'status':'READY' if all(checks.values()) else 'DEGRADED','checks':checks}

def _shipment_twin(c, shipment_id):
    s=c.execute('SELECT * FROM shipments WHERE id=?',(shipment_id,)).fetchone()
    if not s: raise HTTPException(404,'Shipment not found')
    s=dict(s)
    containers=[dict(r) for r in c.execute('SELECT * FROM containers WHERE shipment_id=? ORDER BY id',(shipment_id,)).fetchall()]
    trips=[dict(r) for r in c.execute('SELECT * FROM trips WHERE bl=? ORDER BY sn',(s.get('bl'),)).fetchall()]
    decls=[dict(r) for r in c.execute('SELECT * FROM declarations WHERE shipment_id=? ORDER BY id DESC',(shipment_id,)).fetchall()]
    docs=[dict(r) for r in c.execute('SELECT * FROM documents WHERE shipment_id=? ORDER BY id DESC',(shipment_id,)).fetchall()]
    dem=[dict(r) for r in c.execute('SELECT * FROM demurrage WHERE shipment_id=? ORDER BY id DESC',(shipment_id,)).fetchall()]
    events=[dict(r) for r in c.execute('SELECT * FROM events WHERE entity_id=? ORDER BY id DESC LIMIT 50',(shipment_id,)).fetchall()]
    exp=[dict(r) for r in c.execute('SELECT * FROM cost_exposures WHERE shipment_id=? ORDER BY id DESC',(shipment_id,)).fetchall()]
    tasks=[dict(r) for r in c.execute("SELECT * FROM operational_tasks WHERE entity_id=? AND status NOT IN ('COMPLETED','CLOSED') ORDER BY priority,due_at",(shipment_id,)).fetchall()]
    risks=[dict(r) for r in c.execute("SELECT * FROM risk_v2 WHERE entity_type='SHIPMENT' AND entity_id=? ORDER BY id DESC LIMIT 5",(shipment_id,)).fetchall()]
    eta=[dict(r) for r in c.execute('SELECT * FROM eta_predictions WHERE shipment_id=? ORDER BY id DESC LIMIT 5',(shipment_id,)).fetchall()]
    locations=[x.get('location') for x in trips if x.get('location')]
    latest_loc=locations[0] if locations else s.get('destination') or s.get('pod') or s.get('pol')
    blocker_count=len([x for x in tasks if x.get('priority') in ('HIGH','CRITICAL')]) + len([x for x in dem if x.get('status')=='OPEN'])
    latest_risk=risks[0]['score'] if risks else 0
    health=max(0,min(100,100-(blocker_count*10)-float(latest_risk)*0.25))
    return {'shipment':s,'containers':containers,'trips':trips,'declarations':decls,'documents':docs,'demurrage':dem,'events':events,'exposures':exp,'open_tasks':tasks,'latest_risk':risks[0] if risks else None,'eta':eta[0] if eta else None,'digital_twin':{'entity_type':'SHIPMENT','entity_id':shipment_id,'health_score':round(health,2),'risk_score':latest_risk,'location':latest_loc,'blocker_count':blocker_count,'model_version':V15_VERSION}}

@app.get('/api/v15/shipment/{shipment_id}/360')
def v15_shipment_360(shipment_id:str):
    c=db()
    try: return _shipment_twin(c,shipment_id)
    finally: c.close()

@app.post('/api/v15/digital-twin/build')
def v15_build_twin(x:TwinBuildIn):
    c=db(); data=_shipment_twin(c,x.shipment_id); twin=data['digital_twin']
    cur=c.execute('INSERT INTO twin_snapshots(entity_type,entity_id,state,health_score,risk_score,eta,location,blockers,model_version,captured_at) VALUES(?,?,?,?,?,?,?,?,?,?)',('SHIPMENT',x.shipment_id,json.dumps(data,separators=(',',':')),twin['health_score'],twin['risk_score'],data['eta']['predicted_eta'] if data['eta'] else None,twin['location'],json.dumps(data['open_tasks']),x.model_version,now_utc()))
    c.commit(); ident=cur.lastrowid; c.close(); return {'snapshot_id':ident,'shipment_id':x.shipment_id,'digital_twin':twin}

@app.get('/api/v15/network/overview')
def v15_network():
    c=db();
    shipments=[dict(r) for r in c.execute('SELECT id,bl,customer,origin,pol,pod,destination,status,containers FROM shipments ORDER BY created_at DESC LIMIT 100').fetchall()]
    rows=[]
    for s in shipments:
        trips=[dict(r) for r in c.execute('SELECT sn,truck,container,location,status,dispatch,arrival,offloaded FROM trips WHERE bl=? ORDER BY sn',(s.get('bl'),)).fetchall()]
        risks=[dict(r) for r in c.execute("SELECT score,level,factors,recommended_actions,calculated_at FROM risk_v2 WHERE entity_type='SHIPMENT' AND entity_id=? ORDER BY id DESC LIMIT 1",(s['id'],)).fetchall()]
        rows.append({'shipment':s,'trips':trips,'risk':risks[0] if risks else None})
    c.close(); return {'version':V15_VERSION,'route':['Dar es Salaam','Tunduma','Nakonde','Zambia','Kasumbalesa','DRC','Destination'],'shipments':rows}
