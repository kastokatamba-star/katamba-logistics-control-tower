# Katamba Logistics Control Tower — V6 Release

## V6 — Enterprise Workflow & Rules Layer

V6 continues from V5 and preserves the existing shipment, trucking/transit, customs, documents, finance, exceptions, intelligence, reconciliation, approvals and audit foundations.

### Added
- RBAC foundation: users, roles and permission catalogue.
- Configurable workflow definitions and workflow-run state.
- Versioned tariff-rule registry and deterministic tariff calculation endpoint.
- Evidence registry and verification controls for operational/customs/waiver evidence.
- Integration contract registry for future customs, port, shipping-line, GPS and finance connectors.
- Observability endpoint with core operational health metrics.
- Expanded health metadata and enterprise capabilities.
- Frontend Enterprise Controls, Tariff Engine, Workflows, Evidence, Integrations and Observability pages.
- Frontend error state changed from misleading "Backend not reachable" to a page-specific error state.

### Quality gates
- Python compilation: PASS
- FastAPI startup: PASS
- Root frontend route: HTTP 200
- Health: HTTP 200
- Procedures: HTTP 200; EX1–EX3 and IM4–IM9 present
- RBAC endpoints: PASS
- Workflow endpoints: PASS
- Tariff calculation: PASS
- Evidence endpoints: PASS
- Integration endpoints: PASS
- Observability endpoint: PASS

### Important rule
No live carrier, terminal or regulatory tariff is invented. A tariff rule must carry source, version and effective dates before being treated as authoritative.

## Next target: V7
- Production-grade authentication/session model
- Policy enforcement middleware
- Full workflow state transitions and approvals
- Advanced demurrage/detention/storage separation
- Shipment/BL/document/container graph
- Customs reconciliation expansion
- Evidence-to-exception automation
- Integration adapters and webhook/event contracts
- Automated unit/integration/end-to-end test suite
- Operational search and filtering
- Data migration/versioning strategy
