# Katamba Logistics Control Tower — V15

## Live Logistics Digital Twin

V15 unifies the operational view of a shipment across B/L, containers, trucking, customs declarations, documents, demurrage, events, financial exposure, tasks, ETA and risk decisions.

### New endpoints
- GET `/api/v15/health`
- GET `/api/v15/shipment/{shipment_id}/360`
- POST `/api/v15/digital-twin/build`
- GET `/api/v15/network/overview`

### Design principles
- Existing V2–V14 modules remain the baseline.
- Official tariff/rule values are not fabricated.
- Predictions are decision support and remain explainable/versioned.
- Operational timestamps remain UTC in storage; display uses Africa/Dar_es_Salaam.
- Google Maps is retained through official Directions URLs; live GPS/traffic requires an authorised Maps Platform integration and credentials.
- Trucking remains a first-class operational domain.
