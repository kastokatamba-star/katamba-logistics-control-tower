# Katamba Logistics Control Tower — V0.7

## V7 focus: Enterprise Hardening, Performance & Operational Integrity

V7 is built on V6 and preserves the established business scope: shipment 360, B/L and container control, trucking/transit corridors, customs procedures EX1–EX3 and IM4–IM9, declaration validation, demurrage/waiver control, reconciliation, evidence, SLA, approvals, RBAC, workflow, tariff/rule versioning, integrations, audit and observability.

### Major upgrades
- SQLite integrity and performance hardening: WAL, foreign keys, busy timeout and targeted indexes.
- Request correlation IDs and consistent API error responses.
- Readiness/health endpoints suitable for deployment checks.
- Pagination and bounded query endpoints to avoid unbounded reads.
- Operational event ledger for immutable milestone/event history.
- Container 360 control view linking shipment, declarations, documents, demurrage, milestones, events and finance.
- Stronger declaration state-machine validation; illegal lifecycle jumps are rejected.
- Four-way reconciliation control: B/L ↔ Invoice ↔ Packing List ↔ Declaration, with material mismatch handling.
- Deterministic, Decimal-based tariff calculation endpoint; no live commercial/regulatory tariff is invented.
- Control-tower risk scoring foundation for demurrage, SLA, customs query/hold and unresolved reconciliation.
- Idempotency support for selected create operations using an Idempotency-Key request header.
- Operational metrics endpoint for API/database health and record volumes.

### Data integrity rule
No regulatory, customs, port or shipping-line rate is assumed to be current merely because it exists in the application. Rules/tariffs require source, version and effective dates and must be verified before production use.

### Testing standard
V7 is released only after syntax compilation, API smoke tests, lifecycle/state-machine tests, reconciliation tests, tariff calculation tests, idempotency tests and regression checks for EX1–EX3/IM4–IM9.
