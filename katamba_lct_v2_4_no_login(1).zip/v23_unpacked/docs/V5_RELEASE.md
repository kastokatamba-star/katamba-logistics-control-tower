# Katamba Logistics Control Tower — V5

## Intelligence & Automation Layer

V5 extends V4 without replacing its operational foundation.

### Added
- Event stream: `/api/events`
- Notification centre and acknowledgement: `/api/notifications`
- Automated scan: `/api/automation/scan`
- B/L / shipment / declaration / container reconciliation: `/api/reconciliation/{shipment_id}`
- Reconciliation history: `/api/reconciliation/{shipment_id}/history`
- Approval workflow: `/api/approvals`
- Executive analytics: `/api/analytics/overview`
- Expanded health/capability reporting

### Design principles
- Evidence before assumption.
- Reconciliation before submission.
- Rules are versioned and source-aware.
- No invented live shipping-line tariffs.
- Customs workflows remain distinct from physical cargo release.
- Every material change is auditable.

### Next release
V6 will focus on production-grade RBAC, workflow orchestration, configurable rule evaluation, advanced demurrage tariff profiles, document/evidence intelligence, API integration contracts, observability and stronger test coverage.
