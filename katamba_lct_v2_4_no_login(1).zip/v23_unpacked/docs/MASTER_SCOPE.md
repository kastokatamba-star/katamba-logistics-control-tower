# Master Scope — v0.1

## Product vision
Enterprise Logistics + Customs + Trade + Transport Control Platform.

## Core domains
Customers/parties, products, shipments, B/L/AWB/consignments, cargo, containers/equipment, documents, customs declarations, transit, trucking, borders, warehousing, delivery, finance, demurrage/detention, reporting, integrations, security, audit, AI.

## Cargo/movement scope
Import, export, re-export, transit, transshipment, local/domestic, temporary import/export, re-import, warehousing and other supported procedures. Cargo architecture must support containerised, breakbulk, bulk, liquid/dry bulk, Ro-Ro, vehicles, machinery, project/OOG, perishables, dangerous goods, valuable/sensitive, air, sea, road, rail and multimodal movements.

## Tanzania customs framework currently used for study
EX1, EX2, EX3, IM4, IM5, IM6, IM7, IM8, IM9. Production rules must be verified against current authoritative sources before deployment.

## Trucking requirements
Truck, trailers, capacity, B/L, container, current location, driver, contact, driving licence, routing, passport, allocation/loading/dispatch, Tunduma, Nakonde, Zambia, DRC entry-card submissions, Whishky parking, destination arrival, offloading, transit days, free days and chargeable days. Must export operational report to XLSX.

## Engineering principles
Research → Verify → Design → Build → Test → Review → Validate → Document → Release.
API-first; modular architecture; configurable rules; versioned master data; event-driven evolution; auditability; reconciliation; multi-jurisdiction; offline-first event sync; security; automated testing; analytics-ready; no invented regulatory facts.

## Build stages
Core → Customs → Logistics → Finance → Intelligence → Enterprise.
