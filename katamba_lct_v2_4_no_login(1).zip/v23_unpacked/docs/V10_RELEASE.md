# Katamba Logistics Control Tower — V10 Release

## Focus
Enterprise Workflow, Task Orchestration, Document Readiness, Quality Gates and Operational Integrity.

## Preserved scope
- Customs procedures: EX1, EX2, EX3, IM4, IM5, IM6, IM7, IM8, IM9
- B/L ↔ Invoice ↔ Packing List ↔ Declaration reconciliation
- Container 360
- Demurrage / detention / waiver foundation
- Transit and bond monitoring
- DRC / Zambia corridors: Tunduma, Nakonde, Kasumbalesa
- SLA, approvals, evidence and audit
- Versioned official tariff snapshots with source/version/effective-date governance

## New V10 controls
- Operational task queue with priorities and blocking flags
- Evidence-gated task completion
- Procedure-aware document requirements
- Shipment readiness gate
- Automated control scan that creates blocking tasks from failed checks
- Control Tower work queue
- Quality summary and integrity score
- New indexes for high-frequency operational queries

## Regulatory source discipline
Production tariff values are not invented by the application. The authoritative tariff catalogue is designed to accept verified TANeSW/TRA snapshots with exact source values, snapshot reference, version and effective dates. Regulatory changes must create a new governed snapshot rather than silently overwrite history.

## Quality principle
Accuracy before speed. Evidence before assumption. Reconciliation before submission. Official source before regulated-rule activation. No silent overwrite.
