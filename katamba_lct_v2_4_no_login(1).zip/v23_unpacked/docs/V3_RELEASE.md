# Katamba Logistics Control Tower — V0.3 Operational Intelligence

## Delivered
- Control Tower KPI/risk endpoint.
- Container registry separated from shipment and trucking records.
- Demurrage ledger with explicit tariff provenance fields; no live tariff invented.
- Free-time and chargeable-day risk detection.
- Versioned rule registry with source/effective dates/status.
- Milestone table foundation for event-driven evolution.
- Existing V0.2 shipment, trucking, customs, documents, exceptions, finance, masters and audit modules retained.

## Design rule
Operational calculations may be automated, but regulatory/shipping-line tariffs must carry source/version/effective-date metadata before being treated as production rules.

## Next V0.4
- Real shipment/container detail pages.
- Configurable demurrage tariff engine with tiered rates and waiver approvals.
- Customs declaration workspace with declaration header, line items, supporting-document reconciliation and procedure-specific controls.
- Exception SLA/ownership workflow.
- API validation and automated tests.
