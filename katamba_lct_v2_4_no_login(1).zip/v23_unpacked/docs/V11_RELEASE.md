# V11 Release — Enterprise Orchestration & Financial Integrity

V11 extends the V10 baseline without removing prior customs, logistics, demurrage, tariff-governance or audit controls.

## New controls
- Versioned approval matrix with role, threshold, source and effective dates.
- Deterministic workflow start/advance engine and workflow queue.
- SLA escalation scan that creates auditable notifications for overdue operational tasks.
- Finance reconciliation using Decimal arithmetic and explicit variance; no silent adjustment.
- Enterprise health/readiness endpoint.
- Preserves EX1, EX2, EX3, IM4, IM5, IM6, IM7, IM8 and IM9.

## Regulatory integrity
TRA/TANeSW remains the authoritative source for verified production tariff data. No tariff rate is fabricated by this release.

## Quality
- Python compile: PASS
- Regression suite: PASS
- No legacy datetime deprecation warnings after hardening.
- Existing V10 tests retained.
