# Katamba Logistics Control Tower — V0.8

## V8 focus: Advanced Intelligence + Official Tariff Governance

### Tariff governance
- Production tariff catalogue is explicitly anchored to TANeSW / Tanzania Revenue Authority.
- No tariff rate is invented or silently copied from a generic source.
- Each catalogue row requires HS code, description, tariff version, effective date and snapshot reference.
- Rates are stored as strings to preserve exact source representation and avoid accidental rounding.
- Official-source snapshot lookup and governance endpoints are provided.
- This architecture supports exact import of the official TRA/TANeSW tariff dataset once supplied/exported from the authoritative source.

### Intelligence
- Deterministic control-tower risk scoring.
- Shipment-level risk scoring.
- Demurrage exposure, customs blockers, overdue SLA and material reconciliation are combined into operational priority signals.
- Every decision records model version and recommended action.

### Preserved scope
- B/L, invoice, packing list and declaration reconciliation.
- EX1, EX2, EX3, IM4, IM5, IM6, IM7, IM8 and IM9.
- Container 360.
- Shipping line / DO / deposit / demurrage / detention controls.
- Transit and bond lifecycle.
- DRC, Zambia and Malawi corridor operations.
- Evidence, SLA, approvals, RBAC, audit and observability.

### Important tariff note
The system treats the official tariff as a controlled, versioned source rather than assuming it is permanently immutable. Official Tanzania sources indicate that some duty/tax rates can be amended through annual Finance Acts, so the application preserves historical snapshots and effective dates rather than overwriting history. The authoritative production source remains TRA/TANeSW.
