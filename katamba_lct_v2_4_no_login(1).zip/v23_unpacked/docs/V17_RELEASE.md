# V17 / LCT 2.0 — Mission Control

This release is the consolidation point for the Katamba Logistics Control Tower. It is not a new disconnected product. It unifies the V2–V16 foundations into one operational architecture.

## North Star
One operational truth for the complete cargo lifecycle:
B/L → Manifest → Documents → Customs → TRA/OGA controls → Release → Delivery Order → Port/ICD → Truck → Transit → Border → DRC destination → Delivery → Bond closure → Finance reconciliation.

## Production guardrails
- TRA/TANeSW is the authoritative source for production customs/tariff data; no invented production rates.
- Exact tariff snapshots require source, version, effective dates, snapshot reference and checksum.
- AI/ETA/risk are decision-support until authorised data/models are configured.
- Financial calculations use decimal arithmetic.
- Events are designed for idempotency and auditability.
- UTC is the storage standard; Africa/Dar_es_Salaam is the operational display timezone.
- Google Maps is retained for corridor/navigation links; deeper Maps Platform features require authorised credentials.

## V17 APIs
- `/api/v17/health`
- `/api/v17/mission-control`
- `/api/v17/shipment/{shipment_id}/360`
- `/api/v17/tariff-governance`
- `/api/v17/architecture`

## Official workflow reference
The Tanzania Trade Portal currently documents multi-stage customs/port workflows including customs lodging, TANSAD, inspection/OGA controls, TRA release, Delivery Order, port clearance, truck/driver announcement and gate-out. The exact sequence varies by commodity/procedure and participating agencies.
