# Katamba Logistics Control Tower V14

## V14 focus
Real-time Command Centre, trucking calendar, Google Maps corridor links, operational clock, API resilience and frontend/backend same-origin serving.

## Important runtime fix
The previous `TypeError: Failed to fetch` path was hardened by:
- CORS support for separated frontend/API development
- clearer API error messages
- same-origin FastAPI serving of the frontend
- API base configuration via `window.__KATAMBA_API__`
- V14 health endpoint

## Trucking
The trucking module remains a first-class operational module. It supports corridor visibility across Dar es Salaam → Tunduma → Nakonde → Zambia → Kasumbalesa → DRC, milestone calendar data and Google Maps route links.

## Time
Operational display uses Africa/Dar_es_Salaam. Backend timestamps remain UTC for audit consistency.

## Google Maps
Links use Google Maps Directions URLs. They do not require a Google Maps API key for the normal web directions link. Future live map/traffic integrations should use an authorised API key and official Google Maps Platform APIs.

## Run
```bash
cd backend
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000
```
Open `http://localhost:8000/`.

## Verify
- `/api/v14/health`
- `/api/v14/clock`
- `/api/v14/command-centre`
- `/api/v14/calendar/trucking`
- `/api/v14/map/trip/1`
- `/docs`
