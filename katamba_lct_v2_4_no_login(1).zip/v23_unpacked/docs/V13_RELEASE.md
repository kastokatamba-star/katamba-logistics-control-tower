# V13 — Digital Twin, Predictive ETA, Risk 2.0 & Command Centre

V13 advances the Control Tower from workflow orchestration into operational intelligence while preserving the existing V2–V12 foundations.

## Core capabilities
- Digital Twin snapshots for shipment/container/trip entities
- Versioned ETA prediction records with confidence and contributing factors
- Versioned Risk 2.0 decisions with explainable factors and recommended actions
- Append-only event-stream read endpoint with cursor (`after_id`)
- Command Centre posture: critical/high exceptions, overdue tasks, pending integrations and open financial exposure
- Health/readiness checks for V13 data structures, foreign keys and WAL

## Safety and governance
Predictions and risk decisions are decision-support records. They do not replace authorised customs rules, official TRA/TANeSW tariff data, human approvals, or documentary evidence.

## Preserved scope
EX1–EX3, IM4–IM9; B/L/manifest reconciliation; documents; customs; port/ICD; shipping line/DO; trucking; DRC/Zambia transit; bonds; demurrage/detention/storage; waivers; finance; workflow; approvals; audit; integration integrity; tariff governance.
