# Katamba Logistics Control Tower — V2.1 / V18 Data Hierarchy

## Purpose
V18 makes the existing V2–V17 platform read and navigate the operational hierarchy as a controlled record graph rather than a flat dashboard.

## Record hierarchy
Client → Cargo → Shipment/B/L → Container → Customs/Transport/Documents/Finance/Events.

## Added
- Normalized client master with backfill from existing shipment customer records.
- Normalized cargo items linked to client, shipment/B/L and container.
- Client 360 endpoint and frontend page.
- Shipment 360 hierarchy with cargo, containers, customs, documents, transport and demurrage.
- Container 360 hierarchy with client, shipment, cargo, customs, documents, transport, demurrage and events.
- Cargo register page.
- Dashboard simplified to high-level posture and attention-required items.
- Existing V2–V17 APIs and features retained.

## Governance
This is a consolidation/refinement of the existing product, not a replacement. Existing customs, transit, demurrage, evidence, RBAC, audit and enterprise controls remain in place.
