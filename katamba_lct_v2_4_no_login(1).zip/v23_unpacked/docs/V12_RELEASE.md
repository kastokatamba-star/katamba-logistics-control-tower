# V12 Release — Autonomous Control Tower & Operational Integrity

V12 advances the V11 baseline toward the top-tier vision: an evidence-driven control tower that detects operational risk, creates resolution work, enforces control gates, preserves integration idempotency, monitors route checkpoints and consolidates financial exposure.

## New capabilities
- Exception resolution actions and entity links.
- Control gates for identity, documents, customs, reconciliation, release, equipment, transit and finance.
- Integration message ledger with idempotency-key protection and correlation IDs.
- Route checkpoint tracking with overdue detection.
- Cost exposure ledger using Decimal amounts.
- Automated control-tower scan that creates actionable work for high/critical exceptions and exposure notifications.
- Enterprise health/readiness checks.

## Preserved foundations
- EX1, EX2, EX3, IM4, IM5, IM6, IM7, IM8, IM9.
- B/L, container, trucking/transit, documents, declarations, demurrage, waivers, finance, evidence, audit, SLA, workflow and approval matrix.
- TRA/TANeSW remains the authoritative source for verified production tariff data. No tariff rates are invented.

## Quality gates
- Python compile.
- API smoke tests.
- V11 regression retained.
- Idempotency replay test.
- Gate transition validation.
- Decimal exposure validation.
- Route overdue detection.
- Enterprise health check.
