# Katamba Logistics Control Tower — V0.9

## V9 focus: Advanced Customs Intelligence & Tariff Integrity

- Controlled TANeSW/TRA tariff snapshot import with exact source-rate strings.
- SHA-256 batch checksum, version, effective dates and snapshot reference.
- Imported tariff rows remain UNVERIFIED until authorised verification.
- No tariff rates are invented by the application.
- Classification workspace captures description, technical characteristics, intended use, material, candidate HS, selected HS, basis and confidence.
- Valuation workspace captures invoice, freight, insurance, additions, deductions, Incoterm, method and evidence reference.
- Customs 360 aggregates declarations, documents, reconciliation, classification and valuation.
- Decimal arithmetic and input validation protect calculation integrity.

The production tariff source is intended to be the authoritative TRA/TANeSW dataset supplied/exported from the official system. Tanzania's official Trade Portal states that Tanzania uses HS codes and that classification is based on the EAC Common External Tariff. Versions/effective dates are preserved instead of overwriting history.
