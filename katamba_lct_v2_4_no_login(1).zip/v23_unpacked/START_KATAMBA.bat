@echo off
setlocal
cd /d "%~dp0"

echo ==============================================
echo   KATAMBA LOGISTICS CONTROL TOWER
echo   Local Single-User Mode
echo ==============================================

where py >nul 2>nul
if %errorlevel%==0 (
  set "PY=py"
) else (
  where python >nul 2>nul
  if %errorlevel%==0 (
    set "PY=python"
  ) else (
    echo.
    echo Python is not installed or is not available in PATH.
    echo Install Python 3.12+ and run this file again.
    pause
    exit /b 1
  )
)

%PY% -c "import fastapi,uvicorn" >nul 2>nul
if errorlevel 1 (
  echo Installing required Python packages...
  %PY% -m pip install -r backend\requirements.txt
  if errorlevel 1 (
    echo Package installation failed.
    pause
    exit /b 1
  )
)

set KATAMBA_SINGLE_USER_MODE=1
start "Katamba LCT Server" /min %PY% -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8000

timeout /t 2 /nobreak >nul
start "" http://127.0.0.1:8000/

echo.
echo Katamba LCT is running at http://127.0.0.1:8000/
echo Keep the server window open while using the system.
echo.
pause
